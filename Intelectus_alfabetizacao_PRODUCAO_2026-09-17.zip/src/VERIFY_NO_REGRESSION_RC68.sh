#!/bin/bash
set -euo pipefail
ROOT="/Users/leandroandradedarocha/Developer/intelectus-alfabetizacao-rc68"
BASE="/Users/leandroandradedarocha/Developer/INTELECTUS_ALFABETIZACAO_FROZEN_RC68_FINAL"
TMP="${TMPDIR:-/tmp}/intelectus-alfabetizacao-rc68-current.sha256"
cd "$ROOT"
find . -type f ! -path './.vercel/*' ! -name 'VERIFY_NO_REGRESSION_RC68.sh' -print0 | sort -z | xargs -0 shasum -a 256 > "$TMP"
if ! diff -u "$BASE/BASELINE_CORE_SHA256SUMS.txt" "$TMP"; then
  echo 'REGRESSION_BLOCKED: arquivos divergem da baseline RC68 aprovada.' >&2
  exit 1
fi
if ! grep -q 'RC68-ANNUAL-EXPANSION-20260915' index.html version.json scripts/annual.rc68.js; then
  echo 'REGRESSION_BLOCKED: marcador RC68 ausente.' >&2
  exit 1
fi
node --check scripts/app.rc63.js >/dev/null
node --check scripts/enhancements.rc63.js >/dev/null
node --check scripts/voice.rc64.js >/dev/null
node --check scripts/annual.rc68.js >/dev/null
echo 'NO_REGRESSION_PASS: RC68 íntegra e sintaticamente válida.'