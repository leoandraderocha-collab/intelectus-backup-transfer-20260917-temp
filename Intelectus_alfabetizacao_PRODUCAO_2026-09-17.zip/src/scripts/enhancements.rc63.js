
/* Intelectus Alfabetização — RC63 10/10 layer */
(()=>{
'use strict';
const RC63_VERSION=63;
const RC63_RELEASE='RC63.2-10-DE-10';
state.rcPedagogicalVersion=RC63_VERSION;
state.rc63=state.rc63&&typeof state.rc63==='object'?state.rc63:{};
state.rc63.tutorialDone=!!state.rc63.tutorialDone;
state.rc63.tutorialStep=Number.isInteger(state.rc63.tutorialStep)?state.rc63.tutorialStep:0;
state.rc63.achievements=state.rc63.achievements&&typeof state.rc63.achievements==='object'?state.rc63.achievements:{};
safeSave();

// BNCC: 2º Ano order alphabetically is explicitly a reviewed prerequisite, not mislabeled as a new 2º-year skill.
const grade2=window.RC59_CURRICULUM?.['2º Ano'];
const orderSkill=grade2?.find(s=>s.id==='ef2-order');
if(orderSkill){orderSkill.bncc=['EF01LP10'];orderSkill.desc='Pré-requisito do 1º ano retomado funcionalmente no 2º ano; não é apresentado como habilidade nova do 2º ano.';}

const ACH=[
 {id:'first',icon:'🌟',name:'Primeira Missão',desc:'Concluir a primeira prática da aventura.',test:()=>totalAttempts()>=1},
 {id:'letters',icon:'🔤',name:'Amigo das Letras',desc:'Avançar com segurança nas habilidades de letras.',test:()=>skillMastered(['ei-letters','ef1-letters','ef2-review-letters'])||worldStats(0).attempts>=8},
 {id:'sounds',icon:'👂',name:'Caçador de Sons',desc:'Explorar rimas, sons iniciais ou finais.',test:()=>skillMastered(['ei-rhyme','ef1-rhyme','ef2-final'])||worldStats(1).attempts>=6},
 {id:'half',icon:'🧭',name:'Metade da Jornada',desc:'Chegar a 50% do percurso da etapa.',test:()=>progress()>=50},
 {id:'reader',icon:'📚',name:'Leitor Explorador',desc:'Praticar compreensão e construção de sentido.',test:()=>worldStats(6).attempts>=5||skillMastered(['ei-books','ef1-literal','ef2-literal'])},
 {id:'complete',icon:'🏆',name:'Etapa Concluída',desc:'Concluir 100% do percurso da etapa.',test:()=>progress()>=100}
];
function C(){try{return window.RC59_API?.C?.()||[]}catch(_){return[]}}
function progress(){try{return window.RC59_API?.curriculumProgress?.()||0}catch(_){return 0}}
function skillMastered(ids){try{return C().some(s=>ids.includes(s.id)&&window.RC59_API.skillProgress(s).mastered)}catch(_){return false}}
function totalAttempts(){let n=0;try{worlds.forEach((_,i)=>{n+=Number(worldStats(i).attempts||0)})}catch(_){}return n}
function awardAchievements(){const unlocked=[];ACH.forEach(a=>{if(!state.rc63.achievements[a.id]&&a.test()){state.rc63.achievements[a.id]=Date.now();unlocked.push(a)}});if(unlocked.length)safeSave();return unlocked}
function unlockedCount(){return ACH.filter(a=>state.rc63.achievements[a.id]).length}
function fmtDate(ts){try{return new Date(ts).toLocaleDateString('pt-BR')}catch(_){return''}}
function badgeMini(a){return `<div class="rc63-badge-mini"><i>${a.icon}</i><div><b>${escapeHtml(a.name)}</b><small>${escapeHtml(a.desc)}</small></div></div>`}
function toast(a){document.querySelector('.rc63-toast')?.remove();const n=document.createElement('div');n.className='rc63-toast';n.setAttribute('role','status');n.setAttribute('aria-live','polite');n.innerHTML=`${a.icon} Nova conquista: <b>${escapeHtml(a.name)}</b>`;document.body.appendChild(n);setTimeout(()=>n.remove(),3600)}

function guideInfo(){const list=window.RC58_GUIDES||[];return list.find(x=>x.id===state.guideId)||list[0]||{name:state.guide||'Lia',title:'Profª',src:TEACHER}}
function tutorial(){
 setTop(false);const g=guideInfo(),step=Math.max(0,Math.min(2,state.rc63.tutorialStep||0));
 const dots=`<div class="rc63-tutorial-progress" aria-label="Passo ${step+1} de 3">${[0,1,2].map(i=>`<i class="${i<=step?'on':''}"></i>`).join('')}</div>`;
 let demo='';
 if(step===0)demo=`<div class="rc63-demo rc63-sound-demo"><b>1. Primeiro, escute</b><button id="rc63Hear" aria-label="Ouvir exemplo">🔊</button><small>Toque no alto-falante. Você pode ouvir novamente sempre que precisar.</small></div><button class="primary-xl" id="rc63TutNext" disabled>Ouvi! Continuar</button>`;
 if(step===1)demo=`<div class="rc63-demo"><b>2. Depois, escolha sua resposta</b><p>Qual é a letra A?</p><div class="rc63-demo-choices"><button class="rc63-demo-choice" data-rc63-demo="B">B</button><button class="rc63-demo-choice" data-rc63-demo="A">A</button></div><div id="rc63TutFeedback" role="status" aria-live="polite"></div></div><button class="primary-xl" id="rc63TutNext" disabled>Continuar</button>`;
 if(step===2)demo=`<div class="rc63-demo"><div class="rc63-reward" aria-hidden="true">🏆</div><b>3. Receba feedback e siga no seu ritmo</b><p>Acertar libera comemorações. Errar mostra uma dica e você pode tentar outra vez.</p></div><button class="primary-xl" id="rc63TutFinish">Estou pronto para a aventura!</button>`;
 document.querySelector('#view').innerHTML=`<section class="view"><div class="card rc63-tutorial">${dots}<img class="rc63-guide" src="${g.src}" alt="${escapeHtml(g.title+' '+g.name)}, guia da aventura"><h1>Como jogar</h1><p>${escapeHtml(g.name)} mostra em três passos como funciona uma missão.</p>${demo}<p class="rc63-tip">Você pode rever este tutorial a qualquer momento pela tela inicial ou pela Área da Família.</p>${footer()}</div></section>`;
 if(step===0){const hear=document.querySelector('#rc63Hear'),next=document.querySelector('#rc63TutNext');hear.onclick=()=>{try{playSeq([pick(AUD.praise)])}catch(_){};hear.textContent='✓';next.disabled=false;next.focus()};next.onclick=()=>{state.rc63.tutorialStep=1;safeSave();render()}}
 if(step===1){const next=document.querySelector('#rc63TutNext'),fb=document.querySelector('#rc63TutFeedback');document.querySelectorAll('[data-rc63-demo]').forEach(b=>b.onclick=()=>{if(b.dataset.rc63Demo==='A'){b.classList.add('ok');fb.innerHTML='<p><b>Isso! Muito bem!</b></p>';next.disabled=false;next.focus();try{playSeq([pick(AUD.praise)])}catch(_){}}else{fb.innerHTML='<p>Quase! Procure a letra <b>A</b> e tente novamente.</p>';try{playSeq([pick(AUD.try)])}catch(_){}}});next.onclick=()=>{state.rc63.tutorialStep=2;safeSave();render()}}
 if(step===2)document.querySelector('#rc63TutFinish').onclick=()=>{state.rc63.tutorialDone=true;state.rc63.tutorialStep=0;safeSave();view=state.diagnosticDone?'home':'diagnosticIntro';render()};
}
function achievements(){
 setTop(true);awardAchievements();const n=unlockedCount();
 document.querySelector('#view').innerHTML=`<section class="view"><div class="card rc63-achievements"><button class="secondary" id="rc63AchBack">← Voltar</button><h1>Conquistas</h1><div class="rc63-ach-summary">${n} de ${ACH.length} conquistas desbloqueadas nesta etapa.</div><div class="rc63-badge-grid">${ACH.map(a=>{const ts=state.rc63.achievements[a.id],locked=!ts;return `<div class="rc63-badge-card ${locked?'locked':''}"><div class="icon">${locked?'🔒':a.icon}</div><div><b>${escapeHtml(a.name)}</b><small>${escapeHtml(a.desc)}</small>${ts?`<span class="date">Conquistada em ${fmtDate(ts)}</span>`:''}</div></div>`}).join('')}</div>${footer()}</div></section>`;
 document.querySelector('#rc63AchBack').onclick=()=>{view='home';render()};
}

// New learners see a real three-step tutorial between onboarding and diagnosis.
const RC63_PREV_ONBOARDING=onboarding;
onboarding=function(){
 RC63_PREV_ONBOARDING();
 if(view==='onboardSound'&&!state.rc63.tutorialDone){const btn=document.querySelector('#next');if(btn){const old=btn.onclick;btn.onclick=e=>{if(typeof old==='function')old.call(btn,e);state.rc63.tutorialStep=0;safeSave();view='rc63Tutorial';render()}}}
};

function enhanceHome(){const root=document.querySelector('.home-view');if(!root||root.querySelector('.rc63-toolbar'))return;const newly=awardAchievements();const hero=root.querySelector('.hero');if(!hero)return;const bar=document.createElement('div');bar.className='rc63-toolbar';bar.innerHTML=`<button type="button" id="rc63How">❔ Como jogar</button><button type="button" id="rc63Achievements">🏅 Conquistas <span>${unlockedCount()}/${ACH.length}</span></button>`;hero.insertAdjacentElement('afterend',bar);const strip=document.createElement('div');strip.className='rc63-badge-strip';const unlocked=ACH.filter(a=>state.rc63.achievements[a.id]);strip.innerHTML=unlocked.length?unlocked.slice(-3).reverse().map(badgeMini).join(''):`<div class="rc63-badge-empty">A primeira conquista aparece assim que a criança conclui sua primeira missão.</div>`;bar.insertAdjacentElement('afterend',strip);document.querySelector('#rc63How').onclick=()=>{state.rc63.tutorialStep=0;view='rc63Tutorial';render()};document.querySelector('#rc63Achievements').onclick=()=>{view='rc63Achievements';render()};if(newly[0])setTimeout(()=>toast(newly[0]),80)}
function enhanceAdult(){const card=document.querySelector('.card.adult');if(!card||card.querySelector('.rc63-family-block'))return;awardAchievements();const skills=C(),codes=[...new Set(skills.flatMap(s=>s.bncc||[]).filter(Boolean))];const prereq=state.grade==='2º Ano'?1:0;const block=document.createElement('section');block.className='rc63-family-block';block.innerHTML=`<h2>Rastreabilidade pedagógica e conquistas</h2><p>O mapa abaixo usa a BNCC da etapa e identifica separadamente retomadas de pré-requisitos, evitando apresentar revisão como habilidade nova.</p><div class="rc63-bncc-grid"><div><b>${skills.length}</b><small>habilidades/vivências nesta etapa</small></div><div><b>${codes.length}</b><small>códigos BNCC rastreados</small></div><div><b>${unlockedCount()}/${ACH.length}</b><small>conquistas desbloqueadas</small></div></div>${prereq?`<div class="rc63-prereq"><b>Pré-requisito explicitado:</b> ordem alfabética retoma EF01LP10 no 2º Ano como revisão funcional; não é rotulada como habilidade nova do 2º Ano.</div>`:''}<div class="rc63-toolbar"><button type="button" id="rc63AdultTutorial">❔ Rever como jogar</button><button type="button" id="rc63AdultAchievements">🏅 Ver conquistas</button></div>`;const grid=card.querySelector('.adult-grid');(grid||card).insertAdjacentElement(grid?'beforebegin':'beforeend',block);document.querySelector('#rc63AdultTutorial').onclick=()=>{state.rc63.tutorialStep=0;view='rc63Tutorial';render()};document.querySelector('#rc63AdultAchievements').onclick=()=>{view='rc63Achievements';render()}}
function portalUrl(){try{const u=new URL(window.INTELECTUS_ACCESS_CONFIG?.checkoutUrl||'https://www.portalintelectus.com.br/contratar');return u.href}catch(_){return'https://www.portalintelectus.com.br/contratar'}}
function enhanceAccess(){const offer=document.querySelector('.access-offer');if(!offer||offer.querySelector('.rc63-commercial-note'))return;const note=document.createElement('div');note.className='rc63-commercial-note';note.textContent='Planos, pagamento, renovação, combos e licenças familiares ou escolares são administrados exclusivamente no Portal Intelectus.';offer.appendChild(note);const statusTitle=document.querySelector('.access-status h2')?.textContent||'';if(statusTitle.includes('Período gratuito'))writeTrialShadow();const start=document.querySelector('#accessStartTrial');if(start)checkTrialShadow().then(exists=>{if(!exists||!start.isConnected)return;start.disabled=true;start.setAttribute('aria-disabled','true');const warn=document.createElement('div');warn.className='rc63-shadow-warning';warn.textContent='Este navegador já registra o início de um período gratuito anterior. Para continuar, use uma licença válida. Isso reduz reinícios acidentais do trial, embora a proteção offline não substitua validação central.';start.insertAdjacentElement('afterend',warn)})}

// Offline trial hardening: redundant, non-secret marker in Cache Storage. This raises resistance to casual localStorage-only resets without making false anti-fraud claims.
const SHADOW_CACHE='intelectus-access-shadow-v1',SHADOW_URL='/__intelectus_trial_started_v1__';
async function checkTrialShadow(){try{if(!('caches'in window))return false;const c=await caches.open(SHADOW_CACHE);return !!(await c.match(SHADOW_URL))}catch(_){return false}}
async function writeTrialShadow(){try{if(!('caches'in window))return false;const c=await caches.open(SHADOW_CACHE);await c.put(SHADOW_URL,new Response(JSON.stringify({appId:'intelectus-alfabetizacao',version:1,started:true}),{headers:{'Content-Type':'application/json'}}));return true}catch(_){return false}}
document.addEventListener('click',e=>{if(e.target?.closest?.('#accessStartTrial'))writeTrialShadow()},true);

const RC63_PREV_RENDER=render;
render=function(){
 if(view==='rc63Tutorial')return tutorial();
 if(view==='rc63Achievements')return achievements();
 const out=RC63_PREV_RENDER();
 if(view==='home')enhanceHome();
 if(view==='adult')enhanceAdult();
 if(view==='access')enhanceAccess();
 return out;
};

// PWA shortcuts and keyboard-first skip navigation.
if(!document.querySelector('.rc63-skip')){const a=document.createElement('a');a.className='rc63-skip';a.href='#view';a.textContent='Pular para o conteúdo';document.body.prepend(a)}
try{const q=new URLSearchParams(location.search),shortcut=q.get('atalho');if(shortcut&&state.onboarded){if(shortcut==='familia')view='adult';else if(shortcut==='conquistas')view='rc63Achievements';else if(shortcut==='continuar')view=state.diagnosticDone?'home':'diagnosticIntro';history.replaceState(null,'',location.pathname);}}
catch(_){}

window.RC63_AUDIT=Object.freeze({version:RC63_VERSION,release:RC63_RELEASE,tutorial:true,achievements:ACH.length,bnccPrerequisiteExplicit:true,commercialPlans:['mensal','anual','escola'],trialShadowHardening:true,privateKeyInClient:false,externalRuntimeDependencies:0,progressStorage:'device-local',productionChanged:false});
document.title='Intelectus Alfabetização — RC63';
render();
})();
