'use strict';
/* Intelectus Alfabetização — RC65 Natural Voice Layer
   - Voz real selecionável via Web Speech API para fala da professora.
   - Áudios pedagógicos controlados permanecem para letras/fonemas/palavras.
   - Sem API paga; fallback automático para o áudio local original.
*/
const RC65_VERSION=64;
const RC65_ORIGINAL_PLAY_ONE=playOne;
const RC65_ORIGINAL_STOP_VOICE=stopVoice;
const RC65_KEY_BY_SRC=new Map(Object.entries(AUDIO).map(([key,src])=>[src,key]));
const RC65_SPEECH_TEXT={
  'prof:praise_1':'Muito bem! Você conseguiu.',
  'prof:praise_2':'Ótimo trabalho! Vamos continuar.',
  'prof:praise_3':'Parabéns! Você está avançando muito bem.',
  'prof:try_1':'Tudo bem. Vamos tentar mais uma vez.',
  'prof:hint_1':'Observe com calma e procure uma pista.',
  'prof:model_1':'Eu vou mostrar um exemplo para ajudar.',
  'prof:finish_1':'Muito bem! Você concluiu esta etapa.',
  'prof:chest_1':'Você encontrou uma nova conquista!',
  'prompt:welcome':'Olá! Vamos aprender juntos?',
  'prompt:touch_letter':'Escute e toque na letra correta.',
  'prompt:same_letter':'Encontre a mesma letra em outra forma.',
  'prompt:listen_word':'Escute a palavra com atenção.',
  'prompt:same_initial_sound':'Qual figura começa com o mesmo som?',
  'prompt:rhyme':'Qual palavra termina com um som parecido?',
  'prompt:first_letter':'Qual é a primeira letra?',
  'prompt:first_syllable':'Qual é o primeiro pedaço da palavra?',
  'prompt:last_syllable':'Qual é o último pedaço da palavra?',
  'prompt:count_syllables':'Quantos pedaços você ouve na palavra?',
  'prompt:join_syllables':'Junte os pedaços e escolha a palavra.',
  'prompt:look_choose_word':'Observe a figura e escolha a palavra correta.',
  'prompt:read_choose_picture':'Leia a palavra e escolha a figura correta.',
  'prompt:scene_choose_sentence':'Observe a cena e escolha a frase correta.',
  'prompt:read_choose_scene':'Leia e escolha a cena correta.',
  'prompt:read_answer':'Leia com atenção e escolha a resposta.',
  'story:c1_historia':'Lia ganhou uma bola e foi brincar no quintal.',
  'story:c1_pergunta':'O que Lia ganhou?',
  'story:c2_historia':'O sapo pulou no lago para nadar.',
  'story:c2_pergunta':'Onde o sapo pulou?',
  'story:c3_historia':'Começou a chover. O gato correu para dentro da casa.',
  'story:c3_pergunta':'Por que o gato entrou na casa?'
};

state.voiceEngine=state.voiceEngine==='original'?'original':'system';
state.speechVoiceURI=typeof state.speechVoiceURI==='string'?state.speechVoiceURI:'';
state.speechRate=Number.isFinite(Number(state.speechRate))?Math.min(1.18,Math.max(.78,Number(state.speechRate))):.94;
state.rcVoiceVersion=RC65_VERSION;
safeSave();

function RC65_speechAvailable(){return 'speechSynthesis' in window&&'SpeechSynthesisUtterance' in window}
function RC65_qualityScore(v){
  const name=(v.name||'').toLowerCase(),lang=(v.lang||'').toLowerCase();
  let score=0;
  if(lang==='pt-br')score+=100;else if(lang.startsWith('pt'))score+=70;
  if(/natural|neural|premium|enhanced|melhorada|siri/.test(name))score+=45;
  if(/google|microsoft|apple|luciana|joana|francisca|felipe|maria/.test(name))score+=25;
  if(v.localService)score+=8;
  return score;
}
function RC65_voices(){
  if(!RC65_speechAvailable())return[];
  return window.speechSynthesis.getVoices().filter(v=>String(v.lang||'').toLowerCase().startsWith('pt')).sort((a,b)=>RC65_qualityScore(b)-RC65_qualityScore(a)||String(a.name).localeCompare(String(b.name),'pt-BR'));
}
function RC65_selectedVoice(){
  const list=RC65_voices();
  if(!list.length)return null;
  return list.find(v=>v.voiceURI===state.speechVoiceURI)||list[0];
}
function RC65_voiceLabel(v){
  const kind=v.localService?'offline':'sistema/navegador';
  const quality=/natural|neural|premium|enhanced|melhorada|siri/i.test(v.name||'')?' · natural':'';
  return `${v.name} · ${v.lang} · ${kind}${quality}`;
}
function RC65_speak(text,sequence=voiceSequence){
  if(!text||sequence!==voiceSequence||voiceLevel===0||!RC65_speechAvailable())return Promise.resolve(false);
  const voice=RC65_selectedVoice();
  if(!voice)return Promise.resolve(false);
  return new Promise(resolve=>{
    let settled=false,timer=null;
    const utter=new SpeechSynthesisUtterance(String(text));
    utter.voice=voice;utter.lang=voice.lang||'pt-BR';utter.rate=state.speechRate;utter.pitch=1;utter.volume=voiceLevel/100;
    const finish=ok=>{if(settled)return;settled=true;if(timer)clearTimeout(timer);utter.onend=null;utter.onerror=null;if(sequence===voiceSequence)duck(false);resolve(ok)};
    utter.onstart=()=>duck(true);
    utter.onend=()=>finish(true);
    utter.onerror=()=>finish(false);
    timer=setTimeout(()=>{try{window.speechSynthesis.cancel()}catch(e){}finish(false)},20000);
    try{window.speechSynthesis.speak(utter)}catch(e){finish(false)}
  });
}
function RC65_testVoice(){
  stopVoice();
  const sequence=voiceSequence;
  if(state.voiceEngine==='original')return RC65_ORIGINAL_PLAY_ONE(AUDIO['prof:praise_1'],sequence);
  return RC65_speak('Olá! Eu sou sua professora virtual. Vamos aprender juntos, com calma e alegria.',sequence).then(ok=>ok||RC65_ORIGINAL_PLAY_ONE(AUDIO['prof:praise_1'],sequence));
}

stopVoice=function(){
  try{if(RC65_speechAvailable())window.speechSynthesis.cancel()}catch(e){}
  return RC65_ORIGINAL_STOP_VOICE();
};
playOne=function(src,sequence=voiceSequence){
  const key=RC65_KEY_BY_SRC.get(src),text=key&&RC65_SPEECH_TEXT[key];
  if(state.voiceEngine==='system'&&text&&RC65_speechAvailable()){
    return RC65_speak(text,sequence).then(ok=>ok?true:RC65_ORIGINAL_PLAY_ONE(src,sequence));
  }
  return RC65_ORIGINAL_PLAY_ONE(src,sequence);
};

function RC65_voiceOptionsHtml(){
  const list=RC65_voices();
  if(!RC65_speechAvailable())return '<option value="">Voz natural não disponível neste navegador</option>';
  if(!list.length)return '<option value="">Carregando vozes em português…</option>';
  return '<option value="">Automática — melhor voz disponível</option>'+list.map(v=>`<option value="${escapeHtml(v.voiceURI)}" ${state.speechVoiceURI===v.voiceURI?'selected':''}>${escapeHtml(RC65_voiceLabel(v))}</option>`).join('');
}
RC43_voiceControlsHtml=function(compact=false){
  const system=state.voiceEngine!=='original';
  return `<div class="rc43-voice-choice rc64-voice-choice ${compact?'compact':''}" aria-label="Escolha da voz da professora">
    <div class="rc43-control-title">Voz da professora</div>
    <p class="rc64-voice-intro">Escolha uma voz real disponível no aparelho. Letras, fonemas e palavras de treino mantêm o áudio pedagógico controlado para preservar a pronúncia.</p>
    <div class="rc64-engine-row" role="group" aria-label="Tipo de voz">
      <button type="button" class="rc64-engine ${system?'sel':''}" data-rc64-engine="system" aria-pressed="${system}"><b>✨ Voz natural</b><small>usa a voz escolhida do aparelho</small></button>
      <button type="button" class="rc64-engine ${!system?'sel':''}" data-rc64-engine="original" aria-pressed="${!system}"><b>🎧 Áudio original</b><small>mantém a locução pedagógica gravada</small></button>
    </div>
    <label class="rc64-field">Escolher voz em português
      <select class="rc64-voice-select" ${system?'':'disabled'}>${RC65_voiceOptionsHtml()}</select>
    </label>
    <label class="rc64-field">Velocidade da professora <output class="rc64-rate-out">${state.speechRate.toFixed(2)}×</output>
      <input class="rc64-rate" type="range" min="0.78" max="1.18" step="0.02" value="${state.speechRate}" ${system?'':'disabled'}>
    </label>
    <button type="button" class="soft rc64-test-voice">▶ Ouvir esta voz</button>
    <p class="rc64-voice-note">Sem API paga da Intelectus. Algumas vozes do sistema podem precisar de internet; se falharem, o aplicativo volta automaticamente ao áudio local.</p>
  </div>`;
};
function RC65_refreshVoiceSelects(scope=document){
  scope.querySelectorAll('.rc64-voice-select').forEach(select=>{const before=select.value;select.innerHTML=RC65_voiceOptionsHtml();if(state.speechVoiceURI&&[...select.options].some(o=>o.value===state.speechVoiceURI))select.value=state.speechVoiceURI;else if(before&&[...select.options].some(o=>o.value===before))select.value=before;});
}
RC43_bindVoiceControls=function(scope=document){
  scope.querySelectorAll('[data-rc64-engine]').forEach(btn=>btn.onclick=()=>{
    state.voiceEngine=btn.dataset.rc64Engine==='original'?'original':'system';safeSave();stopVoice();
    scope.querySelectorAll('[data-rc64-engine]').forEach(x=>{const on=x.dataset.rc64Engine===state.voiceEngine;x.classList.toggle('sel',on);x.setAttribute('aria-pressed',String(on));});
    scope.querySelectorAll('.rc64-voice-select,.rc64-rate').forEach(x=>x.disabled=state.voiceEngine==='original');
    RC65_testVoice();
  });
  scope.querySelectorAll('.rc64-voice-select').forEach(select=>select.onchange=()=>{state.speechVoiceURI=select.value;safeSave();stopVoice();RC65_testVoice()});
  scope.querySelectorAll('.rc64-rate').forEach(range=>range.oninput=()=>{state.speechRate=Number(range.value);safeSave();scope.querySelectorAll('.rc64-rate-out').forEach(o=>o.textContent=state.speechRate.toFixed(2)+'×');stopVoice()});
  scope.querySelectorAll('.rc64-test-voice').forEach(btn=>btn.onclick=()=>RC65_testVoice());
  RC65_refreshVoiceSelects(scope);
};

if(RC65_speechAvailable()){
  const refresh=()=>RC65_refreshVoiceSelects(document);
  if(typeof window.speechSynthesis.addEventListener==='function')window.speechSynthesis.addEventListener('voiceschanged',refresh);
  else window.speechSynthesis.onvoiceschanged=refresh;
  window.speechSynthesis.getVoices();
}
