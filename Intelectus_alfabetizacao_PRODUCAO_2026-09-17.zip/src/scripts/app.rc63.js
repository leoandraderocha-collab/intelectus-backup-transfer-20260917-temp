'use strict';

/* ===== legacy-script ===== */
const LOGO="/assets/7dce54df63ef838ede7280bb14b8bceae901beba1dcddc2f94ff6c21ad3a3384.png";const MASCOT="/assets/eab27c74f971191834322932a027cb1e49084835a7ff05c1883b470609fdb0f4.png";
const TEACHER="/assets/e16a2f228739d95a46bfa4b2c38c8e9d835110c86ee507ee619ed849aa87575a.webp";const MUSIC="/assets/7d573ece680cfdae0041258f117efe4ca40686c73f4dd22a549c78a6e5373d2c.mp3";const STORE=(()=>{try{const s=window.localStorage;const k='__intelectus_storage_probe__';s.setItem(k,'1');s.removeItem(k);return s}catch(e){const mem=Object.create(null);return{getItem:k=>Object.prototype.hasOwnProperty.call(mem,k)?mem[k]:null,setItem:(k,v)=>{mem[k]=String(v)},removeItem:k=>{delete mem[k]},clear:()=>{for(const k of Object.keys(mem))delete mem[k]},key:i=>Object.keys(mem)[i]??null,get length(){return Object.keys(mem).length}}}})();const APPKEY="intelectusAlfabetizacaoV41Mastery";const SPLASH_TITLE="Aprender a ler pode ser uma aventura.";const SPLASH_COPY="Brincadeiras curtas, progressivas e com bastante repetição inteligente — sempre no ponto certo.";const GRADES=["Pré-escola","1º Ano","2º Ano"];const worlds=[{"id": "letters", "name": "Vila das Letras", "subtitle": "Reconhecer, nomear e relacionar letras", "icon": "🔤", "color": "#dff7ff", "bncc": ["EF01LP04", "EF01LP10", "EF01LP11"], "lesson": {"title": "Primeiro, conhecemos as letras.", "text": "A criança vê a mesma letra em maiúscula, minúscula e entre outros sinais. O som e o nome ajudam a fixar.", "examples": [["A a", "mesma letra"], ["B b", "duas formas"], ["A ? 7", "letra x sinais"]], "audio": ["/assets/1f36f2dc5a22627f5ef2410a9754712bc9b9976fe3d2104db82c98933aef9ff4.mp3", "/assets/8f8af9c00f9ff411e24acfff64044378fbcce0dcb4a3cd9ac04dc42d936fbdfb.mp3"]}}, {"id": "sounds", "name": "Floresta dos Sons", "subtitle": "Ouvir, comparar e brincar com sons da fala", "icon": "👂", "color": "#fff3bd", "bncc": ["EF01LP05", "EF01LP09", "EF01LP13"], "lesson": {"title": "O ouvido vem junto com os olhos.", "text": "A criança percebe sons iniciais, finais e rimas antes de depender da leitura.", "examples": [["⚽", "BOLA"], ["🦆", "PATO"], ["🍬", "BALA"]], "audio": ["/assets/2534d8511df013a3a67b43b860d01496b9abbcba8a2444c8381bbce2df382bff.mp3", "/assets/dd1023a6b448be9160b14ae866fed764b35a48a126d077ee4cb523239845f100.mp3"]}}, {"id": "graphemes", "name": "Ponte Som + Letra", "subtitle": "Relacionar fonemas e grafemas", "icon": "🌉", "color": "#e6e0ff", "bncc": ["EF01LP07", "EF01LP08"], "lesson": {"title": "Agora ligamos o som à letra.", "text": "A palavra é ouvida e a criança procura a letra que representa o som inicial.", "examples": [["🐄", "VACA → V"], ["⚽", "BOLA → B"], ["🦆", "PATO → P"]], "audio": ["/assets/dd1023a6b448be9160b14ae866fed764b35a48a126d077ee4cb523239845f100.mp3", "/assets/1c6d828fc67a70160039c1efd4f50212eca02204bc5079e6e558080f0b57f3a1.mp3"]}}, {"id": "syllables", "name": "Ilha das Sílabas", "subtitle": "Segmentar, contar e juntar sílabas", "icon": "🏝️", "color": "#ffe5f0", "bncc": ["EF01LP06", "EF01LP08", "EF02LP02"], "lesson": {"title": "Palavras podem ser divididas em pedaços sonoros.", "text": "Primeiro ouvimos e batemos os pedaços; depois juntamos sílabas para formar palavras.", "examples": [["⚽", "BO + LA"], ["🏠", "CA + SA"], ["🍌", "BA + NA + NA"]], "audio": ["/assets/dd1023a6b448be9160b14ae866fed764b35a48a126d077ee4cb523239845f100.mp3", "/assets/8107a400eaeabd072525a2802e294f88243660ccff03325b8b0926ad31aac27b.mp3"]}}, {"id": "words", "name": "Cidade das Palavras", "subtitle": "Decodificar e reconhecer palavras", "icon": "🏘️", "color": "#def6df", "bncc": ["EF12LP01", "EF02LP03", "EF02LP04"], "lesson": {"title": "As sílabas agora viram palavras inteiras.", "text": "A criança associa palavra, som e imagem em diferentes combinações.", "examples": [["🐱", "GATO"], ["🏠", "CASA"], ["🌙", "LUA"]], "audio": ["/assets/c0eb509d0d2522060ce3afb673ccc5b96d744b4e135fe727147ce67b0092b133.mp3"]}}, {"id": "sentences", "name": "Castelo das Frases", "subtitle": "Ler frases simples com apoio visual", "icon": "🏰", "color": "#e5efff", "bncc": ["EF01LP01", "EF01LP12", "EF12LP01"], "lesson": {"title": "Palavras juntas constroem uma ideia.", "text": "As frases são curtas e acompanhadas por cenas para apoiar a compreensão.", "examples": [["🐱💤", "O GATO DORME."], ["🦆🌊", "O PATO NADA."], ["☀️✨", "O SOL BRILHA."]], "audio": ["/assets/29d32cff2a065c22424e53eb14e3ba5e1e2dfbd527dd2e19e1088e8d405ecba1.mp3"]}}, {"id": "comprehension", "name": "Tesouro da Leitura", "subtitle": "Compreender histórias e informações", "icon": "📚", "color": "#fff0c7", "bncc": ["EF12LP02", "EF15LP18"], "lesson": {"title": "Ler é construir sentido.", "text": "A criança escuta ou lê pequenos textos e responde usando pistas do texto e das imagens.", "examples": [["📖", "ouvir/ler"], ["❓", "pensar"], ["💡", "responder"]], "audio": ["/assets/64a5f9d76712ca46c61c4da3d415c06a18f2cf633575ce31bc32a1bacdec76a5.mp3", "/assets/95e36b745b1d3d4d71c36ff3a4056df2095ed41443127fa3f2dd998da27e7fa7.mp3"]}}];const reqs=[{"attempts": 50, "unique": 36, "accuracy": 72}, {"attempts": 30, "unique": 15, "accuracy": 72}, {"attempts": 30, "unique": 16, "accuracy": 72}, {"attempts": 36, "unique": 24, "accuracy": 72}, {"attempts": 30, "unique": 22, "accuracy": 72}, {"attempts": 18, "unique": 5, "accuracy": 72}, {"attempts": 15, "unique": 5, "accuracy": 70}];const CUSTOM_PICS={
MESA:`<svg viewBox="0 0 120 100" aria-hidden="true"><defs><linearGradient id="t" x1="0" x2="1"><stop stop-color="#d68a45"/><stop offset="1" stop-color="#9b552b"/></linearGradient></defs><rect x="18" y="36" width="84" height="18" rx="7" fill="url(#t)"/><rect x="25" y="51" width="10" height="38" rx="5" fill="#754028"/><rect x="85" y="51" width="10" height="38" rx="5" fill="#754028"/><rect x="44" y="24" width="28" height="12" rx="4" fill="#58b9e8"/><path d="M75 33c7-15 20-10 20 0z" fill="#7ccf59"/></svg>`,
TATU:`<svg viewBox="0 0 120 100" aria-hidden="true"><defs><linearGradient id="a" x1="0" x2="1"><stop stop-color="#d6a46b"/><stop offset="1" stop-color="#8c5a38"/></linearGradient></defs><ellipse cx="57" cy="57" rx="38" ry="25" fill="url(#a)"/><path d="M30 40q27-24 55 2" fill="none" stroke="#6f432c" stroke-width="6"/><path d="M40 36v43M52 31v51M64 31v51M76 35v43" stroke="#f0cf9d" stroke-width="4" opacity=".9"/><ellipse cx="93" cy="58" rx="16" ry="12" fill="#b67a4e"/><circle cx="99" cy="54" r="2.5" fill="#1f2f3a"/><path d="M18 62q-13 7-5 12q10-1 20-4" fill="#9e6844"/><path d="M38 79l-7 11M70 80l6 10" stroke="#6f432c" stroke-width="6" stroke-linecap="round"/></svg>`,
SACO:`<svg viewBox="0 0 120 100" aria-hidden="true"><defs><linearGradient id="s" x1="0" x2="1"><stop stop-color="#e4b86d"/><stop offset="1" stop-color="#b87a32"/></linearGradient></defs><path d="M43 17h34l-7 16q22 18 22 43c0 18-14 22-32 22S28 94 28 76c0-25 22-43 22-43z" fill="url(#s)" stroke="#9b6429" stroke-width="4"/><path d="M43 32h34M39 36q21 8 42 0" fill="none" stroke="#8b5a27" stroke-width="4"/><path d="M52 58q8-10 16 0M60 52v27" stroke="#f5e2b7" stroke-width="5" stroke-linecap="round"/></svg>`,
TUBO:`<svg viewBox="0 0 120 100" aria-hidden="true"><defs><linearGradient id="p" x1="0" x2="1"><stop stop-color="#62d4ed"/><stop offset=".55" stop-color="#2195cf"/><stop offset="1" stop-color="#116da6"/></linearGradient></defs><path d="M24 30h53q19 0 19 19v18" fill="none" stroke="url(#p)" stroke-width="25" stroke-linecap="round"/><ellipse cx="23" cy="30" rx="13" ry="16" fill="#8be2f3" stroke="#167eae" stroke-width="4"/><ellipse cx="96" cy="67" rx="13" ry="16" fill="#8be2f3" stroke="#167eae" stroke-width="4"/></svg>`,
MULA:`<svg viewBox="0 0 120 100" aria-hidden="true"><defs><linearGradient id="m" x1="0" x2="1"><stop stop-color="#b78558"/><stop offset="1" stop-color="#80543a"/></linearGradient></defs><ellipse cx="55" cy="59" rx="36" ry="22" fill="url(#m)"/><path d="M82 52q7-23 17-19q11 4 4 26" fill="#9f704d"/><path d="M91 34l-2-22q9 3 13 18M80 36l-8-20q9 0 15 17" fill="#9f704d" stroke="#70462f" stroke-width="3"/><circle cx="98" cy="47" r="2.5" fill="#192934"/><path d="M28 55q-17-8-19 2q8 7 20 8" fill="none" stroke="#6f4833" stroke-width="6" stroke-linecap="round"/><path d="M37 76l-4 17M68 77l3 16" stroke="#68422f" stroke-width="6" stroke-linecap="round"/></svg>`};
function wordPic(value,fallback){const u=String(value||'').toUpperCase();for(const k of Object.keys(CUSTOM_PICS))if(u.includes(k))return CUSTOM_PICS[k];return fallback}
const WORDS=[{"w": "BALA", "g": "B", "sound": "b", "sy": ["BA", "LA"], "pic": "🍬", "level": 1}, {"w": "BOLA", "g": "B", "sound": "b", "sy": ["BO", "LA"], "pic": "⚽", "level": 1}, {"w": "BOCA", "g": "B", "sound": "b", "sy": ["BO", "CA"], "pic": "👄", "level": 1}, {"w": "BULE", "g": "B", "sound": "b", "sy": ["BU", "LE"], "pic": "🫖", "level": 1}, {"w": "DADO", "g": "D", "sound": "d", "sy": ["DA", "DO"], "pic": "🎲", "level": 1}, {"w": "DEDO", "g": "D", "sound": "d", "sy": ["DE", "DO"], "pic": "☝️", "level": 1}, {"w": "FADA", "g": "F", "sound": "f", "sy": ["FA", "DA"], "pic": "🧚", "level": 1}, {"w": "FITA", "g": "F", "sound": "f", "sy": ["FI", "TA"], "pic": "🎀", "level": 1}, {"w": "FOCA", "g": "F", "sound": "f", "sy": ["FO", "CA"], "pic": "🦭", "level": 1}, {"w": "LATA", "g": "L", "sound": "l", "sy": ["LA", "TA"], "pic": "🥫", "level": 1}, {"w": "LOBO", "g": "L", "sound": "l", "sy": ["LO", "BO"], "pic": "🐺", "level": 1}, {"w": "LUA", "g": "L", "sound": "l", "sy": ["LU", "A"], "pic": "🌙", "level": 1}, {"w": "MALA", "g": "M", "sound": "m", "sy": ["MA", "LA"], "pic": "🧳", "level": 1}, {"w": "MESA", "g": "M", "sound": "m", "sy": ["ME", "SA"], "pic": "🪑", "level": 1}, {"w": "MOTO", "g": "M", "sound": "m", "sy": ["MO", "TO"], "pic": "🏍️", "level": 1}, {"w": "MULA", "g": "M", "sound": "m", "sy": ["MU", "LA"], "pic": "🐴", "level": 1}, {"w": "NAVE", "g": "N", "sound": "n", "sy": ["NA", "VE"], "pic": "🚀", "level": 1}, {"w": "NARIZ", "g": "N", "sound": "n", "sy": ["NA", "RIZ"], "pic": "👃", "level": 2}, {"w": "NUVEM", "g": "N", "sound": "n", "sy": ["NU", "VEM"], "pic": "☁️", "level": 2}, {"w": "PATO", "g": "P", "sound": "p", "sy": ["PA", "TO"], "pic": "🦆", "level": 1}, {"w": "PENA", "g": "P", "sound": "p", "sy": ["PE", "NA"], "pic": "🪶", "level": 1}, {"w": "PIPA", "g": "P", "sound": "p", "sy": ["PI", "PA"], "pic": "🪁", "level": 1}, {"w": "POTE", "g": "P", "sound": "p", "sy": ["PO", "TE"], "pic": "🫙", "level": 1}, {"w": "TATU", "g": "T", "sound": "t", "sy": ["TA", "TU"], "pic": "🦔", "level": 1}, {"w": "TELA", "g": "T", "sound": "t", "sy": ["TE", "LA"], "pic": "🖥️", "level": 1}, {"w": "TUBO", "g": "T", "sound": "t", "sy": ["TU", "BO"], "pic": "🧪", "level": 1}, {"w": "VACA", "g": "V", "sound": "v", "sy": ["VA", "CA"], "pic": "🐄", "level": 1}, {"w": "VELA", "g": "V", "sound": "v", "sy": ["VE", "LA"], "pic": "🕯️", "level": 1}, {"w": "VASO", "g": "V", "sound": "v", "sy": ["VA", "SO"], "pic": "🏺", "level": 1}, {"w": "VOVÓ", "g": "V", "sound": "v", "sy": ["VO", "VÓ"], "pic": "👵", "level": 1}, {"w": "CASA", "g": "C", "sound": "k", "sy": ["CA", "SA"], "pic": "🏠", "level": 1}, {"w": "CAMA", "g": "C", "sound": "k", "sy": ["CA", "MA"], "pic": "🛏️", "level": 1}, {"w": "COPO", "g": "C", "sound": "k", "sy": ["CO", "PO"], "pic": "🥤", "level": 1}, {"w": "GATO", "g": "G", "sound": "g", "sy": ["GA", "TO"], "pic": "🐱", "level": 1}, {"w": "GALO", "g": "G", "sound": "g", "sy": ["GA", "LO"], "pic": "🐓", "level": 1}, {"w": "GOTA", "g": "G", "sound": "g", "sy": ["GO", "TA"], "pic": "💧", "level": 1}, {"w": "SAPO", "g": "S", "sound": "s", "sy": ["SA", "PO"], "pic": "🐸", "level": 1}, {"w": "SACO", "g": "S", "sound": "s", "sy": ["SA", "CO"], "pic": "🎒", "level": 1}, {"w": "SINO", "g": "S", "sound": "s", "sy": ["SI", "NO"], "pic": "🔔", "level": 1}, {"w": "BANANA", "g": "B", "sound": "b", "sy": ["BA", "NA", "NA"], "pic": "🍌", "level": 2}, {"w": "MACACO", "g": "M", "sound": "m", "sy": ["MA", "CA", "CO"], "pic": "🐒", "level": 2}, {"w": "TOMATE", "g": "T", "sound": "t", "sy": ["TO", "MA", "TE"], "pic": "🍅", "level": 2}];const SENTENCES=[{"scene":"🐱💤","good":"O GATO DORME.","bad":["O GATO CORRE.","O PATO NADA."]},{"scene":"🦆🌊","good":"O PATO NADA.","bad":["O PATO DORME.","A BOLA ROLA."]},{"scene":"👧⚽","good":"LIA TEM UMA BOLA.","bad":["LIA TEM UM GATO.","LIA VÊ A LUA."]},{"scene":"☀️✨","good":"O SOL BRILHA.","bad":["A LUA BRILHA.","A CASA É ALTA."]},{"scene":"👵🕯️","good":"VOVÓ ACENDE A VELA.","bad":["VOVÓ SEGURA A BOLA.","O GATO VÊ A VELA."]},{"scene":"🐸🌿","good":"O SAPO PULA.","bad":["O SAPO VOA.","A VACA NADA."]},{"scene":"🐒🍌","good":"O MACACO TEM UMA BANANA.","bad":["O MACACO TEM UMA PIPA.","O PATO TEM UMA BOLA."]},{"scene":"🐄🌱","good":"A VACA COME CAPIM.","bad":["A VACA LÊ UM LIVRO.","O GATO ACENDE A VELA."]},{"scene":"🌙🏠","good":"A LUA APARECE NO CÉU.","bad":["A LUA ESTÁ NA MESA.","O SOL DORME NA CASA."]},{"scene":"🪁🌤️","good":"A PIPA VOA ALTO.","bad":["A PIPA NADA NO LAGO.","A MESA VOA ALTO."]},{"scene":"🐓🌅","good":"O GALO CANTA CEDO.","bad":["O GALO DORME NO LAGO.","A FOCA CANTA CEDO."]},{"scene":"🏍️🛣️","good":"A MOTO PASSA NA RUA.","bad":["A MOTO VOA NO CÉU.","O PATO PASSA NA RUA."]},{"scene":"🎲🪑","good":"O DADO ESTÁ NA MESA.","bad":["O DADO ESTÁ NO LAGO.","A MESA ESTÁ NO DADO."]},{"scene":"🪁👧","good":"LIA SOLTA A PIPA.","bad":["LIA DORME NA PIPA.","A PIPA SEGURA LIA."]},{"scene":"🐺🌙","good":"O LOBO VÊ A LUA.","bad":["O LOBO VÊ A MESA.","A LUA VÊ O LOBO."]},{"scene":"🍅🪑","good":"O TOMATE ESTÁ NA MESA.","bad":["O TOMATE VOA NO CÉU.","A MESA NADA NO LAGO."]},{"scene":"🚀🌙","good":"A NAVE VAI PARA A LUA.","bad":["A NAVE DORME NA CAMA.","A LUA VAI PARA A NAVE."]},{"scene":"🫖🪑","good":"O BULE ESTÁ NA MESA.","bad":["O BULE VOA ALTO.","A MESA ESTÁ NO BULE."]},{"scene":"🐒🍌","good":"O MACACO COME A BANANA.","bad":["O MACACO COME A MOTO.","A BANANA COME O MACACO."]},{"scene":"🪶🌬️","good":"A PENA VOA.","bad":["A PENA NADA.","A PENA É UMA MOTO."]},{"scene":"☁️🌙","good":"A NUVEM COBRE A LUA.","bad":["A NUVEM ESTÁ NA MESA.","A LUA COME A NUVEM."]},{"scene":"🐄🏠","good":"A VACA FICA PERTO DA CASA.","bad":["A VACA VOA SOBRE A CASA.","A CASA COME A VACA."]},{"scene":"🕯️🪑","good":"A VELA ESTÁ NA MESA.","bad":["A VELA NADA NO LAGO.","A MESA VOA COM A VELA."]},{"scene":"🐴🌱","good":"A MULA COME CAPIM.","bad":["A MULA LÊ UM LIVRO.","O CAPIM COME A MULA."]}];const AUDIO={"prof:praise_1": "/assets/477693c23fc13deaadfdf4a9332531a1f4f1b87aff406692519710793b736db2.mp3", "prof:praise_2": "/assets/46156a4128683f3877b5cba508cdcc8fd303c377f5e8922d2f75dfd738d9c028.mp3", "prof:praise_3": "/assets/8045ac7fea18cc659e0e2506174d8ea7ce004c8b853a776f5202a16eeea744d8.mp3", "prof:try_1": "/assets/39c1b9f99b48313966ab6ee271862d2acd9cd761357c62e283d1fb8f0033777a.mp3", "prof:hint_1": "/assets/7dbbaaa5b7b0694ca6348972ac703f5773dbb5c38297d0818ebb9590dee184f4.mp3", "prof:model_1": "/assets/66812023737750572cbda272032a67fbc641ff6dd40fdba405a0cf22d95531e8.mp3", "prof:finish_1": "/assets/4126e7aff37e397367c42ff6e6a56af4734b63e991a39838070f93546ce5238c.mp3", "prof:chest_1": "/assets/c9e162caaa691affe65d9627297a385a82d5e6b0d1dafb87aa5e0bd031958ca3.mp3", "prompt:welcome": "/assets/7f17de61e1c5c730033ea1b7b1522d13bb667b051a9c5bd0304f99ea6c6bdda4.mp3", "prompt:touch_letter": "/assets/101ccc9210c8a1796043d0ec696b93ad361df0213250d595fa3dd7db621ead10.mp3", "prompt:same_letter": "/assets/fa4dc16a59f6e648f37c3b3d656e13f92455e4889b4f6778de5f0ef4b11e39b8.mp3", "prompt:listen_word": "/assets/8c7b0371925b5b6df889233e21783f5e03806eb5cfcf8b04e96f90a333c28a21.mp3", "prompt:same_initial_sound": "/assets/2a855dc5947d21925077271434c67c02180d47ccea714212b59d3ac0de843434.mp3", "prompt:rhyme": "/assets/a972ab27aa3b9d0c5f5ff491f8058df9421aee6106a9c44ca0f027db626f205e.mp3", "prompt:first_letter": "/assets/7960c738f39eb83542d5772b5b3cf7c00c6505b972f23ff2285d97ec6173665a.mp3", "prompt:first_syllable": "/assets/8bb500e9d20584afa47d466c731fc156c6a4f5da47a304cf020170c14df322b1.mp3", "prompt:last_syllable": "/assets/89b67d5b9cf8bf43d2c8be77b1f60c75d41e4363dc234910f3be16ec92efc077.mp3", "prompt:count_syllables": "/assets/6b5919d7c39ee690370cb825bdb16c9ba483b7ce39cc080af384b54aaf1d07d0.mp3", "prompt:join_syllables": "/assets/c89e5a66774bd3545e4cba072a4fc7b350733bdf13d95311473a8d45947c0c66.mp3", "prompt:look_choose_word": "/assets/01ef13a6caac5099e5b06f6689429e714b81448f45c45753bd3aa6473fa40594.mp3", "prompt:read_choose_picture": "/assets/c4309df0f05d5d135bb53d9705f61c5e941010af2b3dcec7cee26ffbd9529464.mp3", "prompt:scene_choose_sentence": "/assets/2ca04a85e50ac7b53676d8097fa921e08170bd426e8555b2c334d829ec4e7e70.mp3", "prompt:read_choose_scene": "/assets/2e9d032cd412a99a2c710c8e0113708669c0a011e281c97099781d4ab418bb1c.mp3", "prompt:read_answer": "/assets/74f3dd512eed03282dc36fb660558b68fb1c33e4b58203123dbc2f29c2536bd2.mp3", "letter:A": "/assets/f454a80b098d474dd836d1137466bf7a1d67772ff8f1e6d83ca0bd1de27d8807.mp3", "letter:B": "/assets/a85fc7e8c43d5e2254b8642205286d7d55b639623233ee8148dea57736bfcd33.mp3", "letter:C": "/assets/023b7e948758613b2e47cbb890a8a946d5a14eb6dff43694675d517d26bc44f6.mp3", "letter:D": "/assets/4d4541484aabd53a9d7afaa37094b99a9815236462ea63a30614f671599f306d.mp3", "letter:E": "/assets/a7f06e8e5840720860ed1ee0315e4a997cc67b3f185207611d65c594884286d2.mp3", "letter:F": "/assets/dfc0a2aec440569446d3a4913a3dbfd1aac594bfc5d710db72e5961d6e068807.mp3", "letter:G": "/assets/f29e4be51997e6182e872a501acc012c364c270a1773d1814d5184481e465eca.mp3", "letter:H": "/assets/6b7b05d8ba6064e1b13d1afe3bb31f7ca53b29b65f932958d6ffa4ca8c51f330.mp3", "letter:I": "/assets/569ae4b7c8ee6eb25c4c467553ee12a1bc74b54526cf87a29068b0af955f9a4a.mp3", "letter:J": "/assets/8efb29bce626b1b3e839b7e9cf68ed3747c2358be54ef475b56c35ef876ab28e.mp3", "letter:K": "/assets/d0197ef4caad7caaac230589eb83ebf2bf72a8e12c2cbf1640e8ad55b5d22d72.mp3", "letter:L": "/assets/76a7087181dc4128ba2a54c33878cb38e1dfaf3d241f96223f648a38ecab994a.mp3", "letter:M": "/assets/569f3719f3d770fef7e9c57c22b64c61aba4bfe9a2447baf39cc0a15cd2b4ef7.mp3", "letter:N": "/assets/fb8e839d084b0cad82b1bc0d745377c86062289d2e20c9a9fbdbddb421dacd36.mp3", "letter:O": "/assets/d27cf5db3fff65cbaedf63c0c7427092268ad7c35c80be80796f75d67b647292.mp3", "letter:P": "/assets/c1aba06db3f67a9d4595cdcd16a33d3006d2496a267c283fc7fd8c23f71c7231.mp3", "letter:Q": "/assets/b1cb44ab6b987ea5950313575d7ed21f33c79714c2975acfd325dfac9ca29222.mp3", "letter:R": "/assets/b6a404d11377f3d6f8e1f4b7bfcb7711cca9a3d7df34d788e42c6550186235b2.mp3", "letter:S": "/assets/6b06c95b90316fe35f0cdcec7337fb12254fc0ec2d5f267ace7a813dafbdbec0.mp3", "letter:T": "/assets/f29e334c0902f46699de742b599f45165f1a7b47fac9d1a449b44874cba8cfbc.mp3", "letter:U": "/assets/a4fe0a49a05313bf68cea224c0ae89dcfa7d55e550e8a044276e28670b4b521e.mp3", "letter:V": "/assets/2d1772280fd2b9b96d81c1758ab35d72436adb0119b15ea8dc9152fd1cdda7a4.mp3", "letter:W": "/assets/d037acc0d3b432b4dfdf7b8e44aa24120cca821326fea3a10129db72e4d1536e.mp3", "letter:X": "/assets/f5f52521fa19b7a76f83e7b52c38f0ce465fd5d0f0a08084e4ea76fc39bf0d29.mp3", "letter:Y": "/assets/bbd9efaeb99be68ecb697351620418c82a1ff5789f5f4f6575dadcc3eb6b74d0.mp3", "letter:Z": "/assets/89bb66d77194b39c277204090c7340fa0e218cc54fa62f011fcd99efbcf23fde.mp3", "word:BALA": "/assets/3c8c6d6cd4982ac7cbfb77e284f3703a748dbd84a0266dc05b76b8192816941a.mp3", "word:BOLA": "/assets/93841cac1e39b76189cb22be3b0cd576f23400cfa5eb3bd7acb4388ef846a729.mp3", "word:BOCA": "/assets/89049a502525e61bd304703e32cc99f8abf541bf3539837e67591fdc649a0295.mp3", "word:BULE": "/assets/5ffcf15dff81237a824fc9a3863917ba5813154aebcfc59b37735a044ec734c0.mp3", "word:DADO": "/assets/93e73e22fbfb59cda4be12e6394c1a1f7c9112a8febaad2ff36b6227acce8254.mp3", "word:DEDO": "/assets/738e3a2147e48149daaa67ed15e1765076932578b9e98eb3a7d79f900afd50f9.mp3", "word:FADA": "/assets/285b61f45d28f7915f2e0cd48a51a8caf43476b774adb7794a2e7baf0f39cb6f.mp3", "word:FITA": "/assets/0262e29c605bee641e757ed7fdf0542b69934f4efef342d530d5ad5bc87af38e.mp3", "word:FOCA": "/assets/eda5e9b8ff01799967efa963cd22cb1564ca3fbc0cf2957583b496ecd192b8d1.mp3", "word:LATA": "/assets/05282bdf3c2460e2adc0d566252df02504793506548d11f4f0b99aadf2f0b1c4.mp3", "word:LOBO": "/assets/304739f1e296e8b529807e0c28067342b6db644350315f942c88641460e76f92.mp3", "word:LUA": "/assets/d68ce5e8e8ab03665633e475f64710e1b2cd3f7b2410afbece6acda4fb0a3ca5.mp3", "word:MALA": "/assets/38f2aefd5dda51480f582526f937af3dad45b76bf2d1cf1404b01fb583374b23.mp3", "word:MESA": "/assets/6e717359d9bd8434bdc3a5d8a404c70be238674dc0a14a1f12d9400471242d07.mp3", "word:MOTO": "/assets/394c06ca00f9720d7a8e649f0a7ab07a5450478f2cd3c588ee9d8565e21758d1.mp3", "word:MULA": "/assets/99ab52001a34db7f02e39e8eb0bf376059329c99f0a393a42eff9b7e1d7d058a.mp3", "word:NAVE": "/assets/9ecba779e23576c5e7db01ce320fec38871848cf198728e39369290f7ae3d2c3.mp3", "word:NARIZ": "/assets/5dbe5fa4b508f279c7c0d3ea8701fb15b9bd1ce7ee08b25acc149c8b141d8462.mp3", "word:NUVEM": "/assets/0b1768d46ddb7d3d6388cf11b5f36f1e65916e527f9828e74b80fa30679ce736.mp3", "word:PATO": "/assets/89911fe342a7816c3d9cb121984ba91d9d7686691e43442c17c251867145b582.mp3", "word:PENA": "/assets/17dfc4a53f22cd1da9dbeb9dad9efb23004006cef61bd332214b2ab965c85d2d.mp3", "word:PIPA": "/assets/48050ffdf4b7445ecd0b4f2604a69d0aff71b1fbcf943cfdc1c9f71548433a51.mp3", "word:POTE": "/assets/0485543592f27eb52cf78bc3cdf5e9924545cab13918fc04f679f9bee140cc9c.mp3", "word:TATU": "/assets/5d8d683bce4a77a112b811a8758b1daffe9bf1d5b09318b90889281453ddfbcd.mp3", "word:TELA": "/assets/375a661f9c2b83f4788c2b0701874b2a98a5ba34bccc63678ac87c484562a5b5.mp3", "word:TUBO": "/assets/9302203b50d37e27115244231b9a8d6681371242eb057f58b62aa4e7309f92cf.mp3", "word:VACA": "/assets/914096bc13ee186e01f5b873ca1e95dc8292b2e54d98ac13257c723e811d902f.mp3", "word:VELA": "/assets/9c0db9dd5a9045b50734b3613454832c669158e5f7a2f607c153973d98cba919.mp3", "word:VASO": "/assets/8ac28dd1e9b722669a49bb437a58085ee1544aa8d5a94c0202cb7f66bbb8f316.mp3", "word:VOVÓ": "/assets/b3d4928018424b1251aa71572a4cffe01acd1a79fe003919783490f26a00f9c6.mp3", "word:CASA": "/assets/321764cb735f291ad32169f128bb2d71dc0bc63928e74dc2918dddd33cc82600.mp3", "word:CAMA": "/assets/8093f0a69725c46f526042afb0a35a07eb40e711aab401aed9c4fdde0af567a5.mp3", "word:COPO": "/assets/a7ba0e6f02d5bd1c965d41beb06ff094a9c105e2ed558a729d465020eb529d1f.mp3", "word:GATO": "/assets/de98a0893666e75bd3f8f624a8852df214c05d9231095923f9751436cf8898f2.mp3", "word:GALO": "/assets/b4c2488709dc1e7776069f97ccc229db6c9a7fa8f536df27eefc52107bddfa1e.mp3", "word:GOTA": "/assets/6645b0e1701126e18379e50ebca85008387e7821a86f7b5543b376c343617370.mp3", "word:SAPO": "/assets/2b96768d7d81a53101ad5e5b904862cc10819399388fae42e62435f273d3ed33.mp3", "word:SACO": "/assets/016e9c51c6654f160432aef41197b64dfb0644b9651b85d1c2863c31392f7cd9.mp3", "word:SINO": "/assets/a6c48b1e57a5958ee4e19732a876141da11c3ba463b4578163fa27cea0a66ae4.mp3", "word:BANANA": "/assets/4fb7da93a3c1fe85c51aef0bb6db4489278ae9b57654b69b53ecd794d8213c71.mp3", "word:MACACO": "/assets/25deccdd91c45e6a65047589b6e082f125b36d29f888e30820e6686c687d60ac.mp3", "word:TOMATE": "/assets/f3706dd87a3af375d6cec7454d27fe027fff6f4f522a5f591c8c270b1f0faa93.mp3", "story:c1_historia": "/assets/d7112fbd1fb6c6fd05e198c9f6138500f0e984ac56c4010dcf520b55512f7bd5.mp3", "story:c1_pergunta": "/assets/80e6f7d5f9b20cfa0596725501e58f3e71ccab6f4fa98412be2323ca0233bd6b.mp3", "story:c2_historia": "/assets/324e6653d69d566039f604afa65b9f5b460a46a3172f2917b230c7fe712e222b.mp3", "story:c2_pergunta": "/assets/a87070ac80f39d0638607fccd13a3825a9aca3df97d289f7251854f8c4580255.mp3", "story:c3_historia": "/assets/252d30a7c29326a9aa73133df24c9b1158b0589fb102abbc9364c4639a94180d.mp3", "story:c3_pergunta": "/assets/8312cb77ad076222acb6683448966ff6a9bef3ba873db664cd22d9453757b468.mp3"};const AUD={praise:[AUDIO['prof:praise_1'],AUDIO['prof:praise_2'],AUDIO['prof:praise_3']],try:[AUDIO['prof:try_1'],AUDIO['prof:hint_1']],model:AUDIO['prof:model_1'],finish:AUDIO['prof:finish_1']};const STATE_DEFAULTS={onboarded:false,name:'',grade:'1º Ano',avatar:'🦊',guide:'Lia',guideAvatar:'👩‍🏫',diagnosticDone:false,diagnosticVersion:3,entryIndex:0,stars:0,stats:{},recent:[],seen:[],bypass:[],daily:0};function loadState(){try{const raw=JSON.parse(STORE.getItem(APPKEY)||'null');if(!raw||typeof raw!=='object')return {...STATE_DEFAULTS};return {...STATE_DEFAULTS,...raw,stats:raw.stats||{},recent:Array.isArray(raw.recent)?raw.recent:[],seen:Array.isArray(raw.seen)?raw.seen:[],bypass:Array.isArray(raw.bypass)?raw.bypass:[]}}catch(e){return {...STATE_DEFAULTS}}}let state=loadState();let view=state.onboarded?(state.diagnosticDone?'home':'diagnosticIntro'):'splash',session=null,current=null,attempt={},diag=null,pendingWorld=0,gateTarget=1;

const $=s=>document.querySelector(s);const $$=s=>[...document.querySelectorAll(s)];
const pick=a=>a[Math.floor(Math.random()*a.length)];const shuffle=a=>[...a].sort(()=>Math.random()-.5);const clamp=(n,a,b)=>Math.max(a,Math.min(b,n));
let voiceAudio=null,musicAudio=null,musicOn=true;
let voiceLevel=clamp(Number(STORE.getItem(APPKEY+':voiceVolume')??100),0,100);
let musicLevel=clamp(Number(STORE.getItem(APPKEY+':musicVolume')||50),0,100);
function musicBase(){return .15*(musicLevel/100)}
function initMusic(src){musicAudio=new Audio(src);musicAudio.loop=true;musicAudio.volume=musicBase();musicOn=STORE.getItem(APPKEY+':music')!=='off';$('#musicFab').textContent=musicOn?'♫':'♩'}
function startMusic(){if(musicOn&&musicAudio){musicAudio.volume=musicBase();musicAudio.play().catch(()=>{})}}
function toggleMusic(){musicOn=!musicOn;STORE.setItem(APPKEY+':music',musicOn?'on':'off');$('#musicFab').textContent=musicOn?'♫':'♩';if(musicOn)startMusic();else musicAudio?.pause()}
function setVoiceLevel(v){voiceLevel=clamp(Number(v),0,100);STORE.setItem(APPKEY+':voiceVolume',String(voiceLevel));if(voiceAudio)voiceAudio.volume=voiceLevel/100}
function setMusicLevel(v){musicLevel=clamp(Number(v),0,100);STORE.setItem(APPKEY+':musicVolume',String(musicLevel));if(musicAudio)musicAudio.volume=musicBase()}
function duck(on){if(musicAudio)musicAudio.volume=musicBase()*(on?.22:1)}
async function playOne(src){if(!src)return false;try{if(voiceAudio){voiceAudio.pause();voiceAudio=null}duck(true);voiceAudio=new Audio(src);voiceAudio.volume=voiceLevel/100;await voiceAudio.play();return await new Promise(r=>{voiceAudio.onended=()=>{duck(false);r(true)};voiceAudio.onerror=()=>{duck(false);r(false)};setTimeout(()=>{duck(false);r(false)},9000)})}catch{duck(false);return false}}
async function playSeq(arr){for(const src of arr||[]){if(src)await playOne(src)}}
function safeSave(){STORE.setItem(APPKEY,JSON.stringify(state))}
function escapeHtml(x){return String(x??'').replace(/[&<>"']/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[m]))}
function day(){return new Date().toISOString().slice(0,10)}
function footer(){return `<div class="footer" role="contentinfo">Intelectus Soluções Pedagógicas — Proposta pedagógica alinhada à BNCC para a Educação Infantil e os Anos Iniciais do Ensino Fundamental.</div>`}
function progressPct(i){const r=masteryReq(i),s=worldStats(i);if(!r)return 100;const p1=Math.min(1,s.attempts/r.attempts),p2=Math.min(1,s.unique/r.unique),p3=Math.min(1,s.accuracy/r.accuracy);return Math.round((p1*.38+p2*.32+p3*.30)*100)}
function worldStats(i){const w=worlds[i],x=state.stats[w.id]||{attempts:0,independent:0,unique:[]};return{...x,unique:(x.unique||[]).length,accuracy:x.attempts?Math.round(x.independent/x.attempts*100):0}}
function gradeProfile(){const g=state.grade||'1º Ano';if(g==='Pré-escola')return{grade:g,session:4,letter:[22,44],sound:[18,32],syllable:[20,36],word:[20,34],sentenceEarly:4,storyEarly:3};if(g==='2º Ano')return{grade:g,session:6,letter:[14,30],sound:[10,20],syllable:[12,24],word:[12,22],sentenceEarly:8,storyEarly:8};return{grade:'1º Ano',session:5,letter:[18,36],sound:[14,26],syllable:[16,30],word:[16,28],sentenceEarly:6,storyEarly:6}}
const MASTERY_BY_GRADE={
'Pré-escola':[{attempts:40,unique:26,accuracy:70},{attempts:26,unique:13,accuracy:70},{attempts:26,unique:14,accuracy:70},{attempts:30,unique:18,accuracy:70},{attempts:26,unique:18,accuracy:70},{attempts:14,unique:4,accuracy:70},{attempts:10,unique:3,accuracy:68}],
'1º Ano':[{attempts:46,unique:30,accuracy:72},{attempts:30,unique:15,accuracy:72},{attempts:30,unique:16,accuracy:72},{attempts:34,unique:22,accuracy:72},{attempts:30,unique:22,accuracy:72},{attempts:18,unique:6,accuracy:72},{attempts:14,unique:5,accuracy:70}],
'2º Ano':[{attempts:34,unique:24,accuracy:74},{attempts:24,unique:12,accuracy:74},{attempts:24,unique:14,accuracy:74},{attempts:28,unique:18,accuracy:74},{attempts:26,unique:18,accuracy:74},{attempts:18,unique:7,accuracy:74},{attempts:16,unique:6,accuracy:72}]};
function masteryReq(i){return (MASTERY_BY_GRADE[state.grade||'1º Ano']||reqs)[i]||reqs[i]}
function sessionGoal(){return gradeProfile().session}
function sentencePool(){const p=gradeProfile(),st=worldStats(5),cap=state.grade==='Pré-escola'?10:state.grade==='1º Ano'?18:SENTENCES.length,base=SENTENCES.slice(0,cap);if(st.attempts<Math.max(10,p.sentenceEarly*2)||st.accuracy<72)return base.slice(0,p.sentenceEarly);return base}
function storyPool(stories){const p=gradeProfile(),st=worldStats(6),cap=state.grade==='Pré-escola'?5:state.grade==='1º Ano'?8:stories.length,base=stories.slice(0,cap);if(st.attempts<Math.max(10,p.storyEarly*2)||st.accuracy<72)return base.slice(0,p.storyEarly);return base}
function mastered(i){if(i<0)return true;const r=masteryReq(i),s=worldStats(i);return s.attempts>=r.attempts&&s.unique>=r.unique&&s.accuracy>=r.accuracy}
function unlocked(i){if(i===0)return true;if(state.entryIndex>=i)return true;if((state.bypass||[]).includes(i))return true;return mastered(i-1)}
function nextWorldIndex(){for(let i=0;i<worlds.length;i++)if(unlocked(i)&&!mastered(i))return i;return worlds.length-1}
function recordTask(task,firstTry){if(session?.gate)return;const w=worlds.find(x=>x.id===task.world),i=worlds.indexOf(w);let x=state.stats[w.id]||{attempts:0,independent:0,unique:[]};x.attempts++;if(firstTry)x.independent++;if(!x.unique.includes(task.key))x.unique.push(task.key);x.unique=x.unique.slice(-250);state.stats[w.id]=x;state.total=(state.total||0)+1;state.daily=(state.dailyDay===day()?state.daily:0)+1;state.dailyDay=day();state.stars=(state.stars||0)+(firstTry?1:0);safeSave()}
function remember(sig){state.recent=state.recent||[];state.recent=[...state.recent.filter(x=>x!==sig),sig].slice(-48)}
function uniqueTask(make){let t;for(let i=0;i<30;i++){t=make();if(!state.recent.includes(t.sig))break}remember(t.sig);return t}
function scheduleRetry(task){if(!session||session.gate||!task)return;session.retryQueue=session.retryQueue||[];if(session.retryQueue.some(x=>x.task?.sig===task.sig))return;session.retryQueue.push({at:(session.done||0)+2,task:{...task}})}
function nextSessionTask(){const q=session?.retryQueue||[],idx=q.findIndex(x=>x.at<=(session.done||0));if(idx>=0){const x=q.splice(idx,1)[0];return{...x.task,sig:`${x.task.sig}:review:${session.done}`,review:true}}return session?.guided?makeGuidedTask(session.world,session.done):makeTask(session.world)}
function hintForTask(t){const g=escapeHtml(state.guide||'Lia');if(!t)return `${g}: tente mais uma vez com calma.`;if(t.world==='letters')return `${g}: compare o formato da letra e ouça novamente antes de tocar.`;if(t.world==='sounds')return `${g}: fale a palavra devagar e preste atenção no som que se repete.`;if(t.world==='graphemes')return `${g}: diga a palavra bem devagar e perceba qual letra aparece no começo.`;if(t.world==='syllables')return `${g}: bata palmas para cada pedaço da palavra e tente de novo.`;if(t.world==='words')return `${g}: observe a figura e compare a palavra do começo ao fim.`;if(t.world==='sentences')return `${g}: observe quem aparece na cena e o que está acontecendo.`;if(t.world==='comprehension')return `${g}: volte ao texto e procure a informação que responde à pergunta.`;return `${g}: tente mais uma vez com calma.`}
function setTop(show=true){const splashOnly=view==='splash';$('#top').classList.toggle('hidden',splashOnly);const actions=$('#top .top-actions');if(actions)actions.classList.toggle('hidden',!show);$('#top').classList.toggle('top-minimal',!show);$('#musicFab').classList.toggle('hidden',!show);if(show){$('#starCount').textContent=state.stars||0}}
function worldArt(id){const A={letters:'<svg class="world-art-svg" viewBox="0 0 96 96" aria-hidden="true"><rect x="12" y="18" width="72" height="60" rx="16" fill="#eefaf3" stroke="#bfe8cf" stroke-width="3"/><path d="M48 28c-8-6-18-6-28-2v42c10-4 20-4 28 2V28Zm0 0c8-6 18-6 28-2v42c-10-4-20-4-28 2V28Z" fill="white" stroke="#0b7b58" stroke-width="3"/><text x="29" y="56" font-size="24" font-weight="900" fill="#0b7b58">A</text><text x="56" y="56" font-size="22" font-weight="800" fill="#173b5e">a</text></svg>',sounds:'<svg class="world-art-svg" viewBox="0 0 96 96" aria-hidden="true"><circle cx="48" cy="48" r="38" fill="#eef8ff"/><path d="M23 50a25 25 0 0 1 50 0" fill="none" stroke="#173b5e" stroke-width="7" stroke-linecap="round"/><rect x="17" y="48" width="13" height="27" rx="6" fill="#1ecb63"/><rect x="66" y="48" width="13" height="27" rx="6" fill="#1ecb63"/><path d="M40 42q8 6 0 12M50 38q12 10 0 20" fill="none" stroke="#f2b632" stroke-width="4" stroke-linecap="round"/></svg>',graphemes:'<svg class="world-art-svg" viewBox="0 0 96 96" aria-hidden="true"><rect x="10" y="20" width="32" height="56" rx="12" fill="#e8fff0" stroke="#1ecb63" stroke-width="3"/><text x="26" y="58" text-anchor="middle" font-size="32" font-weight="900" fill="#0b7b58">A</text><path d="M44 48h18" stroke="#173b5e" stroke-width="5" stroke-linecap="round"/><circle cx="71" cy="48" r="14" fill="#eef8ff" stroke="#173b5e" stroke-width="3"/><path d="M67 42q8 6 0 12" fill="none" stroke="#f2b632" stroke-width="4" stroke-linecap="round"/></svg>',syllables:'<svg class="world-art-svg" viewBox="0 0 96 96" aria-hidden="true"><rect x="11" y="26" width="34" height="44" rx="12" fill="#dff7ff" stroke="#50b7d8" stroke-width="3"/><rect x="51" y="26" width="34" height="44" rx="12" fill="#fff2d8" stroke="#f2b632" stroke-width="3"/><text x="28" y="55" text-anchor="middle" font-size="19" font-weight="900" fill="#173b5e">BA</text><text x="68" y="55" text-anchor="middle" font-size="19" font-weight="900" fill="#173b5e">LA</text><path d="M43 48h10" stroke="#0b7b58" stroke-width="4" stroke-linecap="round"/></svg>',words:'<svg class="world-art-svg" viewBox="0 0 96 96" aria-hidden="true"><rect x="12" y="16" width="72" height="64" rx="16" fill="white" stroke="#cde7d5" stroke-width="3"/><circle cx="32" cy="40" r="12" fill="#f2c94c"/><path d="M20 57h56" stroke="#173b5e" stroke-width="5" stroke-linecap="round"/><path d="M28 68h40" stroke="#1ecb63" stroke-width="5" stroke-linecap="round"/></svg>',sentences:'<svg class="world-art-svg" viewBox="0 0 96 96" aria-hidden="true"><path d="M14 20h68v48H45L29 82v-14H14Z" fill="#eef8ff" stroke="#173b5e" stroke-width="3" stroke-linejoin="round"/><path d="M28 36h40M28 48h34M28 60h26" stroke="#0b7b58" stroke-width="5" stroke-linecap="round"/></svg>',comprehension:'<svg class="world-art-svg" viewBox="0 0 96 96" aria-hidden="true"><path d="M48 26c-10-7-22-8-34-3v49c12-5 24-4 34 3V26Zm0 0c10-7 22-8 34-3v49c-12-5-24-4-34 3V26Z" fill="white" stroke="#173b5e" stroke-width="3"/><path d="M25 38h14M25 48h16M57 38h14M57 48h12" stroke="#1ecb63" stroke-width="4" stroke-linecap="round"/><path d="M48 13l3 7 7 2-7 3-3 7-3-7-7-3 7-2Z" fill="#f2b632"/></svg>'};return A[id]||""}function render(){window.scrollTo(0,0);if(view==='splash')return splash();if(view.startsWith('onboard'))return onboarding();if(view==='diagnosticIntro')return diagnosticIntro();if(view==='diagnostic')return activity(true);if(view==='home')return home();if(view==='micro')return micro();if(view==='lesson')return activity(false);if(view==='end')return sessionEnd();if(view==='gateIntro')return gateIntro();if(view==='gateEnd')return gateEnd();if(view==='adult')return adult();view='home';home()}
function splash(){setTop(false);$('#view').innerHTML=`<section class="splash"><div class="splash-card"><img class="splash-logo" src="${LOGO}" alt="Intelectus Alfabetização"><img class="splash-mascot" src="${MASCOT}" alt="Mascote do Intelectus Alfabetização"><h1>${SPLASH_TITLE}</h1><p>${SPLASH_COPY}</p><button class="primary-xl" id="startBtn">Começar</button><button class="install-cta" type="button" onclick="installIntelectus()">Instalar no celular</button>${footer()}</div></section>`;$('#startBtn').onclick=()=>{startMusic();view=state.onboarded?(state.diagnosticDone?'home':'diagnosticIntro'):'onboardName';render()}}
function onboarding(){setTop(false);const idx={onboardName:0,onboardGrade:1,onboardAvatar:2,onboardGuide:3}[view]??0;let body='';if(view==='onboardName')body=`<h1>Como podemos chamar a criança?</h1><p>Esse nome aparece apenas neste aparelho.</p><input id="name" aria-label="Nome da criança" class="big-input" maxlength="20" value="${escapeHtml(state.name||'')}"><button class="primary-xl" id="next">Continuar</button>`;if(view==='onboardGrade')body=`<h1>Em que etapa ela está?</h1><p>Isso ajuda a começar no ritmo certo, com desafios adequados à etapa da criança.</p><div class="grid" id="grades">${GRADES.map(g=>`<button class="secondary" data-grade="${g}">${g}</button>`).join('')}</div><button class="primary-xl" id="next">Continuar</button>`;if(view==='onboardAvatar')body=`<h1>Escolha um avatar</h1><div class="avatar-grid grid">${['🦊','🐼','🦁','🐰','🐯','🐨','🦄','🐸'].map(a=>`<button class="avatar ${state.avatar===a?'sel':''}" data-av="${a}">${a}</button>`).join('')}</div><button class="primary-xl" id="next">Continuar</button>`;if(view==='onboardGuide')body=`<h1>Como a criança quer chamar sua professora-guia?</h1><p>Esse será o nome da professora-guia que orienta a aventura. A criança pode escolher o nome que preferir.</p><div class="guide-preview"><img class="guide-photo" src="${TEACHER}" alt="Professora virtual aprovada"><div><span>MINHA PROFESSORA</span><b id="guidePreviewName">${escapeHtml(state.guide||'Lia')}</b><small>Ela acompanha as missões, comemora conquistas e ajuda quando for preciso.</small></div></div><input id="guide" class="big-input" maxlength="18" value="${escapeHtml(state.guide||'Lia')}" aria-label="Nome escolhido para a professora"><button class="primary-xl" id="next">Conhecer minha professora</button>`;$('#view').innerHTML=`<section class="view"><div class="onboarding card"><div class="steps">${[0,1,2,3].map(i=>`<i class="${i<=idx?'on':''}"></i>`).join('')}</div>${body}${footer()}</div></section>`;if(view==='onboardName')$('#next').onclick=()=>{state.name=$('#name').value.trim()||'Criança';view='onboardGrade';render()};if(view==='onboardGrade'){$$('[data-grade]').forEach(b=>b.onclick=()=>{state.grade=b.dataset.grade;$$('[data-grade]').forEach(x=>x.style.borderColor='');b.style.borderColor='#19b957'});$('#next').onclick=()=>{view='onboardAvatar';render()}}if(view==='onboardAvatar'){$$('[data-av]').forEach(b=>b.onclick=()=>{state.avatar=b.dataset.av;render()});$('#next').onclick=()=>{view='onboardGuide';render()}}if(view==='onboardGuide'){$('#guide').oninput=e=>{const n=e.target.value.trim()||'Lia';const el=$('#guidePreviewName');if(el)el.textContent=n};$('#next').onclick=()=>{state.guide=$('#guide').value.trim()||'Lia';state.diagnosticVersion=3;state.onboarded=true;safeSave();view='diagnosticIntro';render()}}}
function diagnosticIntro(){setTop(false);$('#view').innerHTML=`<section class="view"><div class="card gate-box"><div class="gate-icon">🎧</div><h1>Descobrir por onde começar</h1><p>Vamos fazer dois desafios rápidos por etapa. Assim, um toque errado não decide sozinho o ponto de partida da criança.</p><div class="diag-note">A descoberta é curta e conservadora: só avançamos quando a habilidade aparece com segurança nas duas tentativas.</div><button class="primary-xl" id="diag">Fazer descoberta inicial</button><button class="secondary" style="width:100%;margin-top:12px" id="begin">Começar do primeiro mundo</button>${footer()}</div></section>`;$('#begin').onclick=()=>{state.entryIndex=0;state.diagnosticDone=true;state.diagnosticVersion=3;safeSave();view='home';render()};$('#diag').onclick=()=>{diag={i:0,trial:0,stageScore:0,passed:0};current=makeDiagnostic(0);attempt={wrong:0,done:false};view='diagnostic';render();RC55_scheduleTaskAudio(180)}}
function finishDiagnostic(){state.entryIndex=Math.min(diag.passed,worlds.length-1);state.diagnosticDone=true;state.diagnosticVersion=3;safeSave();view='home';render()}
const WORLD_IMG={"letters":"/assets/2ef4e94a76a03797367c9149efc75fe0c0c68e1fcff16f65702f081a36d6d890.jpg","sounds":"/assets/df82a4ae7898d9ea4bbc2bbae14888bb9fbdc9cf248001f74309b42d830f1cec.jpg","graphemes":"/assets/27ab7ced8f2b595231fb4a52f555a92e2f8a1601b5b89f9860cf6ab46c6c08d9.jpg","syllables":"/assets/22ab3299309b5ef0d297f894e83b41dacd4b9fe81a5ad6dfee85a2e79b98073a.jpg","words":"/assets/6bd030cc49d91f0c5f7eaab5ad421709627b85e693302e3b7444013bee428247.jpg","sentences":"/assets/2d656daa704cb6b3d58b9897782892dfa772ea2f4ec49aaf951213226e3e999b.jpg","comprehension":"/assets/429b9cf0bcca369c2c721399a0df0ea2502ebe1883f390a07812677e7b86b1db.jpg"};
function home(){setTop(true);const n=nextWorldIndex(),w=worlds[n];$('#view').innerHTML=`<section class="view home-view"><div class="hero"><div class="avatar-big">${state.avatar||'🦊'}</div><div><h1>Oi, ${escapeHtml(state.name||'Criança')}!</h1><p>${escapeHtml(state.guide||'Lia')} está com você nessa aventura.</p></div></div><div class="mission"><img class="teacher-mini" src="${TEACHER}" alt="${escapeHtml(state.guide||'Lia')}, professora virtual"><div class="mission-copy"><span class="kicker">MISSÃO COM ${escapeHtml(state.guide||'Lia').toUpperCase()}</span><b>${w.name}</b><p>Vamos aprender brincando!</p></div><button class="primary mission-play" id="guided" aria-label="Jogar missão ${escapeHtml(w.name)}"><span class="play-mark">▶</span> Jogar</button></div><div class="section-title"><h2>Trilha de aprendizagem</h2></div><div class="world-grid">${worlds.map((x,i)=>worldCard(x,i,n)).join('')}</div>${footer()}</section>`;$('#guided').onclick=()=>openGuided();$$('[data-world]').forEach(b=>{b.onclick=()=>prepareWorld(Number(b.dataset.world));b.onkeydown=e=>{if(e.key==='Enter'||e.key===' '){e.preventDefault();prepareWorld(Number(b.dataset.world))}}});$$('[data-skip]').forEach(b=>b.onclick=e=>{e.stopPropagation();requestGate(Number(b.dataset.skip))})}
function worldCard(w,i,n){const u=unlocked(i),s=worldStats(i),pct=mastered(i)?100:progressPct(i);const req=masteryReq(i);const progress=`${Math.min(s.attempts,req.attempts)}/${req.attempts}`;return `<div class="world ${u?'':'locked'} ${i===worlds.length-1?'world-wide':''}" data-world="${i}" role="button" tabindex="0" aria-label="${escapeHtml(w.name)}. ${u?'Abrir atividade':'Bloqueado, segue a sequência pedagógica'}"><div class="world-photo"><img src="${WORLD_IMG[w.id]}" alt="" aria-hidden="true"></div><div class="world-info"><b>${w.name}</b><div class="world-compact"><span class="mini-star">★</span><span>${progress}</span><span class="world-arrow">›</span></div></div><div class="meter"><i style="width:${pct}%"></i></div>${u?(i===n?'<span class="next">Agora</span>':''):'<span class="lock" aria-hidden="true">🔒</span>'}${!u&&i>0&&unlocked(i-1)?`<button class="skip-btn" data-skip="${i}">Eu já sei</button>`:''}</div>`}
let pendingGuided=false;function prepareWorld(i){if(!unlocked(i)){requestGate(i);return}pendingWorld=i;pendingGuided=false;if(!(state.seen||[]).includes(i)){view='micro';render()}else startWorld(i)}
function micro(){setTop(true);const w=worlds[pendingWorld],d=w.lesson;$('#view').innerHTML=`<section class="view"><div class="card micro"><div class="big-illustration">${worldArt(w.id)}</div><span class="kicker">ANTES DE PRATICAR</span><h1>${w.name}</h1><p><b>${d.title}</b><br>${d.text}</p>${pendingWorld===0?`<div class="letter-band">${letterCurriculum().pool.map(x=>`<span>${x} ${x.toLowerCase()}</span>`).join('')}</div><div class="tier-note">Vamos praticar um grupo de letras por vez. Quando estiver firme, novas letras entram naturalmente.</div>`:''}<div class="examples">${d.examples.map(x=>`<div class="example"><span>${x[0]}</span>${x[1]}</div>`).join('')}</div><button class="soft" id="hear">🔊 Ouvir exemplo</button><button class="primary-xl" id="go">Vamos praticar</button></div>${footer()}</section>`;$('#hear').onclick=()=>playSeq(d.audio||[]);$('#go').onclick=()=>{state.seen=state.seen||[];if(!state.seen.includes(pendingWorld))state.seen.push(pendingWorld);safeSave();(pendingGuided?startGuided:startWorld)(pendingWorld)}}
function startWorld(i){session={world:i,goal:sessionGoal(),done:0,independent:0,gate:false,guided:false,retryQueue:[],extra:0};current=makeTask(i);attempt={wrong:0,done:false};view='lesson';render();RC55_scheduleTaskAudio(180)}
function startGuided(i){pendingGuided=false;session={world:i,goal:sessionGoal(),done:0,independent:0,gate:false,guided:true,retryQueue:[],extra:0};current=makeGuidedTask(i,0);attempt={wrong:0,done:false};view='lesson';render();RC55_scheduleTaskAudio(180)} function openGuided(){const i=nextWorldIndex();pendingWorld=i;pendingGuided=true;if(!(state.seen||[]).includes(i)){view='micro';render()}else startGuided(i)}
function makeGuidedTask(i,step){if(step===2){const prior=[];for(let k=0;k<i;k++)if(unlocked(k))prior.push(k);if(prior.length)return makeTask(pick(prior))}return makeTask(i)}
function requestGate(target){gateTarget=target;view='gateIntro';render()}
function gateIntro(){setTop(true);const prev=worlds[gateTarget-1],target=worlds[gateTarget];$('#view').innerHTML=`<section class="view"><div class="card gate-box"><div class="gate-icon">🚀</div><h1>Quer avançar para ${target.name}?</h1><p>Vamos fazer uma rodada curta em <b>${prev.name}</b>. Se a criança mostrar segurança, a próxima etapa será liberada.</p><button class="primary-xl" id="gateGo">Quero mostrar que já sei</button><button class="secondary" style="width:100%;margin-top:12px" id="backHome">Continuar praticando</button></div>${footer()}</section>`;$('#backHome').onclick=()=>{view='home';render()};$('#gateGo').onclick=()=>{session={world:gateTarget-1,goal:5,done:0,independent:0,gate:true,guided:false};current=RC55_makeAssessmentTask(gateTarget-1);attempt={wrong:0,done:false};view='lesson';render();RC55_scheduleTaskAudio(180)}}
function gateEnd(){setTop(true);const pass=session.independent>=4;if(pass){state.bypass=state.bypass||[];if(!state.bypass.includes(gateTarget))state.bypass.push(gateTarget);safeSave()}$('#view').innerHTML=`<section class="view"><div class="card gate-box"><div class="gate-icon">${pass?'🌟':'💪'}</div><h1>${pass?'Etapa liberada!':'Mais um pouco de prática'}</h1><p>${pass?`Você mostrou que já sabe esta etapa e pode seguir para <b>${worlds[gateTarget].name}</b>.`:`Ainda vale praticar um pouco mais. Vamos reforçar ${worlds[gateTarget-1].name} antes de tentar avançar novamente.`}</p><button class="primary-xl" id="gateDone">Voltar à trilha</button></div>${footer()}</section>`;$('#gateDone').onclick=()=>{view='home';render()}}
function activity(isDiag){setTop(!isDiag);const wi=isDiag?diag.i:session.world,w=worlds[wi],pos=isDiag?(diag.i*2+(diag.trial||0)):session.done,total=isDiag?worlds.length*2:session.goal;$('#view').innerHTML=`<section class="view"><div class="card lesson"><div class="lesson-head"><button class="back" id="back" aria-label="Voltar">‹</button><div><b>${isDiag?'Descoberta inicial':session.gate?'Desafio de avanço':w.name}</b><span>${pos+1} de ${total}</span></div></div><div class="progress">${Array.from({length:total},(_,i)=>`<i class="${i<pos?'done':''}"></i>`).join('')}</div><button class="audio-btn" id="audio" aria-label="Ouvir novamente" title="Ouvir novamente">🔊</button><div class="command">${current.command}</div>${stimulus(current)}<div class="choices">${choices(current)}</div>${attempt.wrong&&!attempt.done?`<div class="feedback hint">${hintForTask(current)}</div>`:''}${attempt.done?`<div class="teacher-feedback"><img class="teacher-feedback-photo" src="${TEACHER}" alt="${escapeHtml(state.guide||'Lia')}, professora virtual"><div class="teacher-bubble"><b>${attempt.first?escapeHtml(attempt.praise||`Muito bem, ${state.name||'Criança'}!`):`Vamos treinar mais um pouquinho!`}</b><small>${attempt.first?`${escapeHtml(state.guide||'Lia')} ficou muito feliz com sua conquista.`:`${escapeHtml(state.guide||'Lia')} vai praticar esta ideia com você de novo daqui a pouco.`}</small></div></div><button class="primary-xl" id="next">Continuar</button>`:''}</div>${footer()}</section>`;$('#back').onclick=()=>{view=isDiag?'diagnosticIntro':'home';render()};$('#audio').onclick=()=>playSeq(current.audio);$$('[data-ans]').forEach(b=>b.onclick=()=>answer(decodeURIComponent(b.dataset.ans),isDiag));if($('#next'))$('#next').onclick=()=>next(isDiag)}
function choices(t){return t.options.map(o=>{const v=typeof o==='object'?o.value:o,sel=attempt.done&&String(v)===String(t.answer),bad=attempt.done&&String(v)===String(attempt.selected)&&!sel;let inner='';if(t.kind==='letter')inner=`<div class="letter">${escapeHtml(v)}</div>`;else if(t.kind==='number')inner=`<div class="num">${escapeHtml(v)}</div>`;else if(t.kind==='word')inner=`<div class="word">${escapeHtml(v)}</div>`;else if(t.kind==='picture'){const val=typeof o==='object'?o.value:o,pic=typeof o==='object'?o.pic:o;inner=miniVisual(val,pic)}else if(t.kind==='sentence')inner=`<div class="word">${escapeHtml(typeof o==='object'?o.text:o)}</div>`;else if(t.kind==='shape')inner=`<div class="shape">${o.symbol}</div><div>${escapeHtml(o.name)}</div>`;else if(t.kind==='bar')inner=`<div class="bar" style="height:${o.height}px">${o.value}</div>`;else inner=`<div class="word">${escapeHtml(v)}</div>`;return `<button class="choice ${sel?'good':''} ${bad?'bad':''}" data-ans="${encodeURIComponent(v)}" ${attempt.done?'disabled':''}>${inner}</button>`}).join('')}
function answer(v,isDiag){if(attempt.done)return;attempt.selected=v;const ok=String(v)===String(current.answer);if(ok){attempt.first=attempt.wrong===0;attempt.done=true;attempt.praise=pick([`Muito bem, ${state.name||'Criança'}!`,`Ótimo trabalho, ${state.name||'Criança'}!`,`Você conseguiu, ${state.name||'Criança'}!`]);if(isDiag){}else{session.independent+=attempt.first?1:0;recordTask(current,attempt.first);playSeq([pick(AUD.praise)])}render()}else{attempt.wrong++;if(!isDiag&&!session?.gate&&attempt.wrong===1)scheduleRetry(current);if(attempt.wrong>=2){attempt.first=false;attempt.done=true;if(!isDiag)recordTask(current,false);playSeq([AUD.model]);render()}else{playSeq([pick(AUD.try),...(current.audio||[])]);render()}}}
function next(isDiag){if(isDiag){if(attempt.first)diag.stageScore=(diag.stageScore||0)+1;diag.trial=(diag.trial||0)+1;if(diag.trial<2){current=makeDiagnostic(diag.i);attempt={wrong:0,done:false};render();RC55_scheduleTaskAudio(150);return}if((diag.stageScore||0)<2)return finishDiagnostic();diag.passed++;diag.i++;diag.trial=0;diag.stageScore=0;if(diag.i>=worlds.length)return finishDiagnostic();current=makeDiagnostic(diag.i);attempt={wrong:0,done:false};render();RC55_scheduleTaskAudio(150);return}session.done++;if(session.done>=session.goal){if(session.gate){view='gateEnd';render();return}if((session.retryQueue||[]).length&&(session.extra||0)<2){session.extra=(session.extra||0)+1;session.goal++}else{view='end';render();playSeq([AUD.finish]);return}}current=session.gate?RC55_makeAssessmentTask(session.world):nextSessionTask();attempt={wrong:0,done:false};render();RC55_scheduleTaskAudio(150)}
function sessionEnd(){setTop(true);const w=worlds[session.world],s=worldStats(session.world),first=session.independent||0,total=session.done||session.goal;$('#view').innerHTML=`<section class="view"><div class="card end"><div class="big">🏆</div><h1>Missão concluída!</h1><p>Você concluiu mais uma missão em <b>${w.name}</b>. ${escapeHtml(state.guide||'Lia')} separou revisões extras quando alguma ideia precisou de mais treino.</p><div class="tier-note">Nesta missão: ${first} atividade${first===1?'':'s'} resolvida${first===1?'':'s'} sem ajuda · ${total} prática${total===1?'':'s'} no total.</div><div class="meter"><i style="width:${progressPct(session.world)}%"></i></div><button class="primary-xl" id="again">Continuar a aventura</button></div>${footer()}</section>`;$('#again').onclick=()=>{view='home';render()}}
function adult(){setTop(true);$('#view').innerHTML=`<section class="view"><div class="card adult"><button class="secondary family-back" id="backHome" aria-label="Voltar à trilha">← Voltar à trilha</button><h1>Área da família</h1><p>A trilha respeita o que a criança já aprendeu e libera novas etapas aos poucos, sem saltos aleatórios. Os áudios pedagógicos usam ritmo infantil diferenciado para letras, palavras e instruções.</p><div class="family-teacher"><img src="${TEACHER}" alt="Professora virtual aprovada"><div><span>PROFESSORA VIRTUAL</span><b>${escapeHtml(state.guide||'Lia')}</b><small>A imagem da professora permanece a aprovada; a criança escolhe apenas como quer chamá-la.</small></div></div><div class="profile-settings"><h2>Perfil da criança</h2><p>Você pode corrigir nome, etapa e o nome escolhido para a professora-guia sem apagar o progresso.</p><div class="profile-grid"><label>Nome da criança<input id="profileName" class="profile-input" maxlength="20" value="${escapeHtml(state.name||'')}"></label><label>Nome da professora<input id="profileGuide" class="profile-input" maxlength="18" value="${escapeHtml(state.guide||'Lia')}"></label><label>Etapa<select id="profileGrade" class="profile-input">${GRADES.map(g=>`<option value="${g}" ${state.grade===g?'selected':''}>${g}</option>`).join('')}</select></label></div><button class="soft profile-save" id="saveProfile">Salvar perfil</button><div class="profile-note" id="profileNote">Esses dados ficam apenas neste aparelho.</div></div><div class="sound-settings"><h2>Som e música</h2><p>A voz fica em primeiro plano. Durante as orientações, a música baixa automaticamente.</p><div class="sound-control"><label for="voiceVol">Voz da professora</label><input id="voiceVol" type="range" min="0" max="100" step="5" value="${voiceLevel}" aria-label="Volume da voz"><output id="voiceOut">${voiceLevel}%</output></div><div class="sound-control"><label for="musicVol">Música</label><input id="musicVol" type="range" min="0" max="100" step="5" value="${musicLevel}" aria-label="Volume da música"><output id="musicOut">${musicLevel}%</output></div><button class="soft sound-test" id="testVoice">▶ Ouvir teste da voz</button><div class="sound-note">Os ajustes ficam salvos somente neste aparelho.</div></div><div class="adult-grid">${worlds.map((w,i)=>{const s=worldStats(i);return `<div class="adult-row"><b>${w.name}</b><small>${w.bncc.join(' · ')}</small><div class="meter"><i style="width:${progressPct(i)}%"></i></div><div>${s.attempts} práticas · ${s.accuracy}% sem ajuda · ${s.unique} exemplos/habilidades vistos</div></div>`}).join('')}</div><button class="secondary" style="width:100%;margin-top:14px" id="export">Exportar progresso</button><button class="danger" style="width:100%;margin-top:10px" id="reset">Recomeçar neste aparelho</button>${footer()}</div></section>`;$('#backHome').onclick=()=>{view='home';render()};$('#saveProfile').onclick=()=>{state.name=$('#profileName').value.trim()||'Criança';state.guide=$('#profileGuide').value.trim()||'Lia';state.grade=$('#profileGrade').value||'1º Ano';safeSave();$('#profileNote').textContent='Perfil salvo neste aparelho.';setTimeout(()=>{const n=$('#profileNote');if(n)n.textContent='Esses dados ficam apenas neste aparelho.'},2200)};$('#voiceVol').oninput=e=>{setVoiceLevel(e.target.value);$('#voiceOut').textContent=voiceLevel+'%'};$('#musicVol').oninput=e=>{setMusicLevel(e.target.value);$('#musicOut').textContent=musicLevel+'%';if(musicOn&&musicLevel>0)startMusic()};$('#testVoice').onclick=()=>playSeq([pick(AUD.praise)]);$('#export').onclick=()=>{const blob=new Blob([JSON.stringify(state,null,2)],{type:'application/json'}),a=document.createElement('a');a.href=URL.createObjectURL(blob);a.download=APPKEY+'-progresso.json';a.click();setTimeout(()=>URL.revokeObjectURL(a.href),1000)};$('#reset').onclick=()=>{if(confirm('Recomeçar o progresso neste aparelho?')){STORE.removeItem(APPKEY);location.reload()}}}


function sceneIndex(key){return Math.abs([...String(key)].reduce((a,c)=>a+c.charCodeAt(0),0)+(state.total||0))%12}
function visualPic(w){const v=sceneIndex(w.w),pic=wordPic(w.w,w.pic);return `<div class="visual scene-${v}" style="--rot:${v%4===2?'-3deg':v%4===3?'3deg':'0deg'}" role="img" aria-label="Ilustração de ${escapeHtml(w.w.toLowerCase())}"><span class="emoji">${pic}</span><span class="visual-spark">✦</span></div>`}
function miniVisual(value,pic){const v=sceneIndex(value),p=wordPic(value,pic);return `<div class="mini-visual scene-${v}" role="img" aria-label="${escapeHtml(String(value).toLowerCase())}"><span>${p}</span></div>`}
function letterCurriculum(){const raw=((state.stats||{}).letters||{attempts:0,independent:0,unique:[]}),attempts=raw.attempts||0,acc=attempts?Math.round((raw.independent||0)/attempts*100):0,seen=new Set((raw.unique||[]).map(k=>String(k).split(':')[0])),p=gradeProfile();if(attempts<p.letter[0]||seen.size<8||acc<68)return{tier:1,pool:'AEIOUBMPLT'.split(''),label:'vogais + primeiras consoantes'};if(attempts<p.letter[1]||seen.size<16||acc<70)return{tier:2,pool:'AEIOUBMPLTDFVNSCGR'.split(''),label:'ampliando o repertório'};return{tier:3,pool:'ABCDEFGHIJKLMNOPQRSTUVWXYZ'.split(''),label:'alfabeto completo'}}
function letterOpts(l,lower=false){const letters=letterCurriculum().pool,ds=shuffle(letters.filter(x=>x!==l)).slice(0,2);return shuffle([lower?l.toLowerCase():l,...ds.map(x=>lower?x.toLowerCase():x)])}
function syllableCurriculum(){const st=worldStats(3),p=gradeProfile(),easy=WORDS.filter(x=>x.level===1&&x.sy.length===2),all=WORDS.filter(x=>x.level<=2);if(st.attempts<p.syllable[0])return{pool:easy,modes:['first','count'],label:'ouvir e separar os primeiros pedaços'};if(state.grade==='Pré-escola'||st.attempts<p.syllable[1]||st.accuracy<72)return{pool:easy,modes:['first','last','count'],label:'primeiro, último e quantidade de sílabas'};return{pool:all,modes:['first','last','count','join'],label:'juntar sílabas e formar palavras'}}
function wordCurriculum(){const st=worldStats(4),p=gradeProfile();if(st.attempts<p.word[0]||st.accuracy<70)return WORDS.filter(x=>x.level===1&&x.sy.length===2);if(st.attempts<p.word[1])return WORDS.filter(x=>x.level<=1);return WORDS}
function soundPool(){const st=worldStats(1),p=gradeProfile();if(st.attempts<p.sound[0])return WORDS.filter(x=>x.level===1&&'BMPLT'.includes(x.g));if(st.attempts<p.sound[1])return WORDS.filter(x=>x.level===1&&'BMPLTDFVNSCGR'.includes(x.g));return WORDS.filter(x=>x.level===1)}
function makeTask(i){if(i===0)return uniqueTask(()=>{const curriculum=letterCurriculum(),L=pick(curriculum.pool),r=Math.random();if(r<.34){const low=Math.random()<.5,ans=low?L.toLowerCase():L;return{world:'letters',key:`${L}:${low?'lower':'upper'}`,sig:`letter-listen:${L}:${low}`,command:'Escute e toque na letra',audio:[AUDIO['prompt:touch_letter'],AUDIO['letter:'+L]],kind:'letter',options:letterOpts(L,low),answer:ans}}if(r<.64){const stim=Math.random()<.5?L:L.toLowerCase(),ans=stim===L?L.toLowerCase():L;return{world:'letters',key:`${L}:case`,sig:`case:${L}:${stim}`,command:'Ache a mesma letra em outra forma',audio:[AUDIO['prompt:same_letter']],kind:'letter',stimulus:{type:'letter',text:stim},options:shuffle([ans,...letterOpts(L,stim===L).filter(x=>x!==ans).slice(0,2)]),answer:ans}}if(r<.82){const ans=L;return{world:'letters',key:`${L}:signs`,sig:`signs:${L}`,command:'Escute. Qual opção é a letra?',audio:[AUDIO['prompt:touch_letter'],AUDIO['letter:'+L]],kind:'letter',options:shuffle([ans,pick(['?','!','7','@','#']),pick(['3','%','&','9'])]),answer:ans}}const low=Math.random()<.5,ans=low?L.toLowerCase():L,other=pick(curriculum.pool.filter(x=>x!==L));return{world:'letters',key:`${L}:mixed:${low}`,sig:`mixed:${L}:${low}:${other}`,command:'Escute e toque na letra',audio:[AUDIO['prompt:touch_letter'],AUDIO['letter:'+L]],kind:'letter',options:shuffle([ans,low?other.toLowerCase():other,pick(['?','7','@'])]),answer:ans}});
if(i===1)return uniqueTask(()=>{const pool=soundPool(),r=Math.random();if(r<.78){const model=pick(pool),same=shuffle(pool.filter(x=>x.sound===model.sound&&x.w!==model.w))[0]||model,wrong=shuffle(pool.filter(x=>x.sound!==model.sound)).slice(0,2);return{world:'sounds',key:`initial:${model.sound}:${model.w}`,sig:`sound:${model.w}:${same.w}`,command:'Qual figura começa com o mesmo som?',audio:[AUDIO['prompt:listen_word'],AUDIO['word:'+model.w],AUDIO['prompt:same_initial_sound']],kind:'picture',stimulus:{type:'visual',word:model},options:shuffle([same,...wrong]).map(x=>({value:x.w,pic:x.pic})),answer:same.w}}const rhymeSets=[['GATO','PATO',['BOLA','MALA']],['PATO','GATO',['MESA','VACA']],['MALA','BALA',['PATO','MOTO']],['BALA','MALA',['GATO','CASA']],['VELA','TELA',['BOLA','PATO']],['TELA','VELA',['MALA','VACA']],['BOLA','ESCOLA',['PATO','CASA']]],p=pick(rhymeSets),base=WORDS.find(x=>x.w===p[0]),ans=p[1],wrong=p[2].map(x=>WORDS.find(y=>y.w===x)).filter(Boolean),ansObj=WORDS.find(x=>x.w===ans)||{w:ans,pic:ans==='ESCOLA'?'🏫':'✨'};return{world:'sounds',key:`rhyme:${p[0]}:${ans}`,sig:`rhyme:${p[0]}:${ans}`,command:'Qual termina com um som parecido?',audio:[AUDIO['prompt:listen_word'],AUDIO['word:'+p[0]],AUDIO['prompt:rhyme']],kind:'picture',stimulus:{type:'visual',word:base},options:shuffle([ansObj,...wrong]).map(x=>({value:x.w,pic:x.pic})),answer:ans}});
if(i===2)return uniqueTask(()=>{const w=pick(WORDS.filter(x=>x.level===1)),ds=shuffle('ABCDEFGHIJKLMNOPQRSTUVWXYZ'.split('').filter(x=>x!==w.g)).slice(0,2),lower=Math.random()<.35;return{world:'graphemes',key:`${w.g}:${w.sound}:${w.w}`,sig:`grapheme:${w.w}:${lower}`,command:'Qual letra aparece no começo?',audio:[AUDIO['prompt:listen_word'],AUDIO['word:'+w.w],AUDIO['prompt:first_letter']],kind:'letter',stimulus:{type:'visual',word:w},options:shuffle([lower?w.g.toLowerCase():w.g,...ds.map(x=>lower?x.toLowerCase():x)]),answer:lower?w.g.toLowerCase():w.g}});
if(i===3)return uniqueTask(()=>{const cur=syllableCurriculum(),w=pick(cur.pool),mode=pick(cur.modes);if(mode==='first'){const ds=shuffle([...new Set(cur.pool.filter(x=>x.w!==w.w).map(x=>x.sy[0]))].filter(x=>x!==w.sy[0])).slice(0,2);return{world:'syllables',key:`first:${w.w}`,sig:`sy-first:${w.w}`,command:'Qual é o primeiro pedaço?',audio:[AUDIO['prompt:listen_word'],AUDIO['word:'+w.w],AUDIO['prompt:first_syllable']],kind:'word',stimulus:{type:'visual',word:w},options:shuffle([w.sy[0],...ds]),answer:w.sy[0]}}if(mode==='last'){const ans=w.sy.at(-1),ds=shuffle([...new Set(cur.pool.filter(x=>x.w!==w.w).map(x=>x.sy.at(-1)))].filter(x=>x!==ans)).slice(0,2);return{world:'syllables',key:`last:${w.w}`,sig:`sy-last:${w.w}`,command:'Qual é o último pedaço?',audio:[AUDIO['prompt:listen_word'],AUDIO['word:'+w.w],AUDIO['prompt:last_syllable']],kind:'word',stimulus:{type:'visual',word:w},options:shuffle([ans,...ds]),answer:ans}}if(mode==='count'){const ans=String(w.sy.length);return{world:'syllables',key:`count:${w.w}`,sig:`sy-count:${w.w}`,command:'Quantos pedaços você ouve?',audio:[AUDIO['prompt:listen_word'],AUDIO['word:'+w.w],AUDIO['prompt:count_syllables']],kind:'number',stimulus:{type:'visual',word:w},options:shuffle(['1','2','3'].filter(x=>x!==ans).slice(0,2).concat(ans)),answer:ans}}const wrong=shuffle(cur.pool.filter(x=>x.w!==w.w)).slice(0,2);return{world:'syllables',key:`join:${w.w}`,sig:`sy-join:${w.w}`,command:'Junte os pedaços e escolha a palavra',audio:[AUDIO['prompt:join_syllables']],kind:'word',stimulus:{type:'syllables',items:w.sy},options:shuffle([w.w,...wrong.map(x=>x.w)]),answer:w.w}});
if(i===4)return uniqueTask(()=>{const pool=wordCurriculum(),w=pick(pool),ds=shuffle(pool.filter(x=>x.w!==w.w)).slice(0,2);if(Math.random()<.58)return{world:'words',key:`img:${w.w}`,sig:`img-word:${w.w}`,command:'Observe a figura. Qual palavra combina?',audio:[AUDIO['prompt:look_choose_word']],kind:'word',stimulus:{type:'visual',word:w},options:shuffle([w.w,...ds.map(x=>x.w)]),answer:w.w};return{world:'words',key:`read:${w.w}`,sig:`word-img:${w.w}`,command:'Leia e escolha a figura',audio:[AUDIO['prompt:read_choose_picture']],kind:'picture',stimulus:{type:'word',text:w.w},options:shuffle([w,...ds]).map(x=>({value:x.w,pic:x.pic})),answer:w.w}});
if(i===5)return uniqueTask(()=>{const s=pick(sentencePool()),opts=shuffle([{value:s.good,text:s.good},...s.bad.map(x=>({value:x,text:x}))]);return{world:'sentences',key:s.good,sig:`sentence:${s.good}`,command:'Observe a cena e escolha a frase',audio:[AUDIO['prompt:scene_choose_sentence']],kind:'sentence',stimulus:{type:'scene',text:s.scene},options:opts,answer:s.good}});
return uniqueTask(()=>{const stories=[
{key:'c1',story:'Lia ganhou uma bola e foi brincar no quintal.',q:'O que Lia ganhou?',opts:[['BOLA','⚽'],['GATO','🐱'],['PIPA','🪁']],ans:'BOLA',audio:[AUDIO['story:c1_historia'],AUDIO['story:c1_pergunta']]},
{key:'c2',story:'O sapo pulou no lago para nadar.',q:'Onde o sapo pulou?',opts:[['LAGO','🌊'],['CASA','🏠'],['CAMA','🛏️']],ans:'LAGO',audio:[AUDIO['story:c2_historia'],AUDIO['story:c2_pergunta']]},
{key:'c3',story:'Começou a chover. O gato correu para dentro da casa.',q:'Por que o gato entrou na casa?',opts:[['POR CAUSA DA CHUVA','🌧️'],['PARA COMER','🍽️'],['PARA VER A LUA','🌙']],ans:'POR CAUSA DA CHUVA',audio:[AUDIO['story:c3_historia'],AUDIO['story:c3_pergunta']]},
{key:'c4',story:'LIA LEU UM LIVRO. DEPOIS, FOI DORMIR.',q:'O que Lia fez primeiro?',opts:[['LEU UM LIVRO','📖'],['FOI DORMIR','🛏️'],['JOGOU BOLA','⚽']],ans:'LEU UM LIVRO',audio:[AUDIO['prompt:read_answer']]},
{key:'c5',story:'PEDRO LEVOU A PIPA AO PARQUE PORQUE O DIA ESTAVA ENSOLARADO.',q:'O que Pedro levou ao parque?',opts:[['PIPA','🪁'],['BOLA','⚽'],['LIVROS','📚']],ans:'PIPA',audio:[AUDIO['prompt:read_answer']]},
{key:'c6',story:'A VOVÓ COLOCOU A VELA NA MESA E DEPOIS ACENDEU A LUZ.',q:'Onde a vovó colocou a vela?',opts:[['NA MESA','🪑'],['NA CAMA','🛏️'],['NO LAGO','🌊']],ans:'NA MESA',audio:[AUDIO['prompt:read_answer']]},
{key:'c7',story:'O PATO SAIU DO LAGO E CAMINHOU ATÉ A GRAMA.',q:'De onde o pato saiu?',opts:[['DO LAGO','🌊'],['DA CASA','🏠'],['DA NUVEM','☁️']],ans:'DO LAGO',audio:[AUDIO['prompt:read_answer']]},
{key:'c8',story:'A BOLA ROLOU PARA PERTO DO VASO. LIA FOI BUSCÁ-LA.',q:'Por que Lia foi até o vaso?',opts:[['PARA BUSCAR A BOLA','⚽'],['PARA DORMIR','🛏️'],['PARA ACENDER A VELA','🕯️']],ans:'PARA BUSCAR A BOLA',audio:[AUDIO['prompt:read_answer']]},
{key:'c9',story:'O MACACO VIU A BANANA E SUBIU NO GALHO.',q:'O que o macaco viu?',opts:[['A BANANA','🍌'],['A MOTO','🏍️'],['A PENA','🪶']],ans:'A BANANA',audio:[AUDIO['prompt:read_answer']]},
{key:'c10',story:'A NUVEM ESCURECEU O CÉU. LOGO DEPOIS, COMEÇOU A CHOVER.',q:'O que aconteceu depois que a nuvem escureceu o céu?',opts:[['COMEÇOU A CHOVER','🌧️'],['O SOL BRILHOU','☀️'],['A LUA SUMIU','🌙']],ans:'COMEÇOU A CHOVER',audio:[AUDIO['prompt:read_answer']]},
{key:'c11',story:'MILA GUARDOU O DADO NO POTE PARA NÃO PERDÊ-LO.',q:'Por que Mila guardou o dado?',opts:[['PARA NÃO PERDÊ-LO','🎲'],['PARA MOLHÁ-LO','💧'],['PARA JOGÁ-LO FORA','🗑️']],ans:'PARA NÃO PERDÊ-LO',audio:[AUDIO['prompt:read_answer']]},
{key:'c12',story:'O GALO CANTOU CEDO E A FAMÍLIA ACORDOU.',q:'O que aconteceu primeiro?',opts:[['O GALO CANTOU','🐓'],['A FAMÍLIA ACORDOU','👨‍👩‍👧'],['COMEÇOU A CHOVER','🌧️']],ans:'O GALO CANTOU',audio:[AUDIO['prompt:read_answer']]}
],x=pick(storyPool(stories));return{world:'comprehension',key:x.key,sig:`comp:${x.key}`,command:x.q,audio:x.audio,kind:'picture',stimulus:{type:'story',text:x.story},options:shuffle(x.opts.map(o=>({value:o[0],pic:o[1]}))),answer:x.ans}})}
function makeDiagnostic(i){const d=[()=>{const t=makeTask(0);return t},()=>{const t=makeTask(1);return t},()=>{const t=makeTask(2);return t},()=>{const t=makeTask(3);return t},()=>{const t=makeTask(4);return t},()=>{const t=makeTask(5);return t},()=>{const t=makeTask(6);return t}];return d[i]()}
function stimulus(t){const s=t.stimulus;if(!s)return'';if(s.type==='letter')return `<div class="stimulus"><div class="big-letter">${escapeHtml(s.text)}</div></div>`;if(s.type==='lettergrid')return `<div class="stimulus"><div class="letter-grid">${s.items.map(x=>`<span>${escapeHtml(x)}</span>`).join('')}</div></div>`;if(s.type==='visual')return `<div class="stimulus">${visualPic(s.word)}</div>`;if(s.type==='syllables')return `<div class="stimulus"><div class="reading">${s.items.map(x=>`<span style="background:#eef6ff;border-radius:14px;padding:9px;margin:3px;display:inline-block">${escapeHtml(x)}</span>`).join(' + ')}</div></div>`;if(s.type==='word')return `<div class="stimulus"><div class="reading">${escapeHtml(s.text)}</div></div>`;if(s.type==='scene')return `<div class="stimulus"><div style="font-size:94px">${s.text}</div></div>`;if(s.type==='story')return `<div class="stimulus"><div class="sentence">${escapeHtml(s.text)}</div></div>`;return''}

$('#musicFab').onclick=toggleMusic;$('#adultBtn').onclick=()=>{view='adult';render()};const brandHome=$('#top img');if(brandHome){brandHome.style.cursor='pointer';brandHome.setAttribute('role','button');brandHome.setAttribute('tabindex','0');brandHome.setAttribute('aria-label','Voltar à trilha');const goHome=()=>{view='home';render()};brandHome.onclick=goHome;brandHome.onkeydown=e=>{if(e.key==='Enter'||e.key===' '){e.preventDefault();goHome()}}}initMusic(MUSIC);render();

/* ===== legacy-script ===== */

(()=>{let p=null;window.addEventListener('beforeinstallprompt',e=>{e.preventDefault();p=e});
window.installIntelectus=async function(){
 if(p){p.prompt();try{await p.userChoice}catch(e){}p=null;return}
 const old=document.querySelector('.pwa-note');if(old)old.remove();
 const n=document.createElement('div');n.className='pwa-note';n.textContent=/iphone|ipad|ipod/i.test(navigator.userAgent)?'No iPhone/iPad: Compartilhar → Adicionar à Tela de Início.':'No navegador do celular: abra o menu e escolha “Instalar aplicativo” ou “Adicionar à tela inicial”.';document.body.appendChild(n);setTimeout(()=>n.remove(),5200)
};})();


/* ===== rc61-sw-register ===== */
if('serviceWorker' in navigator&&(location.protocol==='https:'||location.hostname==='localhost'||location.hostname==='127.0.0.1')){window.addEventListener('load',()=>navigator.serviceWorker.register('/sw.js',{scope:'/'}).catch(()=>{}));}

/* ===== rc43-pedagogical-final ===== */

/* Intelectus Alfabetização — RC Pedagógica Final V43
   Camada não destrutiva sobre a V42 homologada.
*/
const RC43_VERSION = 43;
const RC43_PREVIOUS_NEXT_WORLD = (()=>{ try { return nextWorldIndex(); } catch(e) { return 0; } })();
const RC43_ORIGINALS = {
  playOne,
  setTop,
  makeTask,
  nextSessionTask,
  activity,
  adult,
  onboarding,
  worldStats,
  progressPct,
  mastered,
  unlocked
};

const RC43_VOICE_PROFILES = {
  calma:   {label:'Calma',   note:'ritmo mais pausado', rate:.92},
  natural: {label:'Natural', note:'ritmo equilibrado',  rate:1.00},
  animada: {label:'Animada', note:'ritmo mais vivo',    rate:1.08}
};

function RC43_migrateState(){
  state.rcPedagogicalVersion = RC43_VERSION;
  state.voiceProfile = RC43_VOICE_PROFILES[state.voiceProfile] ? state.voiceProfile : 'natural';
  state.skillLedger = state.skillLedger && typeof state.skillLedger==='object' ? state.skillLedger : {};
  state.accessibility = {
    largeText:false,
    highContrast:false,
    reduceMotion:window.matchMedia?.('(prefers-reduced-motion: reduce)')?.matches || false,
    hearingAccommodation:false,
    ...(state.accessibility||{})
  };
  state.stats = state.stats || {};
  for(const w of worlds){
    const x = state.stats[w.id];
    if(!x) continue;
    x.unique = Array.isArray(x.unique) ? x.unique : [];
    x.weightedPoints = Number.isFinite(x.weightedPoints) ? x.weightedPoints : Number(x.independent||0);
    x.assisted = Number.isFinite(x.assisted) ? x.assisted : 0;
    x.errors = Number.isFinite(x.errors) ? x.errors : Math.max(0,Number(x.attempts||0)-Number(x.independent||0));
    x.history = Array.isArray(x.history) ? x.history : [];
  }
  safeSave();
}
RC43_migrateState();

// Proteção contra duplicações de itens lexicais (incluindo a antiga duplicidade de SINO).
(function RC43_dedupeWords(){
  const seen = new Set();
  for(let i=0;i<WORDS.length;i++){
    const key=String(WORDS[i]?.w||'').trim().toUpperCase();
    if(!key) continue;
    if(seen.has(key)){ WORDS.splice(i,1); i--; }
    else seen.add(key);
  }
})();

function RC43_rawStats(i){
  const w=worlds[i];
  if(!w) return {attempts:0,independent:0,unique:[],weightedPoints:0,assisted:0,errors:0,history:[]};
  let x=state.stats[w.id];
  if(!x){
    x={attempts:0,independent:0,unique:[],weightedPoints:0,assisted:0,errors:0,history:[]};
    state.stats[w.id]=x;
  }
  x.unique=Array.isArray(x.unique)?x.unique:[];
  x.history=Array.isArray(x.history)?x.history:[];
  x.weightedPoints=Number.isFinite(x.weightedPoints)?x.weightedPoints:Number(x.independent||0);
  x.assisted=Number.isFinite(x.assisted)?x.assisted:0;
  x.errors=Number.isFinite(x.errors)?x.errors:0;
  return x;
}

function RC43_skillId(task){
  if(task?.skill) return task.skill;
  const k=String(task?.key||'');
  const w=String(task?.world||'');
  if(w==='letters') return `letters:${k.split(':')[0]||'geral'}`;
  if(w==='sounds') return k.startsWith('rhyme:')?'phonology:rhyme':'phonology:initial';
  if(w==='graphemes') return `grapheme:${k.split(':')[0]||'inicial'}`;
  if(w==='syllables') return `syllable:${k.split(':')[0]||'geral'}`;
  if(w==='words') return `word:${k.split(':').at(-1)||'geral'}`;
  if(w==='sentences') return 'sentence:reading';
  if(w==='comprehension'){
    const inferOld=new Set(['c3','c8','c10','c11','c12']);
    return k.startsWith('infer:')||inferOld.has(k)?'comprehension:inferential':'comprehension:literal';
  }
  return `${w||'geral'}:geral`;
}

function RC55_evidence(i){
 const x=RC43_rawStats(i);
 // During initial migration, preserve access earned under the historical rules.
 if(!state.rc55EvidenceVersion||state.grade==='Pré-escola')return x.unique||[];
 return Array.isArray(x.successfulUnique)?x.successfulUnique:[];
}
function RC43_recordSkill(task,score,meta={}){
  const id=RC43_skillId(task);
  const s=state.skillLedger[id]||{attempts:0,points:0,errors:0,help:0,last:0};
  s.attempts++;
  s.points+=score;
  s.errors+=Number(meta.wrong||0);
  if(meta.helpUsed||score<1) s.help++;
  s.last=Date.now();
  state.skillLedger[id]=s;
}

recordTask = function(task,result){
  if(session?.gate || !task) return;
  const w=worlds.find(x=>x.id===task.world),i=worlds.indexOf(w);
  if(i<0) return;
  const x=RC43_rawStats(i);
  let score=0,meta={wrong:0,helpUsed:false};
  if(typeof result==='boolean') score=result?1:0;
  else if(result && typeof result==='object'){
    score=clamp(Number(result.score||0),0,1);
    meta={wrong:Number(result.wrong||0),helpUsed:!!result.helpUsed};
  }
  x.attempts++;
  if(score===1) x.independent++;
  else if(score>0) x.assisted++;
  x.weightedPoints+=score;
  x.successfulUnique=Array.isArray(x.successfulUnique)?x.successfulUnique:[];
  if(score>0&&!x.successfulUnique.includes(task.key))x.successfulUnique.push(task.key);
  x.errors+=meta.wrong;
  if(!x.unique.includes(task.key)) x.unique.push(task.key);
  x.unique=x.unique.slice(-320);
  x.history.push({score,skill:RC43_skillId(task),help:meta.helpUsed,wrong:meta.wrong,at:Date.now()});
  x.history=x.history.slice(-20);
  state.stats[w.id]=x;
  RC43_recordSkill(task,score,meta);
  state.total=(state.total||0)+1;
  state.daily=(state.dailyDay===day()?state.daily:0)+1;
  state.dailyDay=day();
  // Estrelas distinguem desempenho autônomo de desempenho assistido.
  state.stars=(state.stars||0)+(score===1?1:0);
  safeSave();
};

worldStats = function(i){
  const x=RC43_rawStats(i);
  const attempts=Number(x.attempts||0),independent=Number(x.independent||0);
  const weighted=Number(x.weightedPoints||0);
  const hist=(x.history||[]).slice(-8);
  const accuracy=attempts?Math.round(weighted/attempts*100):0;
  const independentAccuracy=attempts?Math.round(independent/attempts*100):0;
  const stability=hist.length?Math.round(hist.reduce((a,h)=>a+Number(h.score||0),0)/hist.length*100):accuracy;
  return {
    ...x,
    unique:(x.unique||[]).length,
    uniqueList:[...(x.unique||[])],
    accuracy,
    independentAccuracy,
    stability,
    stabilityEvidence:hist.length,
    assistedRate:attempts?Math.round(Number(x.assisted||0)/attempts*100):0
  };
};

function RC43_letterCoverage(){
  const u=RC55_evidence(0);
  const letters=new Set(),pairs=new Set(),forms={};
  for(const key of u){
    const p=String(key).split(':'),L=p[0];
    if(!/^[A-Z]$/.test(L)) continue;
    letters.add(L); forms[L]=forms[L]||new Set();
    if(p[1]==='case') pairs.add(L);
    if(p[1]==='lower' || (p[1]==='mixed'&&p[2]==='true')) forms[L].add('lower');
    if(p[1]==='upper' || (p[1]==='mixed'&&p[2]==='false')) forms[L].add('upper');
    if(forms[L].has('lower')&&forms[L].has('upper')) pairs.add(L);
  }
  return {letters,pairs,ratio:(letters.size/26)*.58+(pairs.size/26)*.42,pass:letters.size===26&&pairs.size===26};
}

function RC43_coverage(i){
  const u=RC55_evidence(i);
  if(i===0) return RC43_letterCoverage();
  if(i===1){
    const ini=u.filter(k=>String(k).startsWith('initial:')).length;
    const rhy=u.filter(k=>String(k).startsWith('rhyme:')).length;
    const ratio=Math.min(1,ini/8)*.6+Math.min(1,rhy/4)*.4;
    return{ratio,pass:ini>=8&&rhy>=4,label:`${ini} pares de som inicial · ${rhy} rimas`};
  }
  if(i===2){
    const gs=new Set(u.map(k=>String(k).split(':')[0]).filter(x=>/^[A-Z]$/.test(x)));
    return{ratio:Math.min(1,gs.size/14),pass:gs.size>=14,label:`${gs.size} relações som-letra`};
  }
  if(i===3){
    const modes=new Set(u.map(k=>String(k).split(':')[0]));
    const need=['first','last','count','join','remove'];
    const got=need.filter(x=>modes.has(x)).length;
    return{ratio:got/need.length,pass:got===need.length,label:`${got}/5 tipos silábicos`};
  }
  if(i===4){
    const words=new Set(u.map(k=>String(k).split(':').at(-1)));
    return{ratio:Math.min(1,words.size/18),pass:words.size>=18,label:`${words.size} palavras diferentes`};
  }
  if(i===5){
    return{ratio:Math.min(1,u.length/8),pass:u.length>=8,label:`${u.length} frases diferentes`};
  }
  const inferOld=new Set(['c3','c8','c10','c11','c12']);
  let infer=0,literal=0;
  for(const k0 of u){const k=String(k0);if(k.startsWith('infer:')||inferOld.has(k))infer++;else literal++;}
  return{ratio:Math.min(1,infer/4)*.65+Math.min(1,literal/2)*.35,pass:infer>=4&&literal>=2,label:`${infer} inferenciais · ${literal} literais`};
}

masteryReq = function(i){
  const base=(MASTERY_BY_GRADE[state.grade||'1º Ano']||reqs)[i]||reqs[i]||{attempts:12,unique:6,accuracy:72};
  const target=state.grade==='Pré-escola'?75:state.grade==='2º Ano'?80:78;
  const attempts=i===0?Math.max(base.attempts,52):base.attempts;
  return {...base,attempts,accuracy:Math.max(base.accuracy,target)};
};

progressPct = function(i){
  const r=masteryReq(i),s=worldStats(i),c=RC43_coverage(i);
  if(!r) return 100;
  const evidence=Math.min(1,s.attempts/r.attempts);
  const diversity=Math.min(1,s.unique/r.unique);
  const accuracy=Math.min(1,s.accuracy/r.accuracy);
  const stability=Math.min(1,s.stability/Math.max(1,r.accuracy-3));
  return Math.min(99,Math.round((evidence*.24+diversity*.16+accuracy*.27+stability*.15+Math.min(1,c.ratio)*.18)*100));
};

mastered = function(i){
  if(i<0) return true;
  const r=masteryReq(i),s=worldStats(i),c=RC43_coverage(i);
  const stable=s.stabilityEvidence>=8 && s.stability>=Math.max(70,r.accuracy-3);
  return s.attempts>=r.attempts && s.unique>=r.unique && s.accuracy>=r.accuracy && stable && c.pass;
};

unlocked = function(i){
  if(i===0) return true;
  // Não retirar acesso já conquistado antes da RC43.
  if(i<=RC43_PREVIOUS_NEXT_WORLD || state.entryIndex>=i || (state.bypass||[]).includes(i)) return true;
  // Acomodação: a consciência fonológica exclusivamente auditiva não vira barreira única.
  if(i===2 && state.accessibility?.hearingAccommodation) return true;
  return mastered(i-1);
};

function RC43_scoreForAnswer(){
  const wrong=Number(attempt.wrong||0),help=!!attempt.helpUsed||!!current?.review;
  if(wrong===0&&!help) return 1;
  if(wrong===0&&help) return .65;
  if(wrong===1) return help?.40:.45;
  return 0;
}

answer = function(v,isDiag){
  if(attempt.done) return;
  attempt.selected=v;
  const ok=String(v)===String(current.answer);
  if(ok){
    const score=RC43_scoreForAnswer();
    attempt.first=score===1;
    attempt.supportScore=score;
    attempt.done=true;
    attempt.praise=pick([`Muito bem, ${state.name||'Criança'}!`,`Ótimo trabalho, ${state.name||'Criança'}!`,`Você conseguiu, ${state.name||'Criança'}!`]);
    if(!isDiag){
      session.independent+=score===1?1:0;
      session.weighted=(session.weighted||0)+score;
      recordTask(current,{score,wrong:attempt.wrong||0,helpUsed:!!attempt.helpUsed});
      playSeq([pick(AUD.praise)]);
    }
    render();
  }else{
    attempt.wrong=(attempt.wrong||0)+1;
    if(!isDiag&&!session?.gate&&attempt.wrong===1) scheduleRetry(current);
    if(attempt.wrong>=2){
      attempt.first=false;
      attempt.supportScore=0;
      attempt.done=true;
      if(!isDiag) recordTask(current,{score:0,wrong:attempt.wrong,helpUsed:!!attempt.helpUsed});
      playSeq([AUD.model]);
      render();
    }else{
      playSeq([pick(AUD.try),...(current.audio||[])]);
      render();
    }
  }
};

function RC43_currentLetterEvidence(L){
  const u=RC55_evidence(0);
  const rows=u.filter(k=>String(k).startsWith(L+':'));
  return {seen:rows.length>0,paired:rows.some(k=>String(k).includes(':case')) || (rows.some(k=>String(k).includes(':lower'))&&rows.some(k=>String(k).includes(':upper')))};
}

function RC43_makeLetterTask(forceSkill){
  return uniqueTask(()=>{
    const cur=letterCurriculum();
    let pool=[...cur.pool];
    const forceLetter=String(forceSkill||'').match(/^letters:([A-Z])/)?.[1];
    let L=forceLetter&&pool.includes(forceLetter)?forceLetter:null;
    if(!L){
      const unpaired=pool.filter(x=>!RC43_currentLetterEvidence(x).paired);
      const unseen=pool.filter(x=>!RC43_currentLetterEvidence(x).seen);
      L=pick(unpaired.length?unpaired:unseen.length?unseen:pool);
    }
    const ev=RC43_currentLetterEvidence(L);
    let mode=!ev.paired?'case':pick(['listen','case','signs','mixed']);
    if(mode==='case'){
      const stim=Math.random()<.5?L:L.toLowerCase(),ans=stim===L?L.toLowerCase():L;
      return{world:'letters',skill:`letters:${L}:case`,key:`${L}:case`,sig:`rc43-case:${L}:${stim}`,command:'Ache a mesma letra em outra forma',audio:[AUDIO['prompt:same_letter']],kind:'letter',stimulus:{type:'letter',text:stim},options:shuffle([ans,...letterOpts(L,stim===L).filter(x=>x!==ans).slice(0,2)]),answer:ans};
    }
    if(mode==='signs'){
      return{world:'letters',skill:`letters:${L}:symbol`,key:`${L}:signs`,sig:`rc43-signs:${L}`,command:'Escute. Qual opção é a letra?',audio:[AUDIO['prompt:touch_letter'],AUDIO['letter:'+L]],kind:'letter',options:shuffle([L,pick(['?','!','7','@','#']),pick(['3','%','&','9'])]),answer:L};
    }
    const lower=Math.random()<.5,ans=lower?L.toLowerCase():L;
    if(mode==='mixed'){
      const other=pick(pool.filter(x=>x!==L));
      return{world:'letters',skill:`letters:${L}:${lower?'lower':'upper'}`,key:`${L}:mixed:${lower}`,sig:`rc43-mixed:${L}:${lower}:${other}`,command:'Escute e toque na letra',audio:[AUDIO['prompt:touch_letter'],AUDIO['letter:'+L]],kind:'letter',options:shuffle([ans,lower?other.toLowerCase():other,pick(['?','7','@'])]),answer:ans};
    }
    return{world:'letters',skill:`letters:${L}:${lower?'lower':'upper'}`,key:`${L}:${lower?'lower':'upper'}`,sig:`rc43-listen:${L}:${lower}`,command:'Escute e toque na letra',audio:[AUDIO['prompt:touch_letter'],AUDIO['letter:'+L]],kind:'letter',options:letterOpts(L,lower),answer:ans};
  });
}

const RC43_RHYMES=[
  ['GATO','PATO',['BOLA','MALA']],['PATO','GATO',['MESA','VACA']],
  ['MALA','BALA',['PATO','MOTO']],['BALA','MALA',['GATO','CASA']],
  ['VELA','TELA',['BOLA','PATO']],['TELA','VELA',['MALA','VACA']]
];

function RC43_makeSoundTask(forceMode){
  return uniqueTask(()=>{
    const raw=RC55_evidence(1);
    const initialCount=raw.filter(k=>String(k).startsWith('initial:')).length;
    const rhymeCount=raw.filter(k=>String(k).startsWith('rhyme:')).length;
    const mode=forceMode||(rhymeCount<4?'rhyme':initialCount<8?'initial':Math.random()<.68?'initial':'rhyme');
    if(mode==='rhyme'){
      const p=pick(RC43_RHYMES),base=WORDS.find(x=>x.w===p[0]),ansObj=WORDS.find(x=>x.w===p[1]),wrong=p[2].map(x=>WORDS.find(y=>y.w===x)).filter(Boolean);
      return{world:'sounds',skill:'phonology:rhyme',key:`rhyme:${p[0]}:${p[1]}`,sig:`rc43-rhyme:${p[0]}:${p[1]}`,command:'Qual termina com um som parecido?',audio:[AUDIO['prompt:listen_word'],AUDIO['word:'+p[0]],AUDIO['prompt:rhyme']],kind:'picture',stimulus:{type:'visual',word:base},options:shuffle([ansObj,...wrong]).map(x=>({value:x.w,pic:x.pic})),answer:ansObj.w,phonological:true};
    }
    const pool=soundPool();
    const groups=[...new Set(pool.map(x=>x.sound))].map(sound=>pool.filter(x=>x.sound===sound)).filter(g=>g.length>=2);
    const group=pick(groups),pair=shuffle(group).slice(0,2),model=pair[0],same=pair[1];
    const wrong=shuffle(pool.filter(x=>x.sound!==model.sound)).slice(0,2);
    return{world:'sounds',skill:'phonology:initial',key:`initial:${model.sound}:${model.w}`,sig:`rc43-initial:${model.w}:${same.w}`,command:'Qual figura começa com o mesmo som?',audio:[AUDIO['prompt:listen_word'],AUDIO['word:'+model.w],AUDIO['prompt:same_initial_sound']],kind:'picture',stimulus:{type:'visual',word:model},options:shuffle([same,...wrong]).map(x=>({value:x.w,pic:x.pic})),answer:same.w,phonological:true};
  });
}

function RC43_makeSyllableTask(forceMode){
  return uniqueTask(()=>{
    const cur=syllableCurriculum(),raw=RC55_evidence(3);
    const seenModes=new Set(raw.map(k=>String(k).split(':')[0]));
    let modes=state.grade==='Pré-escola'?cur.modes.filter(m=>['first','last','count'].includes(m)):[...cur.modes];
    if(state.grade!=='Pré-escola'&&cur.pool.some(x=>x.sy.length>=2)&&!modes.includes('remove')&&worldStats(3).attempts>=gradeProfile().syllable[1])modes.push('remove');
    let mode=forceMode&&modes.includes(forceMode)?forceMode:null;
    if(!mode){const missing=modes.filter(m=>!seenModes.has(m));mode=pick(missing.length?missing:modes);}
    const w=pick(cur.pool);
    if(mode==='first'){
      const ds=shuffle([...new Set(cur.pool.filter(x=>x.w!==w.w).map(x=>x.sy[0]))].filter(x=>x!==w.sy[0])).slice(0,2);
      return{world:'syllables',skill:'syllable:first',key:`first:${w.w}`,sig:`rc43-sy-first:${w.w}`,command:'Qual é o primeiro pedaço?',audio:[AUDIO['prompt:listen_word'],AUDIO['word:'+w.w],AUDIO['prompt:first_syllable']],kind:'word',stimulus:{type:'visual',word:w},options:shuffle([w.sy[0],...ds]),answer:w.sy[0]};
    }
    if(mode==='last'){
      const ans=w.sy.at(-1),ds=shuffle([...new Set(cur.pool.filter(x=>x.w!==w.w).map(x=>x.sy.at(-1)))].filter(x=>x!==ans)).slice(0,2);
      return{world:'syllables',skill:'syllable:last',key:`last:${w.w}`,sig:`rc43-sy-last:${w.w}`,command:'Qual é o último pedaço?',audio:[AUDIO['prompt:listen_word'],AUDIO['word:'+w.w],AUDIO['prompt:last_syllable']],kind:'word',stimulus:{type:'visual',word:w},options:shuffle([ans,...ds]),answer:ans};
    }
    if(mode==='count'){
      const ans=String(w.sy.length),opts=['1','2','3'].filter(x=>x!==ans).slice(0,2).concat(ans);
      return{world:'syllables',skill:'syllable:count',key:`count:${w.w}`,sig:`rc43-sy-count:${w.w}`,command:'Quantos pedaços você ouve?',audio:[AUDIO['prompt:listen_word'],AUDIO['word:'+w.w],AUDIO['prompt:count_syllables']],kind:'number',stimulus:{type:'visual',word:w},options:shuffle(opts),answer:ans};
    }
    if(mode==='remove'){
      const easy=cur.pool.filter(x=>x.sy.length===2),x=pick(easy.length?easy:cur.pool.filter(x=>x.sy.length>=2));
      const removeFirst=Math.random()<.5,ans=removeFirst?x.sy.slice(1).join(''):x.sy.slice(0,-1).join('');
      const distractors=shuffle([...new Set(cur.pool.flatMap(y=>y.sy).filter(s=>s!==ans))]).slice(0,2);
      return{world:'syllables',skill:'syllable:manipulation',key:`remove:${x.w}:${removeFirst?'first':'last'}`,sig:`rc43-sy-remove:${x.w}:${removeFirst}`,command:removeFirst?'Tire o primeiro pedaço. O que sobra?':'Tire o último pedaço. O que sobra?',audio:[AUDIO['prompt:listen_word'],AUDIO['word:'+x.w]],kind:'word',stimulus:{type:'syllables',items:x.sy},options:shuffle([ans,...distractors]),answer:ans};
    }
    const wrong=shuffle(cur.pool.filter(x=>x.w!==w.w)).slice(0,2);
    return{world:'syllables',skill:'syllable:join',key:`join:${w.w}`,sig:`rc43-sy-join:${w.w}`,command:'Junte os pedaços e escolha a palavra',audio:[AUDIO['prompt:join_syllables']],kind:'word',stimulus:{type:'syllables',items:w.sy},options:shuffle([w.w,...wrong.map(x=>x.w)]),answer:w.w};
  });
}

const RC43_STORIES=[
 {key:'i13',type:'inferential',story:'ANA PEGOU O GUARDA-CHUVA ANTES DE SAIR. O CÉU ESTAVA BEM ESCURO.',q:'O que provavelmente vai acontecer?',opts:[['VAI CHOVER','🌧️'],['VAI NEVAR','❄️'],['VAI FAZER MUITO SOL','☀️']],ans:'VAI CHOVER'},
 {key:'i14',type:'inferential',story:'LEO BOCEJOU MUITAS VEZES E APAGOU A LUZ DO QUARTO.',q:'Como Leo provavelmente está se sentindo?',opts:[['COM SONO','😴'],['COM FOME','🍽️'],['COM FRIO','🧣']],ans:'COM SONO'},
 {key:'i15',type:'inferential',story:'BIA COLOCOU ÁGUA NO POTE DO CACHORRO. ELE CORREU ATÉ O POTE.',q:'Por que o cachorro correu até o pote?',opts:[['ESTAVA COM SEDE','💧'],['QUERIA DORMIR','🛏️'],['QUERIA BRINCAR DE BOLA','⚽']],ans:'ESTAVA COM SEDE'},
 {key:'i16',type:'inferential',story:'A BOLA CAIU ATRÁS DO SOFÁ. PEDRO SE ABAIXOU E ESTICOU O BRAÇO.',q:'O que Pedro está tentando fazer?',opts:[['PEGAR A BOLA','⚽'],['ABRIR A JANELA','🪟'],['VESTIR O CASACO','🧥']],ans:'PEGAR A BOLA'},
 {key:'i17',type:'inferential',story:'MARIA VIU NUVENS ESCURAS E RECOLHEU AS ROUPAS DO VARAL.',q:'Por que Maria recolheu as roupas?',opts:[['PARA NÃO MOLHAREM','🌧️'],['PARA FICAREM MAIS PESADAS','🧺'],['PARA O SOL APARECER','☀️']],ans:'PARA NÃO MOLHAREM'},
 {key:'i18',type:'inferential',story:'O GATO FICOU PERTO DA PORTA QUANDO OUVIU O BARULHO DA CHAVE.',q:'O que provavelmente está acontecendo?',opts:[['ALGUÉM ESTÁ CHEGANDO','🚪'],['COMEÇOU A CHOVER','🌧️'],['A COMIDA ACABOU','🍽️']],ans:'ALGUÉM ESTÁ CHEGANDO'},
 {key:'i19',type:'inferential',story:'JOÃO ESTUDOU A TARDE TODA. NO DIA SEGUINTE, ACERTOU QUASE TODAS AS QUESTÕES.',q:'O que ajudou João a acertar as questões?',opts:[['ELE ESTUDOU','📚'],['ELE DORMIU TARDE','🌙'],['ELE PERDEU O CADERNO','📒']],ans:'ELE ESTUDOU'},
 {key:'i20',type:'inferential',story:'A PIPA PAROU DE SUBIR QUANDO O VENTO FICOU BEM FRACO.',q:'Por que a pipa parou de subir?',opts:[['FALTOU VENTO','💨'],['FALTOU ÁGUA','💧'],['FALTOU LUZ','💡']],ans:'FALTOU VENTO'},
 {key:'l21',type:'literal',story:'LIA COLOCOU A BOLA DENTRO DA CAIXA AZUL.',q:'Onde Lia colocou a bola?',opts:[['NA CAIXA','📦'],['NO LAGO','🌊'],['NA CAMA','🛏️']],ans:'NA CAIXA'},
 {key:'l22',type:'literal',story:'O PATO NADOU NO LAGO E DEPOIS FOI PARA A GRAMA.',q:'Onde o pato nadou?',opts:[['NO LAGO','🌊'],['NA CASA','🏠'],['NA NUVEM','☁️']],ans:'NO LAGO'},
 {key:'l23',type:'literal',story:'MILA LEVOU UM LIVRO E UMA PIPA PARA O PARQUE.',q:'O que Mila levou para o parque?',opts:[['UM LIVRO E UMA PIPA','📚'],['UMA MOTO E UM DADO','🏍️'],['UMA VELA E UM POTE','🕯️']],ans:'UM LIVRO E UMA PIPA'},
 {key:'l24',type:'literal',story:'O GALO CANTOU CEDO E A FAMÍLIA ACORDOU.',q:'Quem cantou cedo?',opts:[['O GALO','🐓'],['O GATO','🐱'],['O PATO','🦆']],ans:'O GALO'}
];

function RC43_makeComprehensionTask(forceType){
  return uniqueTask(()=>{
    let pool=RC43_STORIES;
    if(state.grade==='Pré-escola') pool=RC43_STORIES.filter(x=>x.key==='i14'||x.key==='i16'||x.key==='i18'||x.type==='literal');
    if(forceType) pool=pool.filter(x=>x.type===forceType);
    const x=pick(pool.length?pool:RC43_STORIES);
    return{world:'comprehension',skill:`comprehension:${x.type}`,key:`${x.type==='inferential'?'infer':'literal'}:${x.key}`,sig:`rc43-comp:${x.key}`,command:x.q,audio:[AUDIO['prompt:read_answer']],kind:'picture',stimulus:{type:'story',text:x.story},options:shuffle(x.opts.map(o=>({value:o[0],pic:o[1]}))),answer:x.ans};
  });
}

function RC43_tagTask(t,i){
  if(!t) return t;
  if(!t.skill) t.skill=RC43_skillId(t);
  if(i===1) t.phonological=true;
  return t;
}

makeTask = function(i){
  if(i===0) return RC43_makeLetterTask();
  if(i===1) return RC43_makeSoundTask();
  if(i===3) return RC43_makeSyllableTask();
  if(i===6){
    const raw=RC55_evidence(6),infer=raw.filter(k=>String(k).startsWith('infer:')).length;
    if(state.grade!=='Pré-escola' || Math.random()<.5) return RC43_makeComprehensionTask(infer<4?'inferential':(Math.random()<.65?'inferential':null));
  }
  return RC43_tagTask(RC43_ORIGINALS.makeTask(i),i);
};

function RC43_weakSkillForWorld(i){
  const prefixes=['letters:','phonology:','grapheme:','syllable:','word:','sentence:','comprehension:'];
  const p=prefixes[i],rows=Object.entries(state.skillLedger||{}).filter(([k,v])=>k.startsWith(p)&&v.attempts>0);
  if(!rows.length) return null;
  rows.sort((a,b)=>((a[1].points/a[1].attempts)-(b[1].points/b[1].attempts)) || (a[1].last-b[1].last));
  const [id,v]=rows[0];
  return (v.points/v.attempts)<.82?id:null;
}

function RC43_taskForWeakSkill(i,id){
  if(!id) return null;
  if(i===0) return RC43_makeLetterTask(id);
  if(i===1) return RC43_makeSoundTask(id.endsWith('rhyme')?'rhyme':'initial');
  if(i===3){
    const map={first:'first',last:'last',count:'count',join:'join',manipulation:'remove'};
    return RC43_makeSyllableTask(map[id.split(':')[1]]||null);
  }
  if(i===6) return RC43_makeComprehensionTask(id.endsWith('inferential')?'inferential':'literal');
  return null;
}

nextSessionTask = function(){
  const q=session?.retryQueue||[],idx=q.findIndex(x=>x.at<=(session.done||0));
  if(idx>=0){const x=q.splice(idx,1)[0];return{...x.task,sig:`${x.task.sig}:review:${session.done}`,review:true,skill:x.task.skill||RC43_skillId(x.task)}}
  const weak=RC43_weakSkillForWorld(session?.world??0);
  if(weak){const t=RC43_taskForWeakSkill(session.world,weak);if(t)return t;}
  return session?.guided?makeGuidedTask(session.world,session.done):makeTask(session.world);
};

// Três perfis sonoros realmente audíveis usando os áudios locais, sem TTS/API em tempo de uso.
playOne = async function(src){
  if(!src) return false;
  try{
    if(voiceAudio){voiceAudio.pause();voiceAudio=null}
    duck(true);
    voiceAudio=new Audio(src);
    voiceAudio.volume=voiceLevel/100;
    const profile=RC43_VOICE_PROFILES[state.voiceProfile]||RC43_VOICE_PROFILES.natural;
    voiceAudio.playbackRate=profile.rate;
    try{voiceAudio.preservesPitch=false;voiceAudio.webkitPreservesPitch=false;}catch(e){}
    await voiceAudio.play();
    return await new Promise(r=>{
      let ended=false;
      const done=v=>{if(ended)return;ended=true;duck(false);r(v)};
      voiceAudio.onended=()=>done(true);
      voiceAudio.onerror=()=>done(false);
      setTimeout(()=>done(false),10000);
    });
  }catch(e){duck(false);return false}
};

function RC43_applyAccessibility(){
  const root=document.documentElement,a=state.accessibility||{};
  root.classList.toggle('rc43-large-text',!!a.largeText);
  root.classList.toggle('rc43-high-contrast',!!a.highContrast);
  root.classList.toggle('rc43-reduce-motion',!!a.reduceMotion);
}
RC43_applyAccessibility();

function RC43_voiceControlsHtml(compact=false){
  return `<div class="rc43-voice-choice ${compact?'compact':''}" role="group" aria-label="Escolha do estilo de voz da professora">
    <div class="rc43-control-title">Voz da professora</div>
    <div class="rc43-choice-row">${Object.entries(RC43_VOICE_PROFILES).map(([id,p])=>`<button type="button" class="rc43-voice-btn ${state.voiceProfile===id?'sel':''}" data-rc43-voice="${id}" aria-pressed="${state.voiceProfile===id?'true':'false'}"><b>${p.label}</b><small>${p.note}</small></button>`).join('')}</div>
    <button type="button" class="soft rc43-test-voice">▶ Ouvir a voz escolhida</button>
  </div>`;
}

function RC43_bindVoiceControls(scope=document){
  scope.querySelectorAll('[data-rc43-voice]').forEach(b=>b.onclick=()=>{
    state.voiceProfile=b.dataset.rc43Voice;
    safeSave();
    scope.querySelectorAll('[data-rc43-voice]').forEach(x=>{const sel=x.dataset.rc43Voice===state.voiceProfile;x.classList.toggle('sel',sel);x.setAttribute('aria-pressed',String(sel));});
    playSeq([pick(AUD.praise)]);
  });
  scope.querySelectorAll('.rc43-test-voice').forEach(b=>b.onclick=()=>playSeq([pick(AUD.praise)]));
}

function RC43_enhanceOnboarding(){
  if(view!=='onboardGuide') return;
  const card=document.querySelector('.onboarding');
  if(!card||card.querySelector('.rc43-voice-choice')) return;
  const input=card.querySelector('#guide');
  if(input) input.insertAdjacentHTML('beforebegin',RC43_voiceControlsHtml(true));
  RC43_bindVoiceControls(card);
}

onboarding = function(){
  RC43_ORIGINALS.onboarding();
  RC43_enhanceOnboarding();
};

function RC43_accessibilityPanelHtml(){
  const a=state.accessibility||{};
  return `<div class="rc43-a11y-panel"><h2>Acessibilidade</h2><p>Os ajustes abaixo ficam somente neste aparelho.</p>
    <label class="rc43-check"><input type="checkbox" data-rc43-a11y="largeText" ${a.largeText?'checked':''}> <span><b>Texto maior</b><small>Aumenta a legibilidade sem alterar o conteúdo.</small></span></label>
    <label class="rc43-check"><input type="checkbox" data-rc43-a11y="highContrast" ${a.highContrast?'checked':''}> <span><b>Contraste reforçado</b><small>Realça bordas, botões e foco.</small></span></label>
    <label class="rc43-check"><input type="checkbox" data-rc43-a11y="reduceMotion" ${a.reduceMotion?'checked':''}> <span><b>Reduzir animações</b><small>Evita movimentos desnecessários.</small></span></label>
    <label class="rc43-check"><input type="checkbox" data-rc43-a11y="hearingAccommodation" ${a.hearingAccommodation?'checked':''}> <span><b>Acomodação auditiva</b><small>Desafios exclusivamente auditivos deixam de ser a única trava de avanço.</small></span></label>
  </div>`;
}

function RC43_enhanceAdult(){
  const card=document.querySelector('.card.adult');
  if(!card) return;
  if(!card.querySelector('.rc43-voice-choice')){
    const family=card.querySelector('.family-teacher');
    if(family) family.insertAdjacentHTML('afterend',RC43_voiceControlsHtml(false));
  }
  if(!card.querySelector('.rc43-a11y-panel')){
    const sound=card.querySelector('.sound-settings');
    if(sound) sound.insertAdjacentHTML('afterend',RC43_accessibilityPanelHtml());
  }
  RC43_bindVoiceControls(card);
  card.querySelectorAll('[data-rc43-a11y]').forEach(el=>el.onchange=()=>{
    state.accessibility[el.dataset.rc43A11y]=!!el.checked;
    safeSave();RC43_applyAccessibility();
  });
  card.querySelectorAll('.adult-row').forEach((row,i)=>{
    if(row.querySelector('.rc43-mastery-line')) return;
    const s=worldStats(i),c=RC43_coverage(i),r=masteryReq(i);
    row.insertAdjacentHTML('beforeend',`<div class="rc43-mastery-line"><b>Domínio efetivo: ${s.accuracy}%</b><span>Autônomo: ${s.independentAccuracy}% · estabilidade: ${s.stability}% · ajuda: ${s.assistedRate}%</span><small>${escapeHtml(c.label||'Cobertura pedagógica em progressão')} · meta ${r.accuracy}%</small></div>`);
  });
}

adult = function(){RC43_ORIGINALS.adult();RC43_enhanceAdult();};

function RC43_supportLabel(score){
  if(score===1)return 'Resposta autônoma — valor integral para domínio';
  if(score>=.6)return 'Resposta com ajuda — valor parcial para domínio';
  if(score>0)return 'Resposta após tentativa — valor reduzido para domínio';
  return 'Item será retomado — ainda não conta como domínio';
}

function RC43_enhanceActivity(isDiag){
  const card=document.querySelector('.card.lesson');if(!card)return;
  const command=card.querySelector('.command');
  if(command) command.setAttribute('id','rc43-command');
  const ch=card.querySelector('.choices');if(ch)ch.setAttribute('aria-describedby','rc43-command');
  if(!attempt.done){
    if(!card.querySelector('.rc43-help-btn')){
      const audio=card.querySelector('#audio');
      const btn=document.createElement('button');btn.type='button';btn.className='secondary rc43-help-btn';btn.textContent='💡 Preciso de uma dica';btn.setAttribute('aria-label','Receber uma dica desta atividade');
      btn.onclick=()=>{attempt.helpUsed=true;attempt.helpCount=(attempt.helpCount||0)+1;render();RC55_scheduleTaskAudio(80)};
      audio?.insertAdjacentElement('afterend',btn);
    }
    if(attempt.helpUsed&&!card.querySelector('.rc43-voluntary-hint')){
      const d=document.createElement('div');d.className='feedback hint rc43-voluntary-hint';d.setAttribute('role','status');d.textContent=hintForTask(current);card.querySelector('.choices')?.insertAdjacentElement('beforebegin',d);
    }
  }
  const feedback=card.querySelector('.feedback');if(feedback){feedback.setAttribute('role','status');feedback.setAttribute('aria-live','polite');}
  const teacher=card.querySelector('.teacher-feedback');if(teacher){teacher.setAttribute('role','status');teacher.setAttribute('aria-live','polite');}
  if(attempt.done&&!isDiag&&!card.querySelector('.rc43-score-note')){
    const score=Number(attempt.supportScore||0),note=document.createElement('div');note.className='rc43-score-note';note.textContent=RC43_supportLabel(score);card.querySelector('#next')?.insertAdjacentElement('beforebegin',note);
  }
  if(current?.phonological&&!card.querySelector('.rc43-construct-badge')){
    const b=document.createElement('div');b.className='rc43-construct-badge';b.textContent='Atividade de escuta — sem palavra escrita como pista';card.querySelector('.command')?.insertAdjacentElement('beforebegin',b);
  }
}

activity = function(isDiag){RC43_ORIGINALS.activity(isDiag);RC43_enhanceActivity(isDiag);};

// Botão de volume sempre acessível no ambiente infantil.
(function RC43_installVolumeControl(){
  if(document.querySelector('#volumeFab')) return;
  const music=document.querySelector('#musicFab');if(!music)return;
  music.insertAdjacentHTML('afterend',`<button id="volumeFab" class="music-fab rc43-volume-fab hidden" type="button" aria-label="Ajustar volume" aria-expanded="false">🔊</button>
    <div id="volumePanel" class="rc43-volume-panel hidden" role="dialog" aria-label="Controles de volume">
      <label>Voz <input id="quickVoiceVol" type="range" min="0" max="100" step="5" value="${voiceLevel}"><output id="quickVoiceOut">${voiceLevel}%</output></label>
      <label>Música <input id="quickMusicVol" type="range" min="0" max="100" step="5" value="${musicLevel}"><output id="quickMusicOut">${musicLevel}%</output></label>
      <button type="button" class="soft" id="quickVoiceTest">▶ Testar voz</button>
    </div>`);
  const fab=document.querySelector('#volumeFab'),panel=document.querySelector('#volumePanel');
  fab.onclick=()=>{const open=panel.classList.toggle('hidden')===false;fab.setAttribute('aria-expanded',String(open));};
  document.querySelector('#quickVoiceVol').oninput=e=>{setVoiceLevel(e.target.value);document.querySelector('#quickVoiceOut').textContent=voiceLevel+'%'};
  document.querySelector('#quickMusicVol').oninput=e=>{setMusicLevel(e.target.value);document.querySelector('#quickMusicOut').textContent=musicLevel+'%';if(musicOn&&musicLevel>0)startMusic()};
  document.querySelector('#quickVoiceTest').onclick=()=>playSeq([pick(AUD.praise)]);
})();

setTop = function(show=true){
  RC43_ORIGINALS.setTop(show);
  const v=document.querySelector('#volumeFab');if(v)v.classList.toggle('hidden',!show);
  if(!show){const p=document.querySelector('#volumePanel');if(p)p.classList.add('hidden');}
};

// Reaplica a tela corrente com a nova camada pedagógica já ativa.
RC43_applyAccessibility();
render();



/* ===== rc44-pedagogical-final-hotfix ===== */

/* Intelectus Alfabetização — RC Pedagógica Final V44
   Fecha o gate de cobertura som+letra conforme o banco sonoro efetivamente disponível
   e corrige a semântica dos indicadores no painel familiar. */
const RC44_VERSION=44;

const RC44_PREV_COVERAGE=RC43_coverage;
RC43_coverage=function(i){
  if(i===2){
    const u=RC55_evidence(i);
    const gs=new Set(u.map(k=>String(k).split(':')[0]).filter(x=>/^[A-Z]$/.test(x)));
    // O banco auditivo validado da V42 contém 12 relações iniciais distintas.
    // A meta não pode exigir uma 13ª/14ª relação inexistente no banco de palavras/áudios.
    const target=12;
    return{ratio:Math.min(1,gs.size/target),pass:gs.size>=target,label:`${gs.size}/${target} relações som-letra do banco auditivo`};
  }
  return RC44_PREV_COVERAGE(i);
};

// A interface oferece estilos audivelmente distintos da mesma locução local.
RC43_voiceControlsHtml=function(compact=false){
  return `<div class="rc43-voice-choice ${compact?'compact':''}" role="group" aria-label="Escolha do estilo de voz da professora">
    <div class="rc43-control-title">Estilo da voz da professora</div>
    <div class="rc43-choice-row">${Object.entries(RC43_VOICE_PROFILES).map(([id,p])=>`<button type="button" class="rc43-voice-btn ${state.voiceProfile===id?'sel':''}" data-rc43-voice="${id}" aria-pressed="${state.voiceProfile===id?'true':'false'}"><b>${p.label}</b><small>${p.note}</small></button>`).join('')}</div>
    <button type="button" class="soft rc43-test-voice">▶ Ouvir o estilo escolhido</button>
  </div>`;
};

const RC44_PREV_ENHANCE_ADULT=RC43_enhanceAdult;
RC43_enhanceAdult=function(){
  RC44_PREV_ENHANCE_ADULT();
  const card=document.querySelector('.card.adult');
  if(!card) return;
  card.querySelectorAll('.adult-row').forEach((row,i)=>{
    const s=worldStats(i);
    Array.from(row.children).forEach(el=>{
      if(el.classList?.contains('rc43-mastery-line')) return;
      if((el.textContent||'').includes('práticas')&&(el.textContent||'').includes('sem ajuda')){
        el.textContent=`${s.attempts} práticas · ${s.independentAccuracy}% autônomas · ${s.unique} exemplos/habilidades vistos`;
      }
    });
  });
  if(!card.querySelector('.rc44-version-note')){
    const h=card.querySelector('h1');
    h?.insertAdjacentHTML('afterend','<div class="rc44-version-note" role="status">RC Pedagógica Final V44 · domínio ponderado, estabilidade e cobertura curricular ativa</div>');
  }
};

adult=function(){RC43_ORIGINALS.adult();RC43_enhanceAdult();};

// Re-render seguro para aplicar a correção na tela corrente.
render();



/* ===== rc45-visual-hotfix ===== */

/* Intelectus Alfabetização — RC Pedagógica Final V45
   Hotfix visual: evita sobreposição dos FABs de áudio na Área da Família. */
const RC45_VERSION=45;
const RC45_PREV_ENHANCE_ADULT=RC43_enhanceAdult;
RC43_enhanceAdult=function(){
  RC45_PREV_ENHANCE_ADULT();
  ['#musicFab','#volumeFab','#volumePanel'].forEach(sel=>document.querySelector(sel)?.classList.add('hidden'));
};
adult=function(){RC43_ORIGINALS.adult();RC43_enhanceAdult();};
render();



/* ===== rc47-pedagogical-10 ===== */

/* Intelectus Alfabetização — RC Pedagógica 10 V47
   Ampliação curricular: Educação Infantil própria, cursiva, produção escrita,
   fonologia inicial/final, manipulação silábica e estruturas V/CVC/CCV.
   Sem APIs/TTS/serviços pagos em tempo de uso. */
const RC47_VERSION=47;

const RC47_COMPLEX_WORDS=[
  {w:'OVO',sy:['O','VO'],pattern:'V',pic:'🥚',level:2},
  {w:'SOL',sy:['SOL'],pattern:'CVC',pic:'☀️',level:2},
  {w:'MAR',sy:['MAR'],pattern:'CVC',pic:'🌊',level:2},
  {w:'PRATO',sy:['PRA','TO'],pattern:'CCV',pic:'🍽️',level:2},
  {w:'PLACA',sy:['PLA','CA'],pattern:'CCV',pic:'🪧',level:2},
  {w:'GRAMA',sy:['GRA','MA'],pattern:'CCV',pic:'🌿',level:2},
  {w:'FRUTA',sy:['FRU','TA'],pattern:'CCV',pic:'🍎',level:2},
  {w:'BRINCO',sy:['BRIN','CO'],pattern:'CCVC',pic:'💎',level:2},
  {w:'VENTO',sy:['VEN','TO'],pattern:'CVC',pic:'💨',level:2},
  {w:'PONTE',sy:['PON','TE'],pattern:'CVC',pic:'🌉',level:2}
];
const RC47_REPLACEMENTS=[
  {from:'PATO',sy:['PA','TO'],pos:'initial',index:0,newSy:'GA',answer:'GATO',wrong:['MATO','PATA']},
  {from:'GATO',sy:['GA','TO'],pos:'final',index:1,newSy:'TA',answer:'GATA',wrong:['GOTA','PATA']},
  {from:'CAMELO',sy:['CA','ME','LO'],pos:'medial',index:1,newSy:'BE',answer:'CABELO',wrong:['CAMELO','CANELO']},
  {from:'PANELA',sy:['PA','NE','LA'],pos:'initial',index:0,newSy:'CA',answer:'CANELA',wrong:['PANELA','CAVELA']},
  {from:'BONECA',sy:['BO','NE','CA'],pos:'initial',index:0,newSy:'CA',answer:'CANECA',wrong:['BONECA','CANECO']},
  {from:'BOLA',sy:['BO','LA'],pos:'final',index:1,newSy:'LO',answer:'BOLO',wrong:['BOLA','MOLA']}
];
const RC47_FINAL_SOUND_SETS=[
  ['BOLA','MALA',['PATO','MESA']],
  ['PATO','GATO',['BOLA','MESA']],
  ['VELA','TELA',['PATO','MOTO']],
  ['CASA','MESA',['PATO','BOLA']],
  ['MOTO','PATO',['MALA','NUVEM']],
  ['POTE','TOMATE',['BOLA','CASA']]
];
const RC47_SENTENCE_WRITING=[
  {key:'gato-dorme',scene:'🐱💤',keywords:['GATO','DORME'],model:'O GATO DORME.'},
  {key:'pato-nada',scene:'🦆🌊',keywords:['PATO','NADA'],model:'O PATO NADA.'},
  {key:'lia-bola',scene:'👧⚽',keywords:['LIA','BOLA'],model:'LIA TEM UMA BOLA.'},
  {key:'sol-brilha',scene:'☀️✨',keywords:['SOL','BRILHA'],model:'O SOL BRILHA.'},
  {key:'sapo-pula',scene:'🐸🌿',keywords:['SAPO','PULA'],model:'O SAPO PULA.'},
  {key:'pipa-voa',scene:'🪁🌤️',keywords:['PIPA','VOA'],model:'A PIPA VOA.'}
];
const RC47_EI_EXPERIENCES=[
  {id:'oral-reconto',code:'EI03EF04',label:'Reconto oral',instruction:'Ouça a história e depois conte com suas palavras o que aconteceu com Lia.',scene:'👧⚽',audio:[AUDIO['story:c1_historia']]},
  {id:'oral-historia',code:'EI03EF06',label:'História própria',instruction:'Invente uma pequena história para esta cena.',scene:'🚀🌙'},
  {id:'escrita-espontanea',code:'EI03EF09',label:'Escrita espontânea',instruction:'Escreva do seu jeito uma palavra para esta figura.',scene:'⚽'},
  {id:'rima-criativa',code:'EI03EF02',label:'Brincadeira sonora',instruction:'Fale outra palavra que combine no som com GATO.',scene:'🐱'}
];
const RC47_BNCC={
  'Pré-escola':['EI03EF01','EI03EF02','EI03EF04','EI03EF06','EI03EF09'],
  '1º Ano':['EF01LP02','EF01LP03','EF01LP04','EF01LP05','EF01LP06','EF01LP07','EF01LP08','EF01LP09','EF01LP10','EF01LP11','EF01LP12','EF01LP13','EF12LP01'],
  '2º Ano':['EF02LP01','EF02LP02','EF02LP03','EF02LP04','EF02LP05','EF02LP07','EF02LP08','EF02LP09','EF12LP01']
};

// Atualiza a rastreabilidade curricular exibida nos mundos.
function RC47_addBncc(i,codes){worlds[i].bncc=[...new Set([...(worlds[i].bncc||[]),...codes])];}
RC47_addBncc(0,['EF01LP11','EF02LP07']);
RC47_addBncc(1,['EF01LP09','EF01LP13']);
RC47_addBncc(2,['EF01LP05','EF01LP07','EF01LP08','EF02LP03']);
RC47_addBncc(3,['EF02LP02','EF02LP04','EF02LP05']);
RC47_addBncc(4,['EF01LP02','EF01LP03','EF02LP03','EF02LP04','EF02LP05','EF02LP07']);
RC47_addBncc(5,['EF02LP01','EF02LP07','EF02LP08','EF02LP09']);
RC47_addBncc(6,['EF12LP02','EF15LP18']);

state.rcPedagogicalVersion=RC47_VERSION;
state.eiLedger=state.eiLedger&&typeof state.eiLedger==='object'?state.eiLedger:{};
safeSave();

const RC47_STYLE=document.createElement('style');
RC47_STYLE.id='rc47-pedagogical-10-style';
RC47_STYLE.textContent=`
.rc47-cursive{font-family:"Segoe Script","Bradley Hand","Comic Sans MS",cursive;font-style:italic;font-weight:700;line-height:1;color:#123d66}
.rc47-cursive.big{font-size:clamp(86px,24vw,150px)}
.rc47-writing{display:grid;gap:10px;margin:8px 0 2px}.rc47-writing input,.rc47-writing textarea{width:100%;border:3px solid #d7e6ed;border-radius:18px;background:#fff;padding:14px 15px;color:#173b5e;font:900 20px/1.35 ui-rounded,system-ui,sans-serif;text-transform:uppercase}.rc47-writing textarea{min-height:110px;resize:vertical}.rc47-writing input:focus,.rc47-writing textarea:focus{border-color:#2b87d5;outline:4px solid rgba(43,135,213,.16)}
.rc47-write-note{font-size:12px;line-height:1.4;color:#58718a;font-weight:800;text-align:center}.rc47-model{margin-top:9px;padding:10px 12px;border-radius:14px;background:#eef8ff;color:#245270;font-weight:850;text-align:center}.rc47-experience{padding:14px;border:2px dashed #83c7a0;border-radius:20px;background:#f1fff5;text-align:center}.rc47-experience b{display:block;color:#0e7d41;font-size:16px}.rc47-experience p{margin:7px 0;color:#496b5a;font-weight:750}.rc47-ei-badge{display:inline-block;margin-bottom:8px;padding:5px 9px;border-radius:999px;background:#e6f8ec;color:#137b40;font-size:11px;font-weight:950}
.rc47-pattern{display:grid;gap:9px;text-align:center}.rc47-pattern .focus-syllable{display:inline-block;padding:10px 14px;border-radius:14px;background:#fff1b8;color:#614b00;font-size:34px;font-weight:1000}.rc47-pattern small{color:#61788d;font-weight:800}.rc47-bncc-trace{margin:16px 0;padding:15px;border:1px solid #dce9ef;border-radius:18px;background:linear-gradient(135deg,#f4fbff,#f5fff1)}.rc47-bncc-trace h2{margin:0 0 6px;font-size:19px}.rc47-bncc-codes{display:flex;flex-wrap:wrap;gap:6px;margin-top:9px}.rc47-bncc-codes span{padding:5px 8px;border-radius:999px;background:#fff;border:1px solid #cfe2eb;font-size:10px;font-weight:900;color:#33576d}.rc47-bncc-trace p{margin:0;color:#60778f;font-size:12px;line-height:1.45;font-weight:750}
.rc47-trace-wrap{position:relative;max-width:360px;height:220px;margin:8px auto;border:3px solid #dbe9ef;border-radius:22px;background:#fff;overflow:hidden}.rc47-trace-guide{position:absolute;inset:0;display:grid;place-items:center;font-size:150px;opacity:.16;pointer-events:none}.rc47-trace-wrap canvas{position:absolute;inset:0;width:100%;height:100%;touch-action:none}.rc47-trace-actions{display:flex;gap:8px;justify-content:center;flex-wrap:wrap}.rc47-construct-note{margin:7px auto 12px;max-width:620px;font-size:11px;line-height:1.4;color:#536f82;text-align:center;font-weight:800}
@media(max-width:430px){.rc47-writing input,.rc47-writing textarea{font-size:18px}.rc47-trace-wrap{height:190px}.rc47-trace-guide{font-size:125px}}
`;
document.head.appendChild(RC47_STYLE);

function RC47_norm(v){return String(v||'').normalize('NFD').replace(/[\u0300-\u036f]/g,'').toUpperCase().replace(/[^A-Z0-9?! ]+/g,' ').replace(/\s+/g,' ').trim();}
function RC47_seen(prefix,worldIndex){return (RC55_evidence(worldIndex)).filter(k=>String(k).startsWith(prefix));}

// Cursiva: relação explícita entre forma cursiva e forma de imprensa.
function RC47_makeCursiveTask(forceLetter){
  return uniqueTask(()=>{
    const seen=new Set(RC47_seen('',0).filter(k=>String(k).includes(':cursive')).map(k=>String(k).split(':')[0]));
    const pool='ABCDEFGHIJKLMNOPQRSTUVWXYZ'.split('');
    const L=forceLetter||pick(pool.filter(x=>!seen.has(x)).length?pool.filter(x=>!seen.has(x)):pool);
    const lower=Math.random()<.68;
    const ans=lower?L.toLowerCase():L;
    const ds=shuffle(pool.filter(x=>x!==L)).slice(0,2).map(x=>lower?x.toLowerCase():x);
    return{world:'letters',skill:`letters:${L}:cursive`,key:`${L}:cursive`,sig:`rc47-cursive:${L}:${lower}`,command:'Qual letra de imprensa corresponde a esta letra cursiva?',audio:[AUDIO['prompt:same_letter']],kind:'letter',stimulus:{type:'rc47-cursive',text:ans},options:shuffle([ans,...ds]),answer:ans};
  });
}

const RC47_PREV_STIMULUS=stimulus;
stimulus=function(t){
  const s=t?.stimulus;
  if(s?.type==='rc47-cursive')return `<div class="stimulus"><div class="rc47-cursive big" aria-label="Letra cursiva ${escapeHtml(s.text)}">${escapeHtml(s.text)}</div></div>`;
  if(s?.type==='rc47-pattern')return `<div class="stimulus"><div class="rc47-pattern"><div>${escapeHtml(s.word)}</div><div class="focus-syllable">${escapeHtml(s.focus)}</div><small>${escapeHtml(s.note||'Observe a estrutura da sílaba destacada.')}</small></div></div>`;
  return RC47_PREV_STIMULUS(t);
};

// Consciência fonológica: acrescenta comparação de final sonoro sem mostrar a palavra escrita.
function RC47_makeFinalSoundTask(){
  return uniqueTask(()=>{
    const p=pick(RC47_FINAL_SOUND_SETS),base=WORDS.find(x=>x.w===p[0]),ansObj=WORDS.find(x=>x.w===p[1]),wrong=p[2].map(n=>WORDS.find(x=>x.w===n)).filter(Boolean);
    return{world:'sounds',skill:'phonology:final',key:`final:${p[0]}:${p[1]}`,sig:`rc47-final:${p[0]}:${p[1]}`,command:'Qual figura termina com o mesmo pedaço sonoro?',audio:[AUDIO['prompt:listen_word'],AUDIO['word:'+p[0]]],kind:'picture',stimulus:{type:'visual',word:base},options:shuffle([ansObj,...wrong]).map(x=>({value:x.w,pic:x.pic})),answer:ansObj.w,phonological:true};
  });
}

// Manipulação: sílaba medial e substituição inicial/medial/final.
function RC47_makeMiddleSyllableTask(){
  return uniqueTask(()=>{
    const pool=WORDS.filter(x=>x.sy.length===3),w=pick(pool),ans=w.sy[1];
    const distractors=shuffle([...new Set(WORDS.flatMap(x=>x.sy).filter(x=>x!==ans))]).slice(0,2);
    return{world:'syllables',skill:'syllable:middle',key:`middle:${w.w}`,sig:`rc47-middle:${w.w}`,command:'Qual é o pedaço do meio?',audio:[AUDIO['prompt:listen_word'],AUDIO['word:'+w.w]],kind:'word',stimulus:{type:'visual',word:w},options:shuffle([ans,...distractors]),answer:ans};
  });
}
function RC47_makeReplaceSyllableTask(){
  return uniqueTask(()=>{
    const x=pick(RC47_REPLACEMENTS),items=[...x.sy];
    const where=x.pos==='initial'?'primeiro':x.pos==='medial'?'do meio':'último';
    return{world:'syllables',skill:`syllable:replace:${x.pos}`,key:`replace:${x.pos}:${x.from}:${x.answer}`,sig:`rc47-replace:${x.pos}:${x.from}`,command:`Troque o pedaço ${where} por ${x.newSy}. Qual palavra se forma?`,audio:[],kind:'word',stimulus:{type:'syllables',items},options:shuffle([x.answer,...x.wrong]),answer:x.answer};
  });
}
function RC47_makePatternTask(){
  return uniqueTask(()=>{
    const groups={V:RC47_COMPLEX_WORDS.filter(x=>x.pattern==='V'),CVC:RC47_COMPLEX_WORDS.filter(x=>x.pattern==='CVC'),CCV:RC47_COMPLEX_WORDS.filter(x=>x.pattern==='CCV')};
    const pattern=pick(['V','CVC','CCV']),x=pick(groups[pattern]),focus=x.sy[0];
    const labels={V:'só vogal',CVC:'consoante + vogal + consoante',CCV:'duas consoantes + vogal'};
    return{world:'syllables',skill:`syllable:pattern:${pattern}`,key:`pattern:${pattern}:${x.w}`,sig:`rc47-pattern:${pattern}:${x.w}`,command:'Que tipo de sílaba aparece destacada?',audio:[],kind:'word',stimulus:{type:'rc47-pattern',word:x.w,focus,note:'Leia a palavra e observe a sílaba destacada.'},options:shuffle([pattern,...['V','CVC','CCV'].filter(p=>p!==pattern)]),answer:pattern,hint:`${pattern} significa ${labels[pattern]}.`};
  });
}

// Escrita produtiva: palavra ou frase produzida pela criança, sem IA/API externa.
function RC47_makeWordWritingTask(){
  return uniqueTask(()=>{
    const pool=state.grade==='2º Ano'?[...WORDS.filter(x=>x.level<=2),...RC47_COMPLEX_WORDS.filter(x=>!['BRINCO','FRUTA'].includes(x.w))]:WORDS.filter(x=>x.level===1);
    const x=pick(pool);
    return{world:'words',skill:'word:productive-writing',key:`write:${x.w}`,sig:`rc47-write-word:${x.w}`,command:'Escreva o nome da figura',audio:AUDIO['word:'+x.w]?[AUDIO['prompt:look_choose_word'],AUDIO['word:'+x.w]]:[],kind:'writing',writeMode:'word',stimulus:{type:'visual',word:x},options:[],answer:x.w,placeholder:'Digite a palavra',writeHint:`Começa com ${x.w[0]}.`};
  });
}
function RC47_makeSentenceWritingTask(){
  return uniqueTask(()=>{
    const x=pick(RC47_SENTENCE_WRITING);
    return{world:'sentences',skill:'sentence:productive-writing',key:`write-sentence:${x.key}`,sig:`rc47-write-sentence:${x.key}`,command:'Escreva uma frase que combine com a cena',audio:[],kind:'writing',writeMode:'sentence',stimulus:{type:'scene',text:x.scene},options:[],answer:x.model,keywords:x.keywords,placeholder:'Escreva sua frase',writeHint:`Use as ideias: ${x.keywords.join(' + ')}.`};
  });
}
function RC47_makePunctuationTask(){
  return uniqueTask(()=>{
    const x=pick(RC47_SENTENCE_WRITING),plain=x.model.replace(/[.!?]$/,'');
    const q=Math.random()<.35,base=q?`ONDE ESTÁ ${x.keywords[0]}`:plain;
    const ans=q?base+'?':base+'.';
    return{world:'sentences',skill:'sentence:punctuation',key:`punct:${x.key}:${q?'q':'p'}`,sig:`rc47-punct:${x.key}:${q}`,command:q?'Escolha a frase que faz uma pergunta.':'Escolha a frase que conta algo e termina com ponto final.',audio:[],kind:'sentence',stimulus:{type:'scene',text:x.scene},options:shuffle([ans,base+'!',base]),answer:ans};
  });
}

// Educação Infantil: experiências de linguagem não são tratadas como prova de acerto/erro.
function RC47_makeEIExperience(worldId){
  const x=pick(RC47_EI_EXPERIENCES);
  return{world:worldId,skill:`ei:${x.code}`,key:`ei:${x.id}`,sig:`rc47-ei:${x.id}:${Date.now()}`,command:x.instruction,audio:x.audio||[],kind:'experience',experience:x,stimulus:{type:'scene',text:x.scene},options:[],answer:'EXPERIENCE'};
}
function RC47_recordEI(task,text=''){
  const code=task?.experience?.code||'EI03EF01',x=state.eiLedger[code]||{count:0,last:0,samples:[]};x.count++;x.last=Date.now();if(text)x.samples=[...(x.samples||[]),String(text).slice(0,80)].slice(-5);state.eiLedger[code]=x;safeSave();
}

// Traçado cursivo tátil: prática motora, sem falsa correção automática do desenho.
function RC47_makeTraceTask(){
  const L=pick('ABCDEFGHIJKLMNOPQRSTUVWXYZ'.split(''));
  return{world:'letters',skill:'letters:cursive-trace',key:`trace:${L}`,sig:`rc47-trace:${L}:${Date.now()}`,command:'Passe o dedo ou o mouse sobre a letra cursiva',audio:[AUDIO['letter:'+L]],kind:'trace',traceLetter:L.toLowerCase(),stimulus:null,options:[],answer:'TRACE'};
}

const RC47_PREV_MAKETASK=makeTask;
makeTask=function(i){
  if(i===0 && state.grade!=='Pré-escola'){
    const cursive=new Set((RC55_evidence(0)).filter(k=>String(k).includes(':cursive')).map(k=>String(k).split(':')[0]));
    if(cursive.size<26 && (worldStats(0).attempts>=10 || Math.random()<.34))return RC47_makeCursiveTask(pick('ABCDEFGHIJKLMNOPQRSTUVWXYZ'.split('').filter(x=>!cursive.has(x))));
    if(state.grade==='2º Ano' && Math.random()<.12)return RC47_makeTraceTask();
  }
  if(i===1 && state.grade!=='Pré-escola'){
    const finals=RC47_seen('final:',1).length;
    if(finals<4 || Math.random()<.22)return RC47_makeFinalSoundTask();
  }
  if(i===3){
    const modes=new Set((RC55_evidence(3)).map(k=>String(k).split(':')[0]));
    if(state.grade!=='Pré-escola'&&!modes.has('middle'))return RC47_makeMiddleSyllableTask();
    if(state.grade==='2º Ano'){
      const replacements=RC47_seen('replace:',3),patterns=RC47_seen('pattern:',3);
      if(replacements.length<3 || Math.random()<.18)return RC47_makeReplaceSyllableTask();
      if(patterns.length<3 || Math.random()<.18)return RC47_makePatternTask();
    }
  }
  if(i===4){
    if(state.grade==='Pré-escola'&&Math.random()<.26)return RC47_makeEIExperience('words');
    const writes=RC47_seen('write:',4).length;
    if(state.grade!=='Pré-escola'&&(writes<5||Math.random()<.28))return RC47_makeWordWritingTask();
  }
  if(i===5){
    if(state.grade==='Pré-escola'&&Math.random()<.28)return RC47_makeEIExperience('sentences');
    if(state.grade!=='Pré-escola'){
      const writes=RC47_seen('write-sentence:',5).length,punct=RC47_seen('punct:',5).length;
      if(writes<4||Math.random()<.22)return RC47_makeSentenceWritingTask();
      if(state.grade==='2º Ano'&&(punct<3||Math.random()<.18))return RC47_makePunctuationTask();
    }
  }
  if(i===6&&state.grade==='Pré-escola'&&Math.random()<.32)return RC47_makeEIExperience('comprehension');
  return RC47_PREV_MAKETASK(i);
};

// Fraquezas novas também entram no roteamento adaptativo.
const RC47_PREV_SKILLID=RC43_skillId;
RC43_skillId=function(task){
  if(task?.skill)return task.skill;
  return RC47_PREV_SKILLID(task);
};
const RC47_PREV_WEAKTASK=RC43_taskForWeakSkill;
RC43_taskForWeakSkill=function(i,id){
  if(i===0&&id?.includes(':cursive'))return RC47_makeCursiveTask(id.match(/letters:([A-Z])/)?.[1]);
  if(i===1&&id==='phonology:final')return RC47_makeFinalSoundTask();
  if(i===3&&id?.startsWith('syllable:middle'))return RC47_makeMiddleSyllableTask();
  if(i===3&&id?.startsWith('syllable:replace'))return RC47_makeReplaceSyllableTask();
  if(i===3&&id?.startsWith('syllable:pattern'))return RC47_makePatternTask();
  if(i===4&&id==='word:productive-writing')return RC47_makeWordWritingTask();
  if(i===5&&id==='sentence:productive-writing')return RC47_makeSentenceWritingTask();
  if(i===5&&id==='sentence:punctuation')return RC47_makePunctuationTask();
  return RC47_PREV_WEAKTASK(i,id);
};

// Cobertura por etapa: EI não é transformada em 1º ano antecipado.
const RC47_PREV_LETTER_COVERAGE=RC43_letterCoverage;
RC43_letterCoverage=function(){
  const u=RC55_evidence(0),letters=new Set(),pairs=new Set(),cursive=new Set();
  for(const k0 of u){const p=String(k0).split(':'),L=p[0];if(!/^[A-Z]$/.test(L))continue;letters.add(L);if(p[1]==='case'||p[1]==='cursive')pairs.add(L);if(p[1]==='cursive')cursive.add(L);}
  if(state.grade==='Pré-escola'){
    const targetLetters=12,targetPairs=6,ratio=Math.min(1,letters.size/targetLetters)*.65+Math.min(1,pairs.size/targetPairs)*.35;
    return{letters,pairs,cursive,ratio,pass:letters.size>=targetLetters&&pairs.size>=targetPairs,label:`${letters.size}/${targetLetters} letras exploradas · ${pairs.size}/${targetPairs} relações de formas (experiência EI)`};
  }
  const ratio=(letters.size/26)*.36+(pairs.size/26)*.29+(cursive.size/26)*.35;
  return{letters,pairs,cursive,ratio,pass:letters.size===26&&pairs.size===26&&cursive.size===26,label:`${letters.size}/26 letras · ${pairs.size}/26 maiúscula/minúscula · ${cursive.size}/26 imprensa/cursiva`};
};

const RC47_PREV_COVERAGE=RC43_coverage;
RC43_coverage=function(i){
  if(i===0)return RC43_letterCoverage();
  const u=RC55_evidence(i);
  if(i===1){
    const ini=u.filter(k=>String(k).startsWith('initial:')).length,rhy=u.filter(k=>String(k).startsWith('rhyme:')).length,fin=u.filter(k=>String(k).startsWith('final:')).length;
    if(state.grade==='Pré-escola')return{ratio:Math.min(1,ini/6)*.55+Math.min(1,rhy/4)*.45,pass:ini>=6&&rhy>=4,label:`${ini} aliterações/sons iniciais · ${rhy} rimas (EI03EF02)`};
    return{ratio:Math.min(1,ini/8)*.45+Math.min(1,rhy/4)*.25+Math.min(1,fin/4)*.30,pass:ini>=8&&rhy>=4&&fin>=4,label:`${ini} iniciais · ${fin} finais · ${rhy} rimas`};
  }
  if(i===3){
    const modes=new Set(u.map(k=>String(k).split(':')[0]));
    if(state.grade==='Pré-escola'){
      const need=['first','last','count','join'],got=need.filter(x=>modes.has(x)).length;return{ratio:got/need.length,pass:got===need.length,label:`${got}/4 experiências silábicas adequadas à EI`};
    }
    const base=['first','last','count','join','remove','middle'],got=base.filter(x=>modes.has(x)).length;
    if(state.grade==='1º Ano')return{ratio:got/base.length,pass:got===base.length,label:`${got}/6 operações silábicas`};
    const replacePos=new Set(u.filter(k=>String(k).startsWith('replace:')).map(k=>String(k).split(':')[1]));
    const patterns=new Set(u.filter(k=>String(k).startsWith('pattern:')).map(k=>String(k).split(':')[1]));
    const ratio=got/base.length*.55+Math.min(1,replacePos.size/3)*.25+Math.min(1,patterns.size/3)*.20;
    return{ratio,pass:got===base.length&&replacePos.size===3&&patterns.size===3,label:`${got}/6 operações · substituição ${replacePos.size}/3 posições · padrões V/CVC/CCV ${patterns.size}/3`};
  }
  if(i===4&&state.grade!=='Pré-escola'){
    const base=RC47_PREV_COVERAGE(i),writes=u.filter(k=>String(k).startsWith('write:')).length,target=state.grade==='2º Ano'?6:5;
    return{ratio:Math.min(1,(base.ratio*.68+Math.min(1,writes/target)*.32)),pass:base.pass&&writes>=target,label:`${base.label} · ${writes}/${target} escritas produtivas`};
  }
  if(i===5&&state.grade!=='Pré-escola'){
    const base=RC47_PREV_COVERAGE(i),writes=u.filter(k=>String(k).startsWith('write-sentence:')).length,punct=u.filter(k=>String(k).startsWith('punct:')).length;
    if(state.grade==='1º Ano')return{ratio:base.ratio*.65+Math.min(1,writes/4)*.35,pass:base.pass&&writes>=4,label:`${base.label} · ${writes}/4 frases produzidas`};
    return{ratio:base.ratio*.50+Math.min(1,writes/4)*.30+Math.min(1,punct/3)*.20,pass:base.pass&&writes>=4&&punct>=3,label:`${base.label} · ${writes}/4 frases produzidas · ${punct}/3 pontuações`};
  }
  return RC47_PREV_COVERAGE(i);
};

// Meta de evidências ajustada sem escolarizar antecipadamente a Pré-escola.
const RC47_PREV_MASTERYREQ=masteryReq;
masteryReq=function(i){
  const r=RC47_PREV_MASTERYREQ(i);
  if(state.grade==='Pré-escola')return{...r,attempts:Math.min(r.attempts,i===0?28:18),accuracy:Math.min(r.accuracy,75)};
  if(i===0)return{...r,attempts:Math.max(r.attempts,60)};
  if(i===4)return{...r,attempts:Math.max(r.attempts,state.grade==='2º Ano'?22:18)};
  if(i===5)return{...r,attempts:Math.max(r.attempts,state.grade==='2º Ano'?20:17)};
  return r;
};

function RC47_checkWriting(task,raw){
  const n=RC47_norm(raw);if(!n)return false;
  if(task.writeMode==='word')return n===RC47_norm(task.answer);
  if(task.writeMode==='sentence'){
    const okWords=(task.keywords||[]).every(k=>n.includes(RC47_norm(k)));
    const hasSpace=n.includes(' '),rawTrim=String(raw||'').trim();
    const punct=state.grade==='2º Ano'?/[.!?]$/.test(rawTrim):true;
    return okWords&&hasSpace&&punct;
  }
  return false;
}
function RC47_submitWriting(){
  if(attempt.done)return;const el=document.querySelector('#rc47WriteInput'),raw=el?.value||'';attempt.written=raw;
  const ok=RC47_checkWriting(current,raw);answer(ok?current.answer:'__RC47_WRONG__',false);
}
function RC47_completeExperience(){
  if(attempt.done)return;const el=document.querySelector('#rc47ExperienceInput');RC47_recordEI(current,el?.value||'');attempt.done=true;attempt.first=true;attempt.supportScore=0;attempt.praise='Experiência concluída!';render();
}
function RC47_setupTrace(){
  const canvas=document.querySelector('#rc47TraceCanvas');if(!canvas)return;const ctx=canvas.getContext('2d');let drawing=false,points=0,last=null;
  const resize=()=>{const r=canvas.getBoundingClientRect(),dpr=Math.max(1,window.devicePixelRatio||1);canvas.width=Math.round(r.width*dpr);canvas.height=Math.round(r.height*dpr);ctx.setTransform(dpr,0,0,dpr,0,0);ctx.lineWidth=9;ctx.lineCap='round';ctx.lineJoin='round';ctx.strokeStyle='#1976d2'};resize();
  const pos=e=>{const r=canvas.getBoundingClientRect(),p=e.touches?.[0]||e;return{x:p.clientX-r.left,y:p.clientY-r.top}};
  const start=e=>{e.preventDefault();drawing=true;last=pos(e)};const move=e=>{if(!drawing)return;e.preventDefault();const p=pos(e);ctx.beginPath();ctx.moveTo(last.x,last.y);ctx.lineTo(p.x,p.y);ctx.stroke();last=p;points++};const end=()=>{drawing=false;last=null};
  canvas.addEventListener('pointerdown',start);canvas.addEventListener('pointermove',move);canvas.addEventListener('pointerup',end);canvas.addEventListener('pointerleave',end);
  document.querySelector('#rc47TraceClear')?.addEventListener('click',()=>{ctx.clearRect(0,0,canvas.width,canvas.height);points=0});
  document.querySelector('#rc47TraceDone')?.addEventListener('click',()=>{if(points<8){const n=document.querySelector('#rc47TraceNote');if(n)n.textContent='Faça alguns traços sobre a letra antes de continuar.';return}attempt.done=true;attempt.first=true;attempt.supportScore=.75;recordTask(current,{score:.75,wrong:0,helpUsed:true});render()});
}

const RC47_PREV_ACTIVITY=activity;
activity=function(isDiag){
  RC47_PREV_ACTIVITY(isDiag);
  if(isDiag||!current)return;
  const card=document.querySelector('.card.lesson');if(!card)return;
  if(current.kind==='writing'){
    const ch=card.querySelector('.choices');if(!ch)return;
    ch.classList.remove('choices');
    if(!attempt.done){
      ch.innerHTML=`<div class="rc47-writing"><${current.writeMode==='sentence'?'textarea':'input'} id="rc47WriteInput" aria-label="${escapeHtml(current.command)}" maxlength="240" ${current.writeMode==='sentence'?'rows="3"':''} autocomplete="off" autocapitalize="characters" spellcheck="false" placeholder="${escapeHtml(current.placeholder||'Escreva aqui')}">${current.writeMode==='sentence'?'':''}</${current.writeMode==='sentence'?'textarea':'input'}><button class="primary" id="rc47WriteSubmit" type="button">Conferir minha escrita</button><div class="rc47-write-note">${state.grade==='2º Ano'&&current.writeMode==='sentence'?'Lembre-se de começar a frase adequadamente, separar as palavras e usar pontuação.':'Tente escrever sem copiar. A dica reduz o peso no domínio.'}</div></div>`;
      if(current.writeMode!=='sentence'){
        // Corrige a marcação inválida criada pelo template input com fechamento.
        const wrap=ch.querySelector('.rc47-writing');const bad=wrap?.querySelector('input');if(bad)bad.value=attempt.written||'';
      }else{const ta=ch.querySelector('textarea');if(ta)ta.value=attempt.written||'';}
      card.querySelector('#rc47WriteSubmit')?.addEventListener('click',RC47_submitWriting);
      card.querySelector('#rc47WriteInput')?.addEventListener('keydown',e=>{if(e.key==='Enter'&&current.writeMode!=='sentence'){e.preventDefault();RC47_submitWriting();}});
    }else{
      ch.innerHTML=`<div class="rc47-model"><b>Uma escrita possível:</b> ${escapeHtml(current.answer)}</div>`;
    }
  }
  if(current.kind==='experience'){
    const ch=card.querySelector('.choices');if(!ch)return;ch.classList.remove('choices');
    if(!attempt.done){
      const wantsText=current.experience?.id==='escrita-espontanea';
      ch.innerHTML=`<div class="rc47-experience"><span class="rc47-ei-badge">${escapeHtml(current.experience?.code||'Educação Infantil')} · experiência, não prova</span><b>${escapeHtml(current.experience?.label||'Experiência de linguagem')}</b><p>${escapeHtml(current.command)}</p>${wantsText?'<input id="rc47ExperienceInput" aria-label="Sua escrita espontânea" class="profile-input" maxlength="40" placeholder="Escreva do seu jeito">':''}<button class="primary-xl" id="rc47ExperienceDone" type="button">Concluí esta experiência</button></div>`;
      card.querySelector('#rc47ExperienceDone')?.addEventListener('click',RC47_completeExperience);
    }else ch.innerHTML='<div class="feedback">Muito bem! Aqui não existe “certo ou errado”: valeu participar, falar, imaginar ou registrar.</div>';
    card.querySelector('.rc43-help-btn')?.classList.add('hidden');
  }
  if(current.kind==='trace'){
    const ch=card.querySelector('.choices');if(!ch)return;ch.classList.remove('choices');
    if(!attempt.done){
      ch.innerHTML=`<div class="rc47-trace-wrap"><div class="rc47-trace-guide rc47-cursive">${escapeHtml(current.traceLetter)}</div><canvas id="rc47TraceCanvas" aria-label="Área para traçar a letra cursiva"></canvas></div><div class="rc47-trace-actions"><button class="soft" id="rc47TraceClear" type="button">Limpar</button><button class="primary" id="rc47TraceDone" type="button">Terminei o traçado</button></div><div class="rc47-write-note" id="rc47TraceNote">Esta atividade pratica o gesto gráfico. O aplicativo não finge corrigir caligrafia automaticamente.</div>`;RC47_setupTrace();
    }else ch.innerHTML='<div class="feedback">Traçado praticado. Continue observando a forma cursiva e a forma de imprensa.</div>';
    card.querySelector('.rc43-help-btn')?.classList.add('hidden');
  }
};

// Dicas específicas.
const RC47_PREV_HINT=hintForTask;
hintForTask=function(t){
  if(t?.kind==='writing')return t.writeHint||'Observe a figura e pense nos sons da palavra.';
  if(t?.skill?.startsWith('syllable:pattern'))return t.hint||'Observe quantas consoantes e vogais aparecem na sílaba.';
  if(t?.skill?.startsWith('phonology:final'))return 'Fale baixinho o nome das figuras e compare como cada palavra termina.';
  if(t?.skill?.includes('cursive'))return 'Compare o desenho da letra cursiva com as letras de imprensa.';
  return RC47_PREV_HINT(t);
};

// Painel familiar: evidencia a etapa e não mistura EI com habilidades EF.
const RC47_PREV_ADULT=adult;
adult=function(){
  RC47_PREV_ADULT();
  const card=document.querySelector('.card.adult');if(!card||card.querySelector('.rc47-bncc-trace'))return;
  const codes=RC47_BNCC[state.grade]||[];const isEI=state.grade==='Pré-escola';
  const html=`<div class="rc47-bncc-trace"><h2>Rastreabilidade BNCC — ${escapeHtml(state.grade||'1º Ano')}</h2><p>${isEI?'Na Educação Infantil, o aplicativo trata oralidade, brincadeiras sonoras, reconto e escrita espontânea como experiências de aprendizagem, sem transformar a etapa em antecipação formal do 1º ano.':'Nesta etapa, os critérios de domínio incluem leitura, relações som–grafema, manipulação silábica e produção escrita; no 2º ano, entram também padrões V/CVC/CCV, segmentação e pontuação.'}</p><div class="rc47-bncc-codes">${codes.map(c=>`<span>${c}</span>`).join('')}</div>${isEI?`<p style="margin-top:10px">Experiências registradas: ${Object.values(state.eiLedger||{}).reduce((a,x)=>a+Number(x.count||0),0)}.</p>`:''}</div>`;
  const grid=card.querySelector('.adult-grid');grid?.insertAdjacentHTML('beforebegin',html);
};

// Microaulas refletem a ampliação curricular.
const RC47_PREV_MICRO=micro;
micro=function(){
  RC47_PREV_MICRO();
  const card=document.querySelector('.card.micro');if(!card)return;
  if(pendingWorld===0&&state.grade!=='Pré-escola'&&!card.querySelector('.rc47-construct-note'))card.querySelector('.examples')?.insertAdjacentHTML('afterend','<div class="rc47-construct-note">Além de maiúsculas e minúsculas, a trilha passa a relacionar formas de imprensa e cursiva e inclui prática tátil de traçado.</div>');
  if(pendingWorld===3&&state.grade==='2º Ano'&&!card.querySelector('.rc47-construct-note'))card.querySelector('.examples')?.insertAdjacentHTML('afterend','<div class="rc47-construct-note">No 2º ano entram substituição de sílabas em diferentes posições e leitura de estruturas V, CVC e CCV.</div>');
  if(state.grade==='Pré-escola'&&!card.querySelector('.rc47-ei-badge'))card.querySelector('.kicker')?.insertAdjacentHTML('beforebegin','<span class="rc47-ei-badge">Educação Infantil · experiência lúdica</span>');
};

// Auditoria interna legível por testes automatizados.
window.RC47_AUDIT={
  version:RC47_VERSION,
  complexWords:RC47_COMPLEX_WORDS.length,
  sentenceWriting:RC47_SENTENCE_WRITING.length,
  eiObjectives:RC47_BNCC['Pré-escola'],
  features:{cursive:true,cursiveTrace:true,productiveWordWriting:true,productiveSentenceWriting:true,finalSound:true,medialSyllable:true,syllableReplacement:true,patterns:['V','CVC','CCV'],punctuation:true,eiLayer:true},
  coverage:()=>worlds.map((w,i)=>({world:w.id,...RC43_coverage(i)}))
};

document.title='Intelectus Alfabetização — RC Pedagógica 10 V47';
render();



/* ===== rc48-pedagogical-10-hotfix ===== */

/* Intelectus Alfabetização — RC Pedagógica 10 V48
   Balanceamento adaptativo, ampliação grafema/ortografia e domínio por competência crítica. */
const RC48_VERSION=48;
state.rcPedagogicalVersion=RC48_VERSION;
state.eiWorldLedger=state.eiWorldLedger&&typeof state.eiWorldLedger==='object'?state.eiWorldLedger:{};
safeSave();

RC47_EI_EXPERIENCES.push({id:'expressao-vivencia',code:'EI03EF01',label:'Expressão oral',instruction:'Conte como você se sentiria ou o que faria nesta situação.',scene:'🌧️🏠'});

const RC48_ORTHO_TASKS=[
 {id:'j-janela',category:'extended',word:'_ANELA',answer:'J',opts:['J','G','X'],label:'JANELA'},
 {id:'r-rato',category:'extended',word:'_ATO',answer:'R',opts:['R','L','N'],label:'RATO',clue:'É um pequeno roedor de cauda comprida.'},
 {id:'z-zebra',category:'extended',word:'_EBRA',answer:'Z',opts:['Z','S','X'],label:'ZEBRA'},
 {id:'x-xale',category:'extended',word:'_ALE',answer:'X',opts:['X','CH','S'],label:'XALE'},
 {id:'q-queijo',category:'contextual',word:'_UEIJO',answer:'Q',opts:['Q','C','K'],label:'QUEIJO'},
 {id:'c-cebola',category:'contextual',word:'_EBOLA',answer:'C',opts:['C','S','Q'],label:'CEBOLA'},
 {id:'g-girafa',category:'contextual',word:'_IRAFA',answer:'G',opts:['G','J','C'],label:'GIRAFA'},
 {id:'qu-quilo',category:'contextual',word:'_UILO',answer:'Q',opts:['Q','C','K'],label:'QUILO'},
 {id:'nasal-pao',category:'nasal',word:'P_O',answer:'Ã',opts:['Ã','A','Õ'],label:'PÃO'},
 {id:'nasal-campo',category:'nasal',word:'CA_PO',answer:'M',opts:['M','N','~'],label:'CAMPO'},
 {id:'nasal-vento',category:'nasal',word:'VE_TO',answer:'N',opts:['N','M','~'],label:'VENTO'},
 {id:'nasal-irma',category:'nasal',word:'IRM_',answer:'Ã',opts:['Ã','A','AN'],label:'IRMÃ'}
];
function RC48_makeOrthoTask(forceCategory){
 return uniqueTask(()=>{
   let pool=RC48_ORTHO_TASKS;if(forceCategory)pool=pool.filter(x=>x.category===forceCategory);
   const x=pick(pool.length?pool:RC48_ORTHO_TASKS);
   return{world:'graphemes',skill:`grapheme:${x.category}`,key:`ortho:${x.category}:${x.id}`,sig:`rc48-ortho:${x.id}`,command:'Complete a palavra com a opção adequada'+(x.clue?'. '+x.clue:'.'),audio:[],kind:'word',stimulus:{type:'word',text:x.word},options:shuffle(x.opts),answer:x.answer,hint:`A palavra é ${x.label}.`};
 });
}
function RC48_skillRate(id){const x=state.skillLedger?.[id];return x&&x.attempts?x.points/x.attempts:0;}
function RC48_skillAttempts(id){return Number(state.skillLedger?.[id]?.attempts||0);}
function RC48_eiCount(worldId){return Number(state.eiWorldLedger?.[worldId]||0);}

// Registra experiências EI por mundo, sem convertê-las em acerto/erro formal.
RC47_recordEI=function(task,text=''){
 const code=task?.experience?.code||'EI03EF01',x=state.eiLedger[code]||{count:0,last:0,samples:[]};x.count++;x.last=Date.now();if(text)x.samples=[...(x.samples||[]),String(text).slice(0,80)].slice(-5);state.eiLedger[code]=x;
 const wid=String(task?.world||'geral');state.eiWorldLedger[wid]=RC48_eiCount(wid)+1;safeSave();
};

// Corrige áudio da escrita: pronúncia da palavra é apoio fonológico, sem comando incompatível.
const RC48_PREV_WORDWRITE=RC47_makeWordWritingTask;
RC47_makeWordWritingTask=function(){const t=RC48_PREV_WORDWRITE();if(t.audio?.length)t.audio=t.audio.filter(src=>src&&src!==AUDIO['prompt:look_choose_word']);return t;};

// Roteamento balanceado: nenhuma nova habilidade monopoliza a sessão.
makeTask=function(i){
  if(i===0&&state.grade!=='Pré-escola'){
    const cursive=new Set((RC55_evidence(0)).filter(k=>String(k).includes(':cursive')).map(k=>String(k).split(':')[0]));
    const missing='ABCDEFGHIJKLMNOPQRSTUVWXYZ'.split('').filter(x=>!cursive.has(x));
    if(missing.length&&Math.random()<.42)return RC47_makeCursiveTask(pick(missing));
    if(state.grade==='2º Ano'&&Math.random()<.10)return RC47_makeTraceTask();
  }
  if(i===1&&state.grade!=='Pré-escola'){
    const finals=RC47_seen('final:',1).length;
    if(Math.random()<(finals<4?.48:.18))return RC47_makeFinalSoundTask();
  }
  if(i===2){
    if(state.grade==='Pré-escola')return RC47_PREV_MAKETASK(i);
    const ortho=RC47_seen('ortho:',2).length,nasal=RC47_seen('ortho:nasal:',2).length;
    let chance=state.grade==='2º Ano'?(ortho<8?.38:.24):(ortho<4?.28:.16);
    if(Math.random()<chance)return RC48_makeOrthoTask(state.grade==='2º Ano'&&nasal<3&&Math.random()<.55?'nasal':null);
  }
  if(i===3){
    const modes=new Set((RC55_evidence(3)).map(k=>String(k).split(':')[0]));
    if(state.grade!=='Pré-escola'&&!modes.has('middle')&&Math.random()<.45)return RC47_makeMiddleSyllableTask();
    if(state.grade==='2º Ano'){
      const replacements=RC47_seen('replace:',3).length,patterns=RC47_seen('pattern:',3).length;
      if(Math.random()<(replacements<5?.28:.14))return RC47_makeReplaceSyllableTask();
      if(Math.random()<(patterns<5?.26:.13))return RC47_makePatternTask();
    }
  }
  if(i===4){
    if(state.grade==='Pré-escola'&&Math.random()<.60)return RC47_makeEIExperience('words');
    if(state.grade!=='Pré-escola'){
      const writes=RC47_seen('write:',4).length,target=state.grade==='2º Ano'?6:5;
      if(Math.random()<(writes<target?.44:.22))return RC47_makeWordWritingTask();
    }
  }
  if(i===5){
    if(state.grade==='Pré-escola'&&Math.random()<.62)return RC47_makeEIExperience('sentences');
    if(state.grade!=='Pré-escola'){
      const writes=RC47_seen('write-sentence:',5).length,punct=RC47_seen('punct:',5).length;
      if(Math.random()<(writes<4?.40:.18))return RC47_makeSentenceWritingTask();
      if(state.grade==='2º Ano'&&Math.random()<(punct<3?.30:.14))return RC47_makePunctuationTask();
    }
  }
  if(i===6&&state.grade==='Pré-escola'&&Math.random()<.58)return RC47_makeEIExperience('comprehension');
  return RC47_PREV_MAKETASK(i);
};

const RC48_PREV_COVERAGE=RC43_coverage;
RC43_coverage=function(i){
  const u=RC55_evidence(i);
  if(i===0&&state.grade!=='Pré-escola'){
    const base=RC43_letterCoverage();
    // Conta cursiva apenas quando houve resposta com algum desempenho positivo.
    const good='ABCDEFGHIJKLMNOPQRSTUVWXYZ'.split('').filter(L=>RC48_skillRate(`letters:${L}:cursive`)>0).length;
    return{...base,ratio:Math.min(base.ratio,.72+good/26*.28),pass:base.pass&&good===26,label:`${base.label} · ${good}/26 cursivas reconhecidas com sucesso`};
  }
  if(i===1&&state.grade!=='Pré-escola'){
    const base=RC48_PREV_COVERAGE(i),rate=RC48_skillRate('phonology:final');
    return{...base,ratio:base.ratio*.84+Math.min(1,rate/.72)*.16,pass:base.pass&&RC48_skillAttempts('phonology:final')>=4&&rate>=.65,label:`${base.label} · desempenho final ${Math.round(rate*100)}%`};
  }
  if(i===2){
    const audioLetters=new Set(u.filter(k=>!/^(ortho:)/.test(String(k))).map(k=>String(k).split(':')[0]).filter(x=>/^[A-Z]$/.test(x)));
    if(state.grade==='Pré-escola')return{ratio:Math.min(1,audioLetters.size/6),pass:audioLetters.size>=6,label:`${audioLetters.size}/6 relações som–letra exploradas (EI, sem antecipação formal)`};
    const ext=u.filter(k=>String(k).startsWith('ortho:extended:')||String(k).startsWith('ortho:contextual:')).length;
    const nasal=u.filter(k=>String(k).startsWith('ortho:nasal:')).length;
    const audioPass=audioLetters.size>=12;
    if(state.grade==='1º Ano')return{ratio:Math.min(1,audioLetters.size/12)*.72+Math.min(1,ext/4)*.28,pass:audioPass&&ext>=4,label:`${audioLetters.size}/12 relações auditivas · ${ext}/4 ampliações grafêmicas`};
    return{ratio:Math.min(1,audioLetters.size/12)*.55+Math.min(1,ext/6)*.25+Math.min(1,nasal/3)*.20,pass:audioPass&&ext>=6&&nasal>=3,label:`${audioLetters.size}/12 auditivas · ${ext}/6 regulares/contextuais · ${nasal}/3 nasalidade`};
  }
  if(i===3&&state.grade!=='Pré-escola'){
    const base=RC48_PREV_COVERAGE(i);
    if(state.grade==='2º Ano'){
      const replAtt=Object.entries(state.skillLedger||{}).filter(([k])=>k.startsWith('syllable:replace:')).reduce((a,[,v])=>a+v.attempts,0),replPts=Object.entries(state.skillLedger||{}).filter(([k])=>k.startsWith('syllable:replace:')).reduce((a,[,v])=>a+v.points,0);
      const patAtt=Object.entries(state.skillLedger||{}).filter(([k])=>k.startsWith('syllable:pattern:')).reduce((a,[,v])=>a+v.attempts,0),patPts=Object.entries(state.skillLedger||{}).filter(([k])=>k.startsWith('syllable:pattern:')).reduce((a,[,v])=>a+v.points,0);
      const rr=replAtt?replPts/replAtt:0,pr=patAtt?patPts/patAtt:0;
      return{...base,pass:base.pass&&replAtt>=3&&patAtt>=3&&rr>=.65&&pr>=.65,label:`${base.label} · sucesso substituição ${Math.round(rr*100)}% · padrões ${Math.round(pr*100)}%`};
    }
    return base;
  }
  if(i===4&&state.grade!=='Pré-escola'){
    const base=RC48_PREV_COVERAGE(i),rate=RC48_skillRate('word:productive-writing'),att=RC48_skillAttempts('word:productive-writing');
    return{...base,ratio:base.ratio*.85+Math.min(1,rate/.75)*.15,pass:base.pass&&att>=4&&rate>=.65,label:`${base.label} · escrita autônoma/assistida ${Math.round(rate*100)}%`};
  }
  if(i===5&&state.grade!=='Pré-escola'){
    const base=RC48_PREV_COVERAGE(i),rate=RC48_skillRate('sentence:productive-writing'),att=RC48_skillAttempts('sentence:productive-writing');
    return{...base,ratio:base.ratio*.86+Math.min(1,rate/.72)*.14,pass:base.pass&&att>=3&&rate>=.60,label:`${base.label} · produção de frases ${Math.round(rate*100)}%`};
  }
  if(state.grade==='Pré-escola'&&[4,5,6].includes(i)){
    const wid=worlds[i].id,count=RC48_eiCount(wid),target=4;
    return{ratio:Math.min(1,count/target),pass:count>=target,label:`${count}/${target} experiências de oralidade/leitura/escrita espontânea`};
  }
  return RC48_PREV_COVERAGE(i);
};

// Na EI, “concluir um mundo” significa vivenciar experiências suficientes, não provar domínio formal.
const RC48_PREV_MASTERED=mastered;
mastered=function(i){
 if(state.grade==='Pré-escola'&&[4,5,6].includes(i))return RC43_coverage(i).pass;
 return RC48_PREV_MASTERED(i);
};
const RC48_PREV_PROGRESS=progressPct;
progressPct=function(i){if(state.grade==='Pré-escola'&&[4,5,6].includes(i))return Math.min(100,Math.round(RC43_coverage(i).ratio*100));return RC48_PREV_PROGRESS(i);};

// Painel deixa explícita a semântica de progresso na EI.
const RC48_PREV_ADULT=adult;
adult=function(){
 RC48_PREV_ADULT();const card=document.querySelector('.card.adult');if(!card)return;
 if(state.grade==='Pré-escola')card.querySelectorAll('.rc43-mastery-line b').forEach(b=>{b.textContent=b.textContent.replace('Domínio efetivo','Progresso de experiências')});
 const note=card.querySelector('.rc44-version-note');if(note)note.textContent='RC Pedagógica 10 V48 · cobertura por etapa, produção escrita e experiências EI ativas';
};

window.RC48_AUDIT={version:RC48_VERSION,orthographicTasks:RC48_ORTHO_TASKS.length,eiExperienceTypes:RC47_EI_EXPERIENCES.length,balancedRouting:true,criticalSkillFloors:true};
document.title='Intelectus Alfabetização — RC Pedagógica 10 V48';
render();



/* ===== rc49-pedagogical-10-final ===== */

/* Intelectus Alfabetização — RC Pedagógica 10 V49
   Correções finais de validade: evidência separada para caixa e cursiva; EI sem gate de composição silábica formal. */
const RC49_VERSION=49;
state.rcPedagogicalVersion=RC49_VERSION;
safeSave();

RC43_letterCoverage=function(){
  const u=RC55_evidence(0),letters=new Set(),pairs=new Set(),cursive=new Set(),forms={};
  for(const k0 of u){
    const p=String(k0).split(':'),L=p[0];if(!/^[A-Z]$/.test(L))continue;
    letters.add(L);forms[L]=forms[L]||new Set();
    if(p[1]==='case')pairs.add(L);
    if(p[1]==='lower'||(p[1]==='mixed'&&p[2]==='true'))forms[L].add('lower');
    if(p[1]==='upper'||(p[1]==='mixed'&&p[2]==='false'))forms[L].add('upper');
    if(forms[L].has('lower')&&forms[L].has('upper'))pairs.add(L);
    if(p[1]==='cursive')cursive.add(L);
  }
  if(state.grade==='Pré-escola'){
    const targetLetters=12,targetPairs=6,ratio=Math.min(1,letters.size/targetLetters)*.68+Math.min(1,pairs.size/targetPairs)*.32;
    return{letters,pairs,cursive,ratio,pass:letters.size>=targetLetters&&pairs.size>=targetPairs,label:`${letters.size}/${targetLetters} letras exploradas · ${pairs.size}/${targetPairs} relações maiúscula/minúscula (experiência EI)`};
  }
  const ratio=(letters.size/26)*.34+(pairs.size/26)*.31+(cursive.size/26)*.35;
  return{letters,pairs,cursive,ratio,pass:letters.size===26&&pairs.size===26&&cursive.size===26,label:`${letters.size}/26 letras · ${pairs.size}/26 maiúscula/minúscula · ${cursive.size}/26 imprensa/cursiva`};
};

const RC49_PREV_COVERAGE=RC43_coverage;
RC43_coverage=function(i){
  if(i===0){
    const base=RC43_letterCoverage();
    if(state.grade==='Pré-escola')return base;
    const good='ABCDEFGHIJKLMNOPQRSTUVWXYZ'.split('').filter(L=>RC48_skillRate(`letters:${L}:cursive`)>0).length;
    return{...base,ratio:Math.min(base.ratio,.72+good/26*.28),pass:base.pass&&good===26,label:`${base.label} · ${good}/26 cursivas reconhecidas com sucesso`};
  }
  if(i===3&&state.grade==='Pré-escola'){
    const modes=new Set((RC55_evidence(3)).map(k=>String(k).split(':')[0])),need=['first','last','count'],got=need.filter(x=>modes.has(x)).length;
    return{ratio:got/need.length,pass:got===need.length,label:`${got}/3 experiências de percepção silábica (sem exigir composição formal na EI)`};
  }
  return RC49_PREV_COVERAGE(i);
};

window.RC49_AUDIT={version:RC49_VERSION,caseEvidenceSeparatedFromCursive:true,preschoolSyllableGate:['first','last','count']};
document.title='Intelectus Alfabetização — RC Pedagógica 10 V49';
render();



/* ===== rc50-ei-developmentally-aligned ===== */

/* Intelectus Alfabetização — RC Pedagógica 10 V50
   Refinamento final da Educação Infantil: oralidade, sequenciação e inferência visual; sem leitura formal obrigatória. */
const RC50_VERSION=50;
state.rcPedagogicalVersion=RC50_VERSION;
safeSave();

const RC50_EI_VISUAL_SEQUENCES=[
 {id:'ovo-pintinho',scene:'🥚  ➜  🐣  ➜  ?',answer:'GALINHA',opts:[{value:'GALINHA',pic:'🐔'},{value:'PEIXE',pic:'🐟'},{value:'CARRO',pic:'🚗'}]},
 {id:'semente-flor',scene:'🌱  ➜  🌿  ➜  ?',answer:'FLOR',opts:[{value:'FLOR',pic:'🌻'},{value:'LUA',pic:'🌙'},{value:'BOLA',pic:'⚽'}]},
 {id:'dia-noite',scene:'☀️  ➜  🌇  ➜  ?',answer:'NOITE',opts:[{value:'NOITE',pic:'🌙'},{value:'CHUVA',pic:'🌧️'},{value:'BOLO',pic:'🎂'}]},
 {id:'chuva-guarda',scene:'☁️  ➜  🌧️  ➜  ?',answer:'GUARDA-CHUVA',opts:[{value:'GUARDA-CHUVA',pic:'☂️'},{value:'OCULOS',pic:'🕶️'},{value:'BOLA',pic:'⚽'}]},
 {id:'lavar-maos',scene:'👐  ➜  🧼  ➜  ?',answer:'MAOS-LIMPAS',opts:[{value:'MAOS-LIMPAS',pic:'✨'},{value:'SAPATO',pic:'👟'},{value:'LIVRO',pic:'📘'}]},
 {id:'sono',scene:'🥱  ➜  🛏️  ➜  ?',answer:'DORMIR',opts:[{value:'DORMIR',pic:'😴'},{value:'CORRER',pic:'🏃'},{value:'NADAR',pic:'🏊'}]}
];
const RC50_EI_VISUAL_INFERENCES=[
 {id:'chove',scene:'🌧️👧',answer:'GUARDA-CHUVA',opts:[{value:'GUARDA-CHUVA',pic:'☂️'},{value:'SORVETE',pic:'🍦'},{value:'BOLA',pic:'⚽'}]},
 {id:'sede',scene:'☀️🥵',answer:'AGUA',opts:[{value:'AGUA',pic:'💧'},{value:'LUA',pic:'🌙'},{value:'PIPA',pic:'🪁'}]},
 {id:'frio',scene:'❄️🥶',answer:'CASACO',opts:[{value:'CASACO',pic:'🧥'},{value:'OCULOS',pic:'🕶️'},{value:'BOLA',pic:'⚽'}]},
 {id:'planta',scene:'🌱☀️',answer:'AGUA',opts:[{value:'AGUA',pic:'💧'},{value:'SAPATO',pic:'👟'},{value:'DADO',pic:'🎲'}]},
 {id:'sono',scene:'🌙🥱',answer:'CAMA',opts:[{value:'CAMA',pic:'🛏️'},{value:'MOTO',pic:'🏍️'},{value:'PATO',pic:'🦆'}]},
 {id:'fome',scene:'😋🍽️',answer:'COMIDA',opts:[{value:'COMIDA',pic:'🍌'},{value:'NUVEM',pic:'☁️'},{value:'VELA',pic:'🕯️'}]}
];
function RC50_makeEISequence(){
 const x=pick(RC50_EI_VISUAL_SEQUENCES);
 return uniqueTask(()=>({world:'sentences',skill:'ei:visual-sequence',key:`ei-seq:${x.id}`,sig:`rc50-ei-seq:${x.id}:${Date.now()}`,command:'👀 ➜ 👆 Observe as imagens. O que vem depois?',audio:[],kind:'picture',stimulus:{type:'scene',text:x.scene},options:shuffle(x.opts),answer:x.answer,hint:'Olhe a ordem das imagens e pense no que acontece depois.'}));
}
function RC50_makeEIInference(){
 const x=pick(RC50_EI_VISUAL_INFERENCES);
 return uniqueTask(()=>({world:'comprehension',skill:'ei:visual-inference',key:`ei-infer:${x.id}`,sig:`rc50-ei-infer:${x.id}:${Date.now()}`,command:'👀 ➜ 👆 Olhe a cena e escolha a imagem que faz mais sentido.',audio:[],kind:'picture',stimulus:{type:'scene',text:x.scene},options:shuffle(x.opts),answer:x.answer,hint:'Use as pistas da cena.'}));
}

// Na Pré-escola, mundos de frase/compreensão ficam inteiramente em experiências e linguagem visual.
const RC50_PREV_MAKETASK=makeTask;
makeTask=function(i){
 if(state.grade==='Pré-escola'&&i===5){
   if(Math.random()<.58)return RC47_makeEIExperience('sentences');
   return RC50_makeEISequence();
 }
 if(state.grade==='Pré-escola'&&i===6){
   if(Math.random()<.58)return RC47_makeEIExperience('comprehension');
   return RC50_makeEIInference();
 }
 return RC50_PREV_MAKETASK(i);
};

// Evidência visual também conta como vivência de linguagem, sem transformar a EI em prova formal.
const RC50_PREV_ANSWER=answer;
answer=function(v,isDiag){
 const wasDone=attempt.done,t=current;
 RC50_PREV_ANSWER(v,isDiag);
 if(!wasDone&&attempt.done&&state.grade==='Pré-escola'&&t&&String(t.key||'').startsWith('ei-seq:')){
   state.eiWorldLedger.sentences=RC48_eiCount('sentences')+1;
   const x=state.eiLedger.visualSequence||{count:0,last:0,samples:[]};x.count++;x.last=Date.now();state.eiLedger.visualSequence=x;safeSave();
 }
 if(!wasDone&&attempt.done&&state.grade==='Pré-escola'&&t&&String(t.key||'').startsWith('ei-infer:')){
   state.eiWorldLedger.comprehension=RC48_eiCount('comprehension')+1;
   const x=state.eiLedger.visualInference||{count:0,last:0,samples:[]};x.count++;x.last=Date.now();state.eiLedger.visualInference=x;safeSave();
 }
};

const RC50_PREV_ADULT=adult;
adult=function(){
 RC50_PREV_ADULT();
 const note=document.querySelector('.rc44-version-note');
 if(note)note.textContent='RC Pedagógica 10 V50 · EI com oralidade, sequenciação e inferência visual; alfabetização formal no 1º/2º ano';
};
window.RC50_AUDIT={version:RC50_VERSION,preschoolFormalSentenceReadingRequired:false,preschoolFormalTextReadingRequired:false,visualSequences:RC50_EI_VISUAL_SEQUENCES.length,visualInferences:RC50_EI_VISUAL_INFERENCES.length};
document.title='Intelectus Alfabetização — RC Pedagógica 10 V50';
render();


/* ===== rc51-audio-accessibility-final ===== */

/* Intelectus Alfabetização — RC Pedagógica 10 V52
   Acessibilidade: não exibir controle de áudio sem faixa associada. */
const RC51_VERSION=52;
state.rcPedagogicalVersion=RC51_VERSION;
safeSave();
const RC51_PREV_ACTIVITY=activity;
activity=function(isDiag){
  RC51_PREV_ACTIVITY(isDiag);
  const hasAudio=Array.isArray(current?.audio)&&current.audio.some(Boolean);
  const b=document.querySelector('#audio');
  if(b&&!hasAudio){b.hidden=true;b.style.display='none';b.setAttribute('aria-hidden','true');b.tabIndex=-1;}
};
window.RC51_AUDIT={version:RC51_VERSION,silentAudioButton:false,hideAudioWhenNoTrack:true};
document.title='Intelectus Alfabetização — RC Pedagógica 10 V52';
render();


/* ===== v53-focus-footer-hardening ===== */

const RC53_VERSION=53;
state.rcPedagogicalVersion=RC53_VERSION;
safeSave();
const RC53_PREV_ACTIVITY=activity;
activity=function(isDiag){
  RC53_PREV_ACTIVITY(isDiag);
  if(!isDiag){
    ['musicFab','volumeFab','volumePanel'].forEach(id=>{const el=document.getElementById(id);if(el)el.classList.add('hidden')});
  }
};
window.RC53_AUDIT={version:RC53_VERSION,baseline:'V52 pedagogy preserved',activityGlobalFabsHidden:true,mobileBnccSafePadding:true};
document.title='Intelectus Alfabetização';


/* ===== audit-v54-hardening ===== */

/* Fine-audit candidate based on the exact frozen V54. Local review, not production certification. */
if(!state.rc55EvidenceVersion){
 const earned=worlds.map((w,i)=>i).filter(i=>unlocked(i));
 state.bypass=[...new Set([...(state.bypass||[]),...earned])];
 state.rc55EvidenceVersion=1;
 safeSave();
}
const RC55_PREV_PROGRESS=progressPct;
progressPct=function(i){return mastered(i)?100:Math.min(99,RC55_PREV_PROGRESS(i));};
nextWorldIndex=function(){
 const entry=clamp(Math.floor(Number(state.entryIndex)||0),0,worlds.length-1);
 for(let i=entry;i<worlds.length;i++)if(unlocked(i)&&!mastered(i))return i;
 for(let i=0;i<entry;i++)if(unlocked(i)&&!mastered(i))return i;
 return worlds.length-1;
};
// The short discovery screen renders choice buttons only. Never send it an open activity.
function RC55_makeAssessmentTask(i){
 for(let n=0;n<32;n++){
  const t=makeTask(i);
  if(!['writing','trace','experience'].includes(t.kind)&&t.options?.length===3)return t;
 }
 if(state.grade==='Pré-escola'&&i===5)return RC50_makeEISequence();
 if(state.grade==='Pré-escola'&&i===6)return RC50_makeEIInference();
 return RC43_ORIGINALS.makeTask(i);
}
makeDiagnostic=RC55_makeAssessmentTask;
function RC55_scheduleTaskAudio(delay){
 const task=current,screen=view;
 setTimeout(()=>{if(current===task&&view===screen)playSeq(task.audio)},delay);
}
let voiceSequence=0,voiceCancel=null,rc55LastView=view;
function stopVoice(){voiceSequence++;if(voiceCancel)voiceCancel();voiceCancel=null;if(voiceAudio){voiceAudio.pause();voiceAudio=null}duck(false)}
playOne=function(src,sequence=voiceSequence){
 if(!src||sequence!==voiceSequence||voiceLevel===0)return Promise.resolve(false);
 if(voiceCancel)voiceCancel();
 return new Promise(resolve=>{
  const audio=new Audio(src);voiceAudio=audio;audio.volume=voiceLevel/100;
  const profile=RC43_VOICE_PROFILES[state.voiceProfile]||RC43_VOICE_PROFILES.natural;
  audio.playbackRate=profile.rate;
  try{audio.preservesPitch=false;audio.webkitPreservesPitch=false}catch(e){}
  let timer=null,settled=false;const task=current;
  const finish=(ok,failed=false)=>{if(settled)return;settled=true;if(timer!==null)clearTimeout(timer);audio.onended=null;audio.onerror=null;audio.pause();if(voiceAudio===audio)voiceAudio=null;if(voiceCancel===cancel)voiceCancel=null;if(sequence===voiceSequence)duck(false);if(failed&&sequence===voiceSequence&&task===current&&task?.kind==='writing'&&task.writeMode==='word'&&task.audio?.includes(src)&&typeof RC56_markAudioUnavailable==='function')RC56_markAudioUnavailable(task);resolve(ok)};
  const cancel=()=>finish(false);voiceCancel=cancel;
  audio.onended=()=>finish(true);audio.onerror=()=>finish(false,true);duck(true);
  timer=setTimeout(()=>finish(false,true),15000);
  try{Promise.resolve(audio.play()).catch(()=>finish(false,true))}catch(e){finish(false,true)}
 });
};
playSeq=async function(arr){
 stopVoice();if(voiceLevel===0)return;const sequence=voiceSequence;
 for(const src of arr||[]){if(sequence!==voiceSequence)return;if(src&&!await playOne(src,sequence))return}
};
const RC55_PREV_RENDER=render;
render=function(){if(rc55LastView!==view){stopVoice();rc55LastView=view}return RC55_PREV_RENDER();};
// Word spelling distinguishes VOVÓ from VOVO; sentence production is open and needs meaningful review.
function RC55_normalizeWriting(raw){return String(raw??'').normalize('NFC').toLocaleUpperCase('pt-BR').trim().replace(/\s+/g,' ')}
RC47_checkWriting=function(task,raw){
 const n=RC55_normalizeWriting(raw);if(!n)return false;
 if(task.writeMode==='word')return n===RC55_normalizeWriting(task.answer);
 if(task.writeMode==='sentence'){
  const model=RC55_normalizeWriting(task.answer);
  if(n===model||(state.grade==='1º Ano'&&n===model.replace(/[.!?]$/,'')))return true;
  return null; // Different wording is neither automatically wrong nor automatically correct.
 }
 return false;
};
RC47_submitWriting=function(){
 if(attempt.done)return;
 const el=document.querySelector('#rc47WriteInput'),raw=el?.value||'';attempt.written=raw;
 if(!raw.trim()){if(el){el.setAttribute('aria-invalid','true');el.focus()}return}
 const result=RC47_checkWriting(current,raw);
 if(result===null){attempt.needsAdultReview=true;render();return}
 answer(result?current.answer:'__RC47_WRONG__',false);
};
function RC55_confirmSentence(){
 if(attempt.done||!attempt.needsAdultReview)return;
 attempt.helpUsed=true;attempt.needsAdultReview=false;
 answer(current.answer,false);
}
const RC55_PREV_ACTIVITY=activity;
activity=function(isDiag){
 RC55_PREV_ACTIVITY(isDiag);
 const card=document.querySelector('.card.lesson');if(!card||!current)return;
 if(attempt.done&&Number(attempt.supportScore||0)===0&&!['experience','trace'].includes(current.kind)){
  const feedback=card.querySelector('.teacher-feedback');
  if(feedback&&!card.querySelector('.rc55-answer')){
   const p=document.createElement('p');p.className='rc55-answer';p.setAttribute('role','status');p.textContent='Vamos observar juntos: '+current.answer+'.';feedback.insertAdjacentElement('afterend',p);
  }
 }
 if(current.kind==='writing'&&attempt.needsAdultReview&&!attempt.done){
  const writing=card.querySelector('.rc47-writing');
  if(writing){
   const p=document.createElement('div');p.className='rc55-writing-review';p.setAttribute('role','status');
   p.innerHTML='<p>Sua frase pode ser diferente do exemplo. Peça a um adulto para conferir se ela combina com a cena, se as palavras estão separadas e se a pontuação faz sentido.</p><button type="button" class="secondary" id="rc55WritingEdit">Quero ajustar minha frase</button><button type="button" class="primary" id="rc55WritingConfirm">O adulto conferiu minha frase</button>';
   writing.appendChild(p);
   card.querySelector('#rc47WriteSubmit')?.classList.add('hidden');
   card.querySelector('#rc55WritingEdit')?.addEventListener('click',()=>{attempt.needsAdultReview=false;render()});
   card.querySelector('#rc55WritingConfirm')?.addEventListener('click',RC55_confirmSentence);
  }
 }
 if(current.kind==='trace'&&!attempt.done){
  const actions=card.querySelector('.rc47-trace-actions');
  if(actions){
   const b=document.createElement('button');b.type='button';b.className='secondary';b.textContent='Praticar de outro jeito';
   b.onclick=()=>{current=RC47_makeCursiveTask();attempt={wrong:0,done:false};render()};actions.appendChild(b);
  }
 }
};
const RC55_PREV_ADULT=adult;
adult=function(){
 RC55_PREV_ADULT();
 const card=document.querySelector('.card.adult');if(!card)return;
 const trace=card.querySelector('.rc47-bncc-trace');
 if(trace&&!trace.querySelector('.rc55-scope')){
  const p=document.createElement('p');p.className='rc55-scope';p.textContent='As atividades apoiam habilidades selecionadas da BNCC. Os registros ajudam a acompanhar a prática e não substituem a avaliação docente. O histórico anterior permanece salvo; a cobertura agora distingue tentativas de respostas bem-sucedidas. Os registros antigos da Educação Infantil podem reunir reconto e sequências visuais, sem permitir separar essas experiências.';trace.appendChild(p);
 }
 const note=card.querySelector('.rc44-version-note');if(note)note.textContent='Acompanhamento da aprendizagem';
};
const rc55Style=document.createElement('style');
rc55Style.textContent='button:focus-visible,input:focus-visible,select:focus-visible,textarea:focus-visible{outline:3px solid #123d66;outline-offset:3px}.rc55-answer,.rc55-writing-review,.rc55-scope{font-size:15px;line-height:1.5;color:#173b5e}.rc55-writing-review button{margin:6px 4px;min-height:44px}';
document.head.appendChild(rc55Style);
document.title='Intelectus Alfabetização';
render();



/* ===== curriculum-final ===== */

/* Delimited curriculum review. Existing art, recordings and learner history are preserved. */
const RC56_ALPHABET='ABCDEFGHIJKLMNOPQRSTUVWXYZ'.split('');
function RC56_needsAdultWordReview(task){
 return !!(task?.kind==='writing'&&task.writeMode==='word'&&(
  task.requiresAdultReview||!AUDIO['word:'+task.answer]||voiceLevel===0||
  state.accessibility?.hearingAccommodation||(task===current&&attempt.audioUnavailable)
 ));
}
function RC56_prepareWordTask(task){
 if(task?.kind!=='writing'||task.writeMode!=='word')return task;
 if(RC56_needsAdultWordReview(task)){
  task.requiresAdultReview=true;task.wordAssessmentMode='adult-guided';
  task.command='Escreva uma palavra para a figura e confira com um adulto.';
 }else{
  task.wordAssessmentMode='dictation';task.command='Ouça a palavra e escreva.';
 }
 return task;
}
const RC56_PREV_WORD_TASK=RC47_makeWordWritingTask;
RC47_makeWordWritingTask=function(){return RC56_prepareWordTask(RC56_PREV_WORD_TASK());};
const RC56_PREV_CHECK_WRITING=RC47_checkWriting;
RC47_checkWriting=function(task,raw){
 if(!String(raw??'').trim())return false;
 if(RC56_needsAdultWordReview(task))return null;
 return RC56_PREV_CHECK_WRITING(task,raw);
};
// Hook for the audio controller. Ignore stale tasks and completed attempts.
function RC56_markAudioUnavailable(task=current){
 if(!task||task!==current||attempt.done)return false;
 attempt.audioUnavailable=true;
 if(task.kind==='writing'&&task.writeMode==='word'){
  const input=document.querySelector('#rc47WriteInput');
  if(input)attempt.written=input.value||attempt.written||'';
  task.requiresAdultReview=true;attempt.helpUsed=true;RC56_prepareWordTask(task);
 }
 render();return true;
}
const RC56_PREV_ANSWER=answer;
answer=function(value,isDiag){
 if(!isDiag&&RC56_needsAdultWordReview(current)&&!attempt.adultReviewConfirmed&&!attempt.done){
  attempt.needsAdultReview=true;attempt.helpUsed=true;render();return;
 }
 if(!isDiag&&RC56_needsAdultWordReview(current))attempt.helpUsed=true;
 return RC56_PREV_ANSWER(value,isDiag);
};
const RC56_PREV_CONFIRM_WRITING=RC55_confirmSentence;
RC55_confirmSentence=function(){
 if(attempt.done||!attempt.needsAdultReview)return;
 if(current?.writeMode==='word'){
  const written=String(attempt.written||'').trim();
  if(!written)return;
  attempt.adultReviewConfirmed=true;attempt.helpUsed=true;
  // A reviewed synonym is evidence of the submitted word, not of the hidden target.
  if(RC55_normalizeWriting(written)!==RC55_normalizeWriting(current.answer)){
   current.reviewedTarget=current.answer;
   current.key='write:adult:'+RC55_normalizeWriting(written).slice(0,80);
  }
 }
 return RC56_PREV_CONFIRM_WRITING();
};

function RC56_eiExploration(i){
 if(i<0||i>=worlds.length)return null;
 const raw=RC43_rawStats(i);
 if(i<=3){
  const participations=Math.max(0,Number(raw.attempts)||0);
  const distinct=new Set((Array.isArray(raw.unique)?raw.unique:[]).map(String)).size;
  const ratio=Math.min(1,participations/6,distinct/3);
  return{ratio,pass:participations>=6&&distinct>=3,participations,distinct,
   label:participations+'/6 participações · '+distinct+'/3 atividades diferentes',mode:'exploration'};
 }
 const participations=Math.max(0,RC48_eiCount(worlds[i].id));
 return{ratio:Math.min(1,participations/6),pass:participations>=6,participations,
  label:participations+'/6 vivências de linguagem',mode:'exploration'};
}
const RC56_PREV_COVERAGE=RC43_coverage;
RC43_coverage=function(i){
 if(state.grade==='Pré-escola'&&i>=0&&i<worlds.length)return RC56_eiExploration(i);
 return RC56_PREV_COVERAGE(i);
};
const RC56_PREV_MASTERED=mastered;
mastered=function(i){
 if(state.grade==='Pré-escola'&&i>=0&&i<worlds.length)return RC56_eiExploration(i).pass;
 return RC56_PREV_MASTERED(i);
};
const RC56_PREV_MASTERY_REQ=masteryReq;
masteryReq=function(i){
 if(state.grade==='Pré-escola'&&i>=0&&i<worlds.length)return{attempts:6,unique:i<=3?3:0,accuracy:0,mode:'exploration'};
 return RC56_PREV_MASTERY_REQ(i);
};
const RC56_PREV_PROGRESS=progressPct;
progressPct=function(i){
 if(state.grade==='Pré-escola'&&i>=0&&i<worlds.length)return Math.round(RC56_eiExploration(i).ratio*100);
 return RC56_PREV_PROGRESS(i);
};
const RC56_PREV_LETTER_CURRICULUM=letterCurriculum;
letterCurriculum=function(){
 if(state.grade!=='Pré-escola')return RC56_PREV_LETTER_CURRICULUM();
 const attempts=Number(RC43_rawStats(0).attempts)||0,p=gradeProfile();
 const tier=attempts<p.letter[0]?1:attempts<p.letter[1]?2:3;
 const pools=['AEIOUBMPLT','AEIOUBMPLTDFVNSCGR','ABCDEFGHIJKLMNOPQRSTUVWXYZ'];
 return{tier,pool:pools[tier-1].split(''),label:['primeiras explorações de letras','ampliando as experiências','explorando o alfabeto'][tier-1]};
};
const RC56_PREV_WORLD_CARD=worldCard;
worldCard=function(w,i,n){
 let html=RC56_PREV_WORLD_CARD(w,i,n);
 if(state.grade!=='Pré-escola')return html;
 const c=RC56_eiExploration(i),status=c.pass?'Exploração concluída':'Exploração em andamento';
 html=html.replace(/(<div class="world-compact"><span class="mini-star">)[^<]*(<\/span><span>)[^<]*(<\/span>)/,
  '$1✦$2'+Math.min(6,c.participations)+'/6$3');
 return html.replace(/aria-label="([^"]*)"/,(_,label)=>'aria-label="'+label+'. '+status+'"');
};

// Resolve presentation only. Do not rewrite historical skill keys or the original world catalog.
const RC56_EI_WORLD_LABELS=[
 'Exploração de letras','Brincadeiras com sons','Exploração de sons e letras',
 'Percepção de pedaços sonoros','Vivências de linguagem','Vivências de linguagem','Vivências de linguagem'
];
function RC56_worldCodes(i,grade=state.grade){
 if(!worlds[i])return[];
 if(grade==='Pré-escola'){
  if(i<=3)return[];
  return[...new Set(RC47_EI_EXPERIENCES.map(x=>x.code).filter(c=>/^EI03EF\d{2}$/.test(c)))];
 }
 let codes=[...worlds[i].bncc];
 if(i===0)codes=codes.filter(c=>c!=='EF02LP07');
 if(i===6)codes=codes.filter(c=>c!=='EF12LP02').concat('EF15LP03');
 if(i===2||i===4)codes.push('EF02LP05');
 if(i===3)codes=codes.filter(c=>c!=='EF02LP05');
 const year=grade==='2º Ano'?'02':'01';
 return[...new Set(codes.filter(c=>new RegExp('^EF('+year+'|12|15)LP\\d{2}$').test(c)))];
}
function RC56_gradeCodes(grade=state.grade){
 return[...new Set(worlds.flatMap((_,i)=>RC56_worldCodes(i,grade)))];
}
const RC56_PREV_ADULT=adult;
adult=function(){
 RC56_PREV_ADULT();
 const card=document.querySelector('.card.adult');if(!card)return;
 const isEI=state.grade==='Pré-escola';
 card.querySelectorAll('.adult-row').forEach((row,i)=>{
  const codes=RC56_worldCodes(i),caption=row.querySelector('small');
  if(caption)caption.textContent=codes.length?codes.join(' · '):RC56_EI_WORLD_LABELS[i];
  if(!isEI)return;
  const c=RC56_eiExploration(i),line=row.querySelector('.rc43-mastery-line');
  if(line)line.innerHTML='<b>'+(c.pass?'Exploração concluída':'Exploração em andamento')+'</b><span>'+escapeHtml(c.label)+'</span><small>O avanço considera participação e experiências. O histórico de tentativas permanece salvo.</small>';
  Array.from(row.children).forEach(el=>{
   if(!el.classList?.contains('rc43-mastery-line')&&/práticas|autônomas/.test(el.textContent||'')){
    el.textContent=c.participations+' participações registradas';
   }
  });
 });
 const codes=card.querySelector('.rc47-bncc-codes');
 if(codes)codes.innerHTML=RC56_gradeCodes().map(c=>'<span>'+escapeHtml(c)+'</span>').join('');
 const trace=card.querySelector('.rc47-bncc-trace');
 const text=trace?.querySelector('p');
 if(text)text.textContent=isEI?
  'As propostas de linguagem são experiências acompanhadas. A trilha avança por participação; os códigos abaixo se referem às vivências de oralidade e escrita espontânea oferecidas.':
  'Referências das atividades oferecidas nesta etapa. A prática de ordem alfabética, a recitação acompanhada e a escrita cursiva têm registros e limites diferentes; a avaliação docente continua necessária.';
 // Refresh the curriculum and progress summary immediately after the existing save.
 const saveProfile=card.querySelector('#saveProfile');
 if(saveProfile)saveProfile.addEventListener('click',()=>{
  render();const note=document.querySelector('#profileNote');
  if(note){note.textContent='Perfil salvo neste aparelho.';note.setAttribute('role','status');}
 });
};

function RC56_makeAlphabetOrderTask(){
 return uniqueTask(()=>{
  const index=1+Math.floor(Math.random()*25),letter=RC56_ALPHABET[index];
  const before=RC56_ALPHABET.slice(Math.max(0,index-2),index);
  const others=shuffle(RC56_ALPHABET.filter(x=>x!==letter&&!before.includes(x))).slice(0,2);
  return{world:'letters',skill:'letters:alphabet-order',key:'order:'+RC56_ALPHABET[index-1]+':'+letter,
   sig:'rc56-order:'+index,command:'Qual letra vem a seguir na ordem do alfabeto?',audio:[],
   kind:'letter',stimulus:{type:'lettergrid',items:[...before,'?']},options:shuffle([letter,...others]),answer:letter};
 });
}
const RC56_PREV_MAKE_TASK=makeTask;
makeTask=function(i){
 if(i===0&&state.grade!=='Pré-escola'&&Math.random()<.15)return RC56_makeAlphabetOrderTask();
 return RC56_PREV_MAKE_TASK(i);
};
const RC56_PREV_WEAK_TASK=RC43_taskForWeakSkill;
RC43_taskForWeakSkill=function(i,id){
 if(i===0&&state.grade!=='Pré-escola'&&id==='letters:alphabet-order')return RC56_makeAlphabetOrderTask();
 return RC56_PREV_WEAK_TASK(i,id);
};
let rc56OralRecorded=false;
function RC56_listenAlphabet(){return playSeq(RC56_ALPHABET.map(letter=>AUDIO['letter:'+letter]));}
function RC56_recordAlphabetPractice(){
 if(rc56OralRecorded||state.grade==='Pré-escola')return false;
 rc56OralRecorded=true;
 const previous=state.alphabetOralPractice||{};
 state.alphabetOralPractice={...previous,count:(Number(previous.count)||0)+1,last:Date.now(),verification:'adult-declared'};
 safeSave();
 const button=document.querySelector('#rc56AlphabetOral');
 if(button){button.disabled=true;button.textContent='Prática oral registrada';}
 return true;
}
const RC56_PREV_MICRO=micro;
micro=function(){
 RC56_PREV_MICRO();rc56OralRecorded=false;
 const card=document.querySelector('.card.micro');if(!card)return;
 if(state.grade==='Pré-escola'){
  if(pendingWorld===0){const note=card.querySelector('.tier-note');if(note)note.textContent='Com novas experiências, outras letras entram na brincadeira.';}
  return;
 }
 if(pendingWorld!==0||card.querySelector('#rc56AlphabetPractice'))return;
 const box=document.createElement('div');box.id='rc56AlphabetPractice';box.className='rc56-practice';
 box.innerHTML='<button class="soft" type="button" id="rc56AlphabetListen">Ouvir o alfabeto</button><button class="secondary" type="button" id="rc56AlphabetOral">Pratiquei recitar com um adulto</button><p>O adulto acompanha a recitação. Este registro indica uma prática realizada e não uma avaliação automática.</p>';
 card.querySelector('.examples')?.insertAdjacentElement('afterend',box);
 box.querySelector('#rc56AlphabetListen')?.addEventListener('click',RC56_listenAlphabet);
 box.querySelector('#rc56AlphabetOral')?.addEventListener('click',RC56_recordAlphabetPractice);
};

const RC56_RECOUNTS=[
 {id:'oral-reconto',scene:'👧⚽',storyText:'Lia ganhou uma bola e foi brincar no quintal.',storyKey:'c1'},
 {id:'oral-reconto-sapo',scene:'🐸🌊',storyText:'O sapo pulou no lago para nadar.',storyKey:'c2',
  instruction:'Ouça a história e depois conte com suas palavras o que aconteceu com o sapo.'},
 {id:'oral-reconto-gato',scene:'🌧️🐱🏠',storyText:'Começou a chover. O gato correu para dentro da casa.',storyKey:'c3',
  instruction:'Ouça a história e depois conte com suas palavras o que aconteceu com o gato.'}
];
for(const x of RC56_RECOUNTS){
 const existing=RC47_EI_EXPERIENCES.find(e=>e.id===x.id);
 if(existing)Object.assign(existing,{storyText:x.storyText,storyKey:x.storyKey});
 else RC47_EI_EXPERIENCES.push({...x,code:'EI03EF04',label:'Reconto oral',audio:[AUDIO['story:'+x.storyKey+'_historia']]});
}
const RC56_PREV_RECORD_EI=RC47_recordEI;
RC47_recordEI=function(task,text=''){
 RC56_PREV_RECORD_EI(task,text);
 const story=task?.experience?.storyKey;if(!story)return;
 state.eiStoryPractices=state.eiStoryPractices&&typeof state.eiStoryPractices==='object'?state.eiStoryPractices:{};
 const previous=state.eiStoryPractices[story]||{};
 state.eiStoryPractices[story]={...previous,count:(Number(previous.count)||0)+1,last:Date.now(),verification:'participation-declared'};
 safeSave();
};

const RC56_PREV_ACTIVITY=activity;
activity=function(isDiag){
 if(!isDiag)RC56_prepareWordTask(current);
 RC56_PREV_ACTIVITY(isDiag);
 if(isDiag||!current)return;
 const card=document.querySelector('.card.lesson');if(!card)return;
 if(current.kind==='writing'&&current.writeMode==='word'&&!attempt.done){
  const writing=card.querySelector('.rc47-writing');
  const note=card.querySelector('.rc47-write-note');
  if(note)note.textContent=RC56_needsAdultWordReview(current)?
   'Um adulto confere a palavra e sua escrita. Essa participação é registrada como acompanhada.':
   'Escreva a palavra narrada. Você pode ouvi-la novamente.';
  if(writing&&!writing.querySelector('#rc56WordAudioFallback')&&!RC56_needsAdultWordReview(current)){
   const button=document.createElement('button');button.id='rc56WordAudioFallback';button.type='button';button.className='secondary';
   button.textContent='Não consegui ouvir';button.addEventListener('click',()=>RC56_markAudioUnavailable(current));writing.appendChild(button);
  }
  if(attempt.needsAdultReview){
   const review=card.querySelector('.rc55-writing-review');
   if(review){
    const p=review.querySelector('p');if(p)p.textContent='Peça a um adulto para conferir se a palavra que você escreveu combina com a figura e se sua escrita está adequada. A figura pode ter mais de um nome.';
    const edit=review.querySelector('#rc55WritingEdit');if(edit)edit.textContent='Quero ajustar minha palavra';
    const confirm=review.querySelector('#rc55WritingConfirm');if(confirm)confirm.textContent='O adulto conferiu minha palavra';
   }
  }
 }
 if(current.kind==='experience'&&current.experience?.storyText&&!attempt.done){
  const experience=card.querySelector('.rc47-experience');
  if(experience&&!experience.querySelector('.rc56-story-text')){
   const details=document.createElement('details');details.className='rc56-story-text';
   details.innerHTML='<summary>Para o adulto: ler a história</summary><p>'+escapeHtml(current.experience.storyText)+'</p>';
   experience.appendChild(details);
  }
 }
};
const rc56Style=document.createElement('style');
rc56Style.textContent='.rc56-practice{display:grid;gap:8px;margin:12px 0}.rc56-practice button{min-height:44px}.rc56-practice p,.rc56-story-text{font-size:14px;line-height:1.45}.rc56-story-text{margin-top:10px;text-align:left}';
document.head.appendChild(rc56Style);
window.RC56_AUDIT={scope:'participation-and-curriculum-review',worldCodes:RC56_worldCodes,eiExploration:RC56_eiExploration};
render();



/* ===== access-config ===== */

/* Candidate configuration. Publish only after the commercial offer and public key are approved.
 * Never place a private signing key in this file or anywhere in the application package. */
window.INTELECTUS_ACCESS_CONFIG = Object.freeze({"enabled":true,"appId":"intelectus-alfabetizacao","trialDays":7,"publicKeyJwk":{"kty":"EC","x":"fONLShCLwcCFoTJoAC7VhsZSSZHEXXAR0Yx6t2jePwY","y":"_3fUE30zkDuZf7SCwKP71RW9rC2N_knaFgqzjQv5PRE","crv":"P-256","alg":"ES256","use":"sig","key_ops":["verify"],"ext":true},"checkoutUrl":"https://www.portalintelectus.com.br/contratar?produto=Intelectus%20Alfabetiza%C3%A7%C3%A3o%C2%AE&origem=app-acesso","offerLabel":"Intelectus Alfabetização®","priceLabel":"Planos e assinatura gerenciados no Portal Intelectus"});



/* ===== access-core ===== */

/*
 * Intelectus Alfabetização — standalone access policy, version 1.
 * No DOM, storage, network, private keys, prices or checkout are used here.
 * All times are integer Unix milliseconds. Callers must persist the trial
 * separately from pedagogical progress and observe it before allowing play.
 * A trial starts ONLY through an explicit createTrial call, never evaluate.
 *
 * License format: base64url(UTF-8 JSON payload) + '.' + base64url(signature).
 * Sign UTF-8 bytes of the FIRST segment, using ECDSA P-256 / SHA-256.
 * Signature is the Web Crypto 64-byte r || s representation, not ASN.1 DER.
 * Payload: {version:1, appId, licenseId, installationId, issuedAt,
 *           expiresAt?}. Omitted expiresAt means no signed expiry.
 * The publisher signs externally. Only a PUBLIC JWK belongs in the app.
 * Reference: https://www.w3.org/TR/webcrypto/#ecdsa-operations
 *
 * Limits: local time and records are not trusted server evidence. Clearing
 * storage, replacing a device ID, editing records/code, or reinstalling can
 * bypass a purely local trial. An offline license cannot be revoked remotely.
 * No claim of payment verification, identity verification, or tamper resistance.
 */
(function (root) {
  'use strict';

  var APP_ID = 'intelectus-alfabetizacao';
  var TRIAL_MS = 7 * 24 * 60 * 60 * 1000;
  var CLOCK_TOLERANCE_MS = 5 * 60 * 1000;
  var MAX_TIME = 8640000000000000;
  var own = function (value, key) {
    return Object.prototype.hasOwnProperty.call(value, key);
  };
  var object = function (value) {
    return value !== null && typeof value === 'object' && !Array.isArray(value);
  };
  var time = function (value) {
    return Number.isSafeInteger(value) && value >= 0 && value <= MAX_TIME;
  };
  var id = function (value, minimum) {
    return typeof value === 'string' && value.length >= minimum &&
      value.length <= 128 && /^[A-Za-z0-9][A-Za-z0-9._:-]*$/.test(value);
  };
  function result(status, allowed, extra) {
    return Object.assign({ status: status, allowed: allowed, remainingMs: 0 }, extra || {});
  }
  function trialShape(record) {
    return object(record) && record.version === 1 && record.type === 'trial' &&
      record.appId === APP_ID && id(record.installationId, 8) &&
      time(record.startedAt) && time(record.expiresAt) && time(record.lastSeenAt) &&
      record.startedAt <= MAX_TIME - TRIAL_MS &&
      record.expiresAt === record.startedAt + TRIAL_MS &&
      record.lastSeenAt >= record.startedAt;
  }
  function createTrial(now, installationId) {
    if (!time(now) || now > MAX_TIME - TRIAL_MS) {
      throw new TypeError('now must be a valid Unix millisecond timestamp');
    }
    if (!id(installationId, 8)) {
      throw new TypeError('installationId must contain 8–128 ASCII identifier characters');
    }
    return {
      version: 1,
      type: 'trial',
      appId: APP_ID,
      installationId: installationId,
      startedAt: now,
      expiresAt: now + TRIAL_MS,
      lastSeenAt: now
    };
  }
  function evaluate(record, now, config) {
    if (!time(now)) return result('invalid_time', false);
    if (record === null || typeof record === 'undefined') {
      return result('not_started', false);
    }
    if (!trialShape(record)) return result('invalid_record', false);
    if (config !== undefined && config !== null && !object(config)) {
      return result('invalid_configuration', false);
    }
    if (config && own(config, 'appId') && config.appId !== record.appId) {
      return result('invalid_record', false, { reason: 'app_mismatch' });
    }
    if (config && own(config, 'installationId') && config.installationId !== record.installationId) {
      return result('invalid_record', false, { reason: 'installation_mismatch' });
    }
    if (now < record.lastSeenAt - CLOCK_TOLERANCE_MS) {
      return result('clock_rollback', false, { expiresAt: record.expiresAt });
    }
    // A tolerated clock drift never adds time to the trial.
    var effectiveNow = Math.max(now, record.lastSeenAt);
    var remainingMs = Math.max(0, record.expiresAt - effectiveNow);
    return result(remainingMs > 0 ? 'trial_active' : 'trial_expired', remainingMs > 0, {
      remainingMs: remainingMs,
      expiresAt: record.expiresAt,
      effectiveNow: effectiveNow
    });
  }
  function observe(record, now) {
    // Never create or repair a trial implicitly. Preserve malformed data as a
    // blocked record, rather than returning null (which means never started).
    if (record === null || typeof record === 'undefined') return record;
    if (!trialShape(record)) return { version: 1, type: 'invalid', reason: 'invalid_record' };
    if (!time(now)) return Object.assign({}, record);
    return Object.assign({}, record, { lastSeenAt: Math.max(record.lastSeenAt, now) });
  }

  function encode64(bytes) {
    var binary = '';
    for (var i = 0; i < bytes.length; i += 1) binary += String.fromCharCode(bytes[i]);
    var encoded;
    if (typeof root.btoa === 'function') encoded = root.btoa(binary);
    else if (typeof Buffer !== 'undefined') encoded = Buffer.from(bytes).toString('base64');
    else throw new Error('base64 unavailable');
    return encoded.replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
  }
  function decode64(value, maximum) {
    if (typeof value !== 'string' || !/^[A-Za-z0-9_-]+$/.test(value) ||
        value.length > maximum || value.length % 4 === 1) throw new Error('invalid base64url');
    var encoded = value.replace(/-/g, '+').replace(/_/g, '/');
    encoded += '='.repeat((4 - encoded.length % 4) % 4);
    var bytes;
    if (typeof root.atob === 'function') {
      var binary = root.atob(encoded);
      bytes = Uint8Array.from(binary, function (character) { return character.charCodeAt(0); });
    } else if (typeof Buffer !== 'undefined') bytes = new Uint8Array(Buffer.from(encoded, 'base64'));
    else throw new Error('base64 unavailable');
    if (encode64(bytes) !== value) throw new Error('noncanonical base64url');
    return bytes;
  }
  function publicKeyShape(jwk) {
    if (!object(jwk) || jwk.kty !== 'EC' || jwk.crv !== 'P-256' || own(jwk, 'd') ||
        (own(jwk, 'alg') && jwk.alg !== 'ES256') ||
        (own(jwk, 'use') && jwk.use !== 'sig')) return false;
    if (own(jwk, 'key_ops') && (!Array.isArray(jwk.key_ops) ||
        jwk.key_ops.length !== 1 || jwk.key_ops[0] !== 'verify')) return false;
    try {
      return decode64(jwk.x, 43).length === 32 && decode64(jwk.y, 43).length === 32;
    } catch (_) { return false; }
  }
  async function verifyLicense(token, config, installationId, now) {
    if (!object(config) || !config.appId || !config.publicKeyJwk) {
      return result('not_configured', false);
    }
    if (!id(config.appId, 1) || !publicKeyShape(config.publicKeyJwk)) {
      return result('invalid_configuration', false);
    }
    if (!time(now)) return result('invalid_time', false);
    if (!id(installationId, 8)) return result('invalid_installation', false);
    if (!root.crypto || !root.crypto.subtle || typeof root.TextEncoder !== 'function' ||
        typeof root.TextDecoder !== 'function') return result('unsupported_environment', false);
    if (typeof token !== 'string' || token.length > 8192) return result('invalid_license', false);
    var segments = token.split('.');
    if (segments.length !== 2) return result('invalid_license', false);
    var signature, payloadBytes;
    try {
      payloadBytes = decode64(segments[0], 4096);
      signature = decode64(segments[1], 86);
      if (signature.length !== 64) return result('invalid_license', false);
    } catch (_) { return result('invalid_license', false); }
    var key;
    try {
      key = await root.crypto.subtle.importKey('jwk', {
        kty: 'EC', crv: 'P-256', x: config.publicKeyJwk.x, y: config.publicKeyJwk.y,
        ext: true, key_ops: ['verify']
      }, { name: 'ECDSA', namedCurve: 'P-256' }, false, ['verify']);
    } catch (_) { return result('invalid_configuration', false); }
    try {
      var verified = await root.crypto.subtle.verify(
        { name: 'ECDSA', hash: 'SHA-256' }, key, signature,
        new root.TextEncoder().encode(segments[0])
      );
      if (!verified) return result('invalid_signature', false);
    } catch (_) { return result('invalid_signature', false); }
    var payload;
    try {
      payload = JSON.parse(new root.TextDecoder('utf-8', { fatal: true }).decode(payloadBytes));
    } catch (_) { return result('invalid_license', false); }
    if (!object(payload) || payload.version !== 1 || !id(payload.appId, 1) ||
        !id(payload.licenseId, 1) || !id(payload.installationId, 8) || !time(payload.issuedAt) ||
        (own(payload, 'expiresAt') && (!time(payload.expiresAt) || payload.expiresAt <= payload.issuedAt))) {
      return result('invalid_license', false);
    }
    if (payload.appId !== config.appId) return result('app_mismatch', false);
    if (payload.installationId !== installationId) return result('installation_mismatch', false);
    if (now < payload.issuedAt) return result('license_not_yet_valid', false);
    if (own(payload, 'expiresAt') && now >= payload.expiresAt) return result('license_expired', false);
    return result('licensed', true, {
      licenseId: payload.licenseId,
      installationId: payload.installationId,
      issuedAt: payload.issuedAt,
      expiresAt: own(payload, 'expiresAt') ? payload.expiresAt : null,
      remainingMs: own(payload, 'expiresAt') ? payload.expiresAt - now : null
    });
  }

  var api = Object.freeze({
    APP_ID: APP_ID,
    TRIAL_MS: TRIAL_MS,
    CLOCK_TOLERANCE_MS: CLOCK_TOLERANCE_MS,
    createTrial: createTrial,
    evaluate: evaluate,
    observe: observe,
    verifyLicense: verifyLicense
  });
  root.IntelectusAccess = api;
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
}(typeof globalThis !== 'undefined' ? globalThis : this));



/* ===== access-ui ===== */

/* Local access UI. Load after access-config.js, access-core.js and every pedagogical override.
 * Access records deliberately live outside APPKEY: resetting/exporting progress does not
 * renew a trial or transfer a licence. Only a successfully verified signature unlocks paid access.
 * A local-only trial is not resistant to clearing storage or modifying application code. */
(function (root) {
  'use strict';
  const host = window;
  const core = root.IntelectusAccess || host.IntelectusAccess;
  const config = host.INTELECTUS_ACCESS_CONFIG || {};
  const accessKey = APPKEY + ':access:v1';
  const installationKey = APPKEY + ':access-installation:v1';
  const protectedViews = new Set(['diagnosticIntro', 'diagnostic', 'micro', 'lesson', 'gateIntro', 'gateEnd']);
  const previousRender = render;
  const previousAdult = adult;
  let storage = null, envelope = null, installationId = '', storageProblem = '';
  let verified = null, verifiedToken = '', verifyingToken = '', verificationEpoch = 0;
  let pendingVerification = null, notice = '', pending = false;

  function denied(status) { return { status, allowed: false, remainingMs: 0 }; }
  function validTime(value) { return Number.isSafeInteger(value) && value >= 0; }
  function validEnvelope(value) {
    return value && typeof value === 'object' && !Array.isArray(value) &&
      value.version === 1 && value.installationId === installationId &&
      validTime(value.lastSeenAt) && Object.prototype.hasOwnProperty.call(value, 'record') &&
      typeof value.licenseToken === 'string' && value.licenseToken.length <= 8192;
  }
  function initializeStorage() {
    try {
      storage = host.localStorage;
      const probe = accessKey + ':probe';
      storage.setItem(probe, '1');
      if (storage.getItem(probe) !== '1') throw new Error('storage');
      storage.removeItem(probe);
      const raw = storage.getItem(accessKey), storedId = storage.getItem(installationKey);
      if (raw === null && storedId === null) {
        const cryptoApi = root.crypto || host.crypto;
        if (!cryptoApi || typeof cryptoApi.getRandomValues !== 'function') throw new Error('crypto');
        const bytes = new Uint8Array(16);
        cryptoApi.getRandomValues(bytes);
        installationId = Array.from(bytes, value => value.toString(16).padStart(2, '0')).join('');
        const now = Date.now();
        if (!validTime(now)) throw new Error('time');
        envelope = { version: 1, installationId, lastSeenAt: now, record: null, licenseToken: '' };
        storage.setItem(installationKey, installationId);
        storage.setItem(accessKey, JSON.stringify(envelope));
      } else {
        installationId = storedId || '';
        if (!/^[A-Za-z0-9][A-Za-z0-9._:-]{7,127}$/.test(installationId) || raw === null) {
          storageProblem = 'invalid_storage'; return;
        }
        try { envelope = JSON.parse(raw); } catch (_) { storageProblem = 'invalid_storage'; return; }
        if (!validEnvelope(envelope)) storageProblem = 'invalid_storage';
      }
    } catch (_) { storageProblem = 'storage_unavailable'; }
  }
  function readEnvelope() {
    if (storageProblem) return false;
    try {
      if (storage.getItem(installationKey) !== installationId) {
        storageProblem = 'invalid_storage'; return false;
      }
      const raw = storage.getItem(accessKey);
      let fresh;
      try { fresh = JSON.parse(raw); } catch (_) { storageProblem = 'invalid_storage'; return false; }
      if (!validEnvelope(fresh)) { storageProblem = 'invalid_storage'; return false; }
      // A second tab cannot move the observed clock backwards in this running tab.
      fresh.lastSeenAt = Math.max(fresh.lastSeenAt, envelope?.lastSeenAt || 0);
      if (fresh.record && envelope?.record && fresh.record.startedAt === envelope.record.startedAt &&
          validTime(fresh.record.lastSeenAt) && validTime(envelope.record.lastSeenAt)) {
        fresh.record.lastSeenAt = Math.max(fresh.record.lastSeenAt, envelope.record.lastSeenAt);
      }
      envelope = fresh;
      return true;
    } catch (_) { storageProblem = 'storage_unavailable'; return false; }
  }
  function persist(nextEnvelope) {
    try {
      const encoded = JSON.stringify(nextEnvelope);
      storage.setItem(accessKey, encoded);
      if (storage.getItem(accessKey) !== encoded) throw new Error('storage');
      envelope = nextEnvelope;
      return true;
    } catch (_) { storageProblem = 'storage_unavailable'; return false; }
  }
  function clockStatus(now) {
    if (!validTime(now)) return denied('invalid_time');
    if (now < envelope.lastSeenAt - core.CLOCK_TOLERANCE_MS) return denied('clock_rollback');
    return null;
  }
  function verifyStoredLicense(token, now) {
    if (verifyingToken === token && pendingVerification) return pendingVerification;
    const epoch = ++verificationEpoch;
    verifyingToken = token;
    pendingVerification = core.verifyLicense(token, config, installationId, now).then(result => {
      if (epoch !== verificationEpoch) return result;
      verifiedToken = token;
      verified = result;
      verifyingToken = '';
      pendingVerification = null;
      if (view === 'access' || view === 'adult' || protectedViews.has(view)) render();
      return result;
    }).catch(() => {
      if (epoch === verificationEpoch) {
        verifiedToken = token; verified = denied('verification_failed');
        verifyingToken = ''; pendingVerification = null;
        if (view === 'access' || view === 'adult' || protectedViews.has(view)) render();
      }
      return denied('verification_failed');
    });
    return pendingVerification;
  }
  function status(touch = true) {
    if (config.enabled === false) return { status: 'disabled', allowed: true, remainingMs: null };
    if (!core || config.appId !== 'intelectus-alfabetizacao' || config.trialDays !== 7) return denied('invalid_configuration');
    if (!readEnvelope()) return denied(storageProblem);
    const now = Date.now(), clock = clockStatus(now);
    if (clock) return clock;
    const effectiveNow = Math.max(now, envelope.lastSeenAt);
    const trial = core.evaluate(envelope.record, effectiveNow, { appId: config.appId, installationId });
    if (touch && !persist({ ...envelope, record: core.observe(envelope.record, effectiveNow), lastSeenAt: effectiveNow })) {
      return denied(storageProblem);
    }
    const token = envelope.licenseToken;
    if (token) {
      if (verifiedToken !== token) {
        verifyStoredLicense(token, effectiveNow);
        return trial.allowed ? trial : denied('verifying');
      }
      if (verified?.allowed) {
        if (effectiveNow < verified.issuedAt) return denied('clock_rollback');
        if (verified.expiresAt !== null && effectiveNow >= verified.expiresAt) {
          return trial.allowed ? trial : denied('license_expired');
        }
        return { ...verified, remainingMs: verified.expiresAt === null ? null : verified.expiresAt - effectiveNow };
      }
      if (!trial.allowed) return verified || trial;
    }
    return trial;
  }
  function dateLabel(timestamp) {
    return new Date(timestamp).toLocaleString('pt-BR', { day: '2-digit', month: '2-digit', year: 'numeric', hour: '2-digit', minute: '2-digit' });
  }
  function statusCopy(result) {
    const remainingDays = Math.max(1, Math.ceil((result.remainingMs || 0) / 86400000));
    const messages = {
      not_started: ['Sete dias para conhecer a aventura', 'O responsável pode iniciar 7 dias completos de acesso gratuito neste aparelho.'],
      trial_active: ['Período gratuito em andamento', 'Restam ' + remainingDays + (remainingDays === 1 ? ' dia' : ' dias') + '. O acesso gratuito termina em ' + dateLabel(result.expiresAt) + '.'],
      trial_expired: ['O período gratuito terminou', 'Para continuar as atividades, é preciso ativar uma licença de um plano pago. O progresso continua salvo neste aparelho.'],
      licensed: ['Licença ativa', result.expiresAt ? 'Acesso válido até ' + dateLabel(result.expiresAt) + '.' : 'A licença deste aparelho não tem data de expiração.'],
      license_expired: ['A licença terminou', 'Ative uma licença válida para continuar as atividades. O progresso continua salvo neste aparelho.'],
      clock_rollback: ['Confira a data e a hora', 'Ative a data e a hora automáticas do aparelho e abra o aplicativo novamente. O progresso permanece disponível na área da família.'],
      invalid_time: ['Confira a data e a hora', 'A data deste aparelho não pôde ser validada. Corrija a data e a hora para verificar o acesso.'],
      storage_unavailable: ['Precisamos salvar o acesso neste aparelho', 'O navegador não permitiu guardar o acesso. Permita o armazenamento do site e abra o aplicativo novamente. A área da família e a exportação continuam disponíveis.'],
      invalid_storage: ['Não foi possível conferir o acesso salvo', 'O registro de acesso deste aparelho está incompleto ou inválido. As atividades estão pausadas. Você pode consultar e exportar o progresso na área da família.'],
      invalid_record: ['Não foi possível conferir o período gratuito', 'O registro do período gratuito está inválido. Você pode consultar e exportar o progresso ou ativar uma licença válida.'],
      verifying: ['Conferindo a licença', 'Aguarde um instante enquanto o aplicativo confere a licença salva neste aparelho.'],
      not_configured: ['Ativação ainda indisponível', 'A ativação de licenças ainda não está configurada nesta versão.'],
      invalid_configuration: ['Acesso indisponível nesta versão', 'A configuração de acesso precisa ser concluída. A área da família e a exportação continuam disponíveis.'],
      installation_mismatch: ['A licença pertence a outro aparelho', 'Confira o código deste aparelho com quem forneceu sua licença.'],
      app_mismatch: ['A licença é de outro aplicativo', 'Use uma licença do Intelectus Alfabetização.'],
      license_not_yet_valid: ['A licença ainda não está válida', 'Confira a data e a hora do aparelho e o início de validade informado para a licença.'],
      unsupported_environment: ['Este navegador não pôde conferir a licença', 'Abra o aplicativo pelo endereço seguro em um navegador atualizado.'],
      disabled: ['Acesso disponível', 'As atividades estão disponíveis nesta configuração.']
    };
    return messages[result.status] || ['Não foi possível validar a licença', 'Confira se o código foi copiado por completo e se é uma licença deste aparelho.'];
  }
  function purchaseUrl() {
    if (!config.publicKeyJwk || !config.offerLabel || !config.priceLabel || !config.checkoutUrl) return '';
    try {
      const url = new URL(config.checkoutUrl);
      return url.protocol === 'https:' && !url.username && !url.password ? url.href : '';
    } catch (_) { return ''; }
  }
  function openAccess() {
    stopVoice(); view = 'access'; notice = ''; render();
    document.querySelector('#accessTitle')?.focus();
  }
  function ensureAccess() {
    const result = status();
    if (result.allowed) return true;
    openAccess(); return false;
  }
  function continueLearning() {
    view = state.onboarded ? (state.diagnosticDone ? 'home' : 'diagnosticIntro') : 'onboardName';
    render();
  }
  function startTrial() {
    if (pending) return false;
    const before = status();
    if (before.status !== 'not_started' || envelope?.record !== null) return false;
    pending = true;
    try {
      const now = Math.max(Date.now(), envelope.lastSeenAt);
      if (!persist({ ...envelope, record: core.createTrial(now, installationId), lastSeenAt: now })) {
        render(); return false;
      }
      notice = ''; continueLearning(); return true;
    } catch (_) { notice = 'Não foi possível iniciar o período gratuito. Confira o acesso neste aparelho.'; render(); return false; }
    finally { pending = false; }
  }
  async function activateLicense(value) {
    if (pending) return denied('busy');
    if (!core || !readEnvelope()) { render(); return denied(storageProblem || 'invalid_configuration'); }
    const now = Date.now(), clock = clockStatus(now);
    if (clock) { notice = statusCopy(clock)[1]; render(); return clock; }
    const token = String(value || '').trim();
    if (!token) { notice = 'Cole o código completo da licença para continuar.'; render(); document.querySelector('#accessLicenseToken')?.focus(); return denied('invalid_license'); }
    pending = true; notice = 'Conferindo a licença…'; render();
    const result = await core.verifyLicense(token, config, installationId, Math.max(now, envelope.lastSeenAt)).catch(() => denied('verification_failed'));
    pending = false;
    if (result.allowed) {
      // Reread after the asynchronous operation so another tab's later timestamp is retained.
      if (!readEnvelope()) { render(); return denied(storageProblem); }
      const nextNow = Date.now(), nextClock = clockStatus(nextNow);
      if (nextClock) { notice = statusCopy(nextClock)[1]; render(); return nextClock; }
      const effectiveNow = Math.max(nextNow, envelope.lastSeenAt);
      if (result.expiresAt !== null && effectiveNow >= result.expiresAt) {
        notice = statusCopy(denied('license_expired'))[1]; render(); return denied('license_expired');
      }
      if (!persist({ ...envelope, licenseToken: token, lastSeenAt: effectiveNow, record: core.observe(envelope.record, effectiveNow) })) { render(); return denied(storageProblem); }
      verificationEpoch++; verifiedToken = token; verified = result; verifyingToken = ''; pendingVerification = null;
      notice = 'Licença ativada. Você já pode continuar a aventura.';
    } else notice = statusCopy(result)[1];
    render(); return result;
  }
  function renderAccess() {
    const result = status(), copy = statusCopy(result), checkout = purchaseUrl();
    setTop(false);
    const canStart = result.status === 'not_started';
    const canActivate = !!config.publicKeyJwk && !storageProblem;
    document.querySelector('#view').innerHTML = `<section class="view"><div class="card adult access-card" aria-labelledby="accessTitle">
      <p class="access-kicker">ÁREA DO RESPONSÁVEL</p><h1 id="accessTitle" tabindex="-1">Acesso e licença</h1>
      <div class="access-status"><h2>${escapeHtml(copy[0])}</h2><p>${escapeHtml(copy[1])}</p></div>
      ${canStart ? `<p>O responsável pode iniciar o período gratuito neste aparelho. Nenhum dado de pagamento é solicitado dentro do aplicativo.</p><button type="button" class="primary-xl" id="accessStartTrial">Iniciar meus 7 dias gratuitos</button>` : ''}
      ${result.allowed ? '<button type="button" class="primary-xl" id="accessContinue">Continuar a aventura</button>' : ''}
      <div class="access-offer"><h2>${result.status==='license_expired'?'Renovar acesso':'Planos e assinatura'}</h2>${checkout && !result.allowed ? `<p>${escapeHtml(config.offerLabel)} · ${escapeHtml(config.priceLabel)}.</p><p>Pagamento, mensal/anual, combos e licenças familiares ou escolares são administrados somente no Portal Intelectus.</p><a class="secondary access-purchase" href="${escapeHtml(checkout)}" target="_blank" rel="noopener noreferrer">${result.status==='license_expired'?'Renovar acesso':'Assinar Intelectus Alfabetização'} <span class="access-small">(abre o Portal)</span></a>` : result.allowed ? '<p>Seu acesso está ativo. Planos e assinatura são administrados pelo Portal Intelectus.</p>' : '<p>O acesso às atividades está pausado até que uma licença válida seja ativada pelo Portal Intelectus.</p>'}</div>
      <div class="access-activation"><h2>Já tem uma licença?</h2><label for="accessLicenseToken">Código completo da licença</label><textarea id="accessLicenseToken" rows="4" maxlength="8192" autocomplete="off" autocapitalize="off" spellcheck="false" aria-describedby="accessLicenseHelp" ${canActivate && !pending ? '' : 'disabled'}></textarea>
      <p id="accessLicenseHelp" class="access-small">${canActivate ? 'Use a licença fornecida para o código deste aparelho. O aplicativo confere a licença antes de liberar o acesso.' : 'A ativação de licenças ainda está indisponível nesta versão.'}</p>
      ${canActivate ? `<button type="button" class="secondary" id="accessActivate" ${pending ? 'disabled' : ''}>${pending ? 'Conferindo…' : 'Ativar licença'}</button>` : ''}
      ${installationId ? `<label for="accessInstallationId">Código deste aparelho</label><input id="accessInstallationId" value="${escapeHtml(installationId)}" readonly class="profile-input" aria-describedby="accessInstallationHelp"><p id="accessInstallationHelp" class="access-small">Este código identifica a instalação para a emissão da licença.</p>` : ''}</div>
      <p id="accessNotice" role="status" aria-live="polite">${escapeHtml(notice)}</p>
      <p class="access-small">Seu progresso fica neste aparelho. Na área da família, você pode consultá-lo e exportar uma cópia, mesmo com as atividades pausadas. Recomeçar o progresso não reinicia o período gratuito.</p>
      <div class="access-actions"><button type="button" class="secondary" id="accessFamily">Ver e exportar progresso</button><button type="button" class="soft" id="accessBack">Voltar</button></div>${footer()}
      </div></section>`;
    document.querySelector('#accessStartTrial')?.addEventListener('click', startTrial);
    document.querySelector('#accessContinue')?.addEventListener('click', continueLearning);
    document.querySelector('#accessActivate')?.addEventListener('click', () => activateLicense(document.querySelector('#accessLicenseToken')?.value));
    document.querySelector('#accessFamily')?.addEventListener('click', () => { view = 'adult'; render(); });
    document.querySelector('#accessBack')?.addEventListener('click', () => { view = state.onboarded ? 'home' : 'splash'; render(); });
  }

  // Keep the commercial status in the adult area. Child screens contain no price banners.
  adult = function () {
    previousAdult();
    const card = document.querySelector('.card.adult');
    if (!card || card.querySelector('#accessPanel')) return;
    const result = status(), copy = statusCopy(result), panel = document.createElement('section');
    panel.id = 'accessPanel'; panel.className = 'access-family-panel';
    panel.innerHTML = `<h2>Acesso e licença</h2><p>${escapeHtml(copy[0])}</p><p class="access-small">${escapeHtml(copy[1])}</p><button type="button" class="secondary" id="accessOpen">${result.allowed?'Gerenciar acesso':'Planos e assinatura'}</button>`;
    const profile = card.querySelector('.profile-settings');
    if (profile) profile.insertAdjacentElement('beforebegin', panel); else card.appendChild(panel);
    panel.querySelector('#accessOpen')?.addEventListener('click', openAccess);
  };
  render = function () {
    if (view === 'access') return renderAccess();
    if (protectedViews.has(view) && !status().allowed) {
      stopVoice(); view = 'access'; return renderAccess();
    }
    return previousRender();
  };
  function guard(fn) { return function () { if (!ensureAccess()) return; return fn.apply(this, arguments); }; }
  startWorld = guard(startWorld);
  startGuided = guard(startGuided);
  prepareWorld = guard(prepareWorld);
  openGuided = guard(openGuided);
  requestGate = guard(requestGate);
  answer = guard(answer);
  next = guard(next);
  recordTask = guard(recordTask);
  finishDiagnostic = guard(finishDiagnostic);
  gateEnd = guard(gateEnd);
  if (typeof RC43_recordSkill === 'function') RC43_recordSkill = guard(RC43_recordSkill);
  if (typeof RC47_recordEI === 'function') RC47_recordEI = guard(RC47_recordEI);
  if (typeof RC47_completeExperience === 'function') RC47_completeExperience = guard(RC47_completeExperience);
  if (typeof RC47_submitWriting === 'function') RC47_submitWriting = guard(RC47_submitWriting);
  if (typeof RC55_confirmSentence === 'function') RC55_confirmSentence = guard(RC55_confirmSentence);
  if (typeof RC56_recordAlphabetPractice === 'function') RC56_recordAlphabetPractice = guard(RC56_recordAlphabetPractice);

  // A trace completion handler mutates its attempt before calling recordTask. Capture
  // the action first, so an expired session cannot create even an in-memory completion.
  document.addEventListener('click', event => {
    if (!protectedViews.has(view)) return;
    const action = event.target?.closest?.('[data-ans],#next,#go,#gateGo,#diag,#begin,#rc47WriteSubmit,#rc47ExperienceDone,#rc47TraceDone,#rc55WritingConfirm,#rc56AlphabetOral');
    if (action && !ensureAccess()) { event.preventDefault(); event.stopImmediatePropagation(); }
  }, true);
  host.addEventListener('storage', event => {
    if (event.key !== accessKey && event.key !== installationKey && event.key !== null) return;
    verified = null; verifiedToken = ''; verificationEpoch++; pendingVerification = null; verifyingToken = '';
    status();
    if (view === 'access' || view === 'adult' || protectedViews.has(view)) render();
  });
  const style = document.createElement('style');
  style.textContent = '.access-card{max-width:740px;margin-inline:auto}.access-card h1{margin-top:4px}.access-card h2,.access-family-panel h2{font-size:20px;line-height:1.3}.access-card p{line-height:1.55}.access-kicker{font-size:12px;font-weight:850;letter-spacing:.07em;color:#226347}.access-status,.access-family-panel{background:#eff9f3;border:1px solid #b9dbc8;border-radius:18px;padding:18px;margin:18px 0}.access-offer,.access-activation{border-top:1px solid #dce6e1;padding-top:16px;margin-top:24px}.access-activation label{display:block;font-weight:800;margin:15px 0 7px}.access-activation textarea{box-sizing:border-box;width:100%;max-width:100%;padding:12px;border:2px solid #809c91;border-radius:12px;font:inherit;overflow-wrap:anywhere;resize:vertical}.access-activation input{box-sizing:border-box;width:100%;min-width:0;font-family:monospace;font-size:14px}.access-card .access-small,.access-family-panel .access-small{font-size:14px;line-height:1.5;color:#35544a}.access-actions{display:flex;gap:10px;flex-wrap:wrap}.access-actions button,.access-card button,.access-purchase{min-height:48px}.access-purchase{display:inline-flex;align-items:center;flex-wrap:wrap;gap:5px;text-decoration:none;box-sizing:border-box}.access-card button:disabled{opacity:.65;cursor:wait}#accessNotice{font-weight:750;color:#174f3c;min-height:24px}.access-card textarea:focus-visible,.access-card input:focus-visible,.access-card a:focus-visible{outline:3px solid #123d66;outline-offset:3px}@media(max-width:430px){.access-card{padding:18px}.access-card h1{font-size:27px}.access-actions>*{width:100%}.access-status,.access-family-panel{padding:14px}}';
  document.head.appendChild(style);
  initializeStorage();
  const api = Object.freeze({ open: openAccess, getStatus: status, startTrial, activateLicense, accessKey, installationKey });
  root.IntelectusAccessUI = api;
  host.IntelectusAccessUI = api;
  render();
}(typeof globalThis !== 'undefined' ? globalThis : this));


/* Intelectus Alfabetização — RC57: precisão BNCC + direção de arte. */
const RC57_VERSION=57;
const RC57_WORD_SVG={"BOLA":"<svg class=\"rc57-icon\" viewBox=\"0 0 120 100\" aria-hidden=\"true\"><circle cx=\"60\" cy=\"50\" r=\"35\" fill=\"#fff\" stroke=\"#1e5b91\" stroke-width=\"5\"/><path d=\"M60 22l13 10-5 16H52l-5-16z\" fill=\"#173b5e\"/><path d=\"M31 39l16-7M89 39l-16-7M38 72l14-18M82 72L68 54\" stroke=\"#173b5e\" stroke-width=\"5\" stroke-linecap=\"round\"/></svg>","SOL":"<svg class=\"rc57-icon\" viewBox=\"0 0 120 100\" aria-hidden=\"true\"><g stroke=\"#f4a900\" stroke-width=\"5\" stroke-linecap=\"round\"><path d=\"M60 8v14M60 78v14M18 50h14M88 50h14M30 20l10 10M80 70l10 10M90 20L80 30M40 70L30 80\"/></g><circle cx=\"60\" cy=\"50\" r=\"25\" fill=\"#ffd64d\" stroke=\"#f4a900\" stroke-width=\"4\"/></svg>","LUA":"<svg class=\"rc57-icon\" viewBox=\"0 0 120 100\" aria-hidden=\"true\"><path d=\"M77 17c-20 6-31 28-24 48 6 17 23 27 41 25-10 8-23 12-37 8-26-7-41-34-34-60C30 13 54-2 77 4c6 2 11 4 16 8-5 1-11 2-16 5z\" fill=\"#ffe27a\" stroke=\"#d8ad36\" stroke-width=\"4\"/></svg>","CASA":"<svg class=\"rc57-icon\" viewBox=\"0 0 120 100\" aria-hidden=\"true\"><path d=\"M20 48L60 16l40 32v38H20z\" fill=\"#fff0c9\" stroke=\"#173b5e\" stroke-width=\"4\"/><path d=\"M14 51L60 12l46 39\" fill=\"none\" stroke=\"#e76f51\" stroke-width=\"9\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/><rect x=\"50\" y=\"58\" width=\"20\" height=\"28\" rx=\"3\" fill=\"#9d5c3a\"/><rect x=\"27\" y=\"55\" width=\"15\" height=\"14\" rx=\"2\" fill=\"#78c9f5\"/></svg>","PIPA":"<svg class=\"rc57-icon\" viewBox=\"0 0 120 100\" aria-hidden=\"true\"><path d=\"M58 12L91 43 58 72 27 43z\" fill=\"#ff6b6b\" stroke=\"#173b5e\" stroke-width=\"4\"/><path d=\"M58 12v60M27 43h64\" stroke=\"#fff\" stroke-width=\"3\"/><path d=\"M58 72q10 9 0 16q-10 7 2 12\" fill=\"none\" stroke=\"#173b5e\" stroke-width=\"3\"/><path d=\"M55 83l-7 5 8 4M61 91l8 4-7 5\" fill=\"none\" stroke=\"#f2b632\" stroke-width=\"3\"/></svg>","MESA":"<svg class=\"rc57-icon\" viewBox=\"0 0 120 100\" aria-hidden=\"true\"><rect x=\"18\" y=\"35\" width=\"84\" height=\"18\" rx=\"6\" fill=\"#c98346\"/><rect x=\"26\" y=\"51\" width=\"10\" height=\"38\" rx=\"4\" fill=\"#7c482e\"/><rect x=\"84\" y=\"51\" width=\"10\" height=\"38\" rx=\"4\" fill=\"#7c482e\"/></svg>","TOMATE":"<svg class=\"rc57-icon\" viewBox=\"0 0 120 100\" aria-hidden=\"true\"><circle cx=\"60\" cy=\"56\" r=\"33\" fill=\"#ef4b45\" stroke=\"#b72f2b\" stroke-width=\"4\"/><path d=\"M60 20l8 15 16-6-10 13 15 6-19 2-10 14-5-16-18-2 15-8-8-12 16 7z\" fill=\"#2e9d4f\"/></svg>","NAVE":"<svg class=\"rc57-icon\" viewBox=\"0 0 120 100\" aria-hidden=\"true\"><path d=\"M60 10c18 17 25 35 23 56L60 83 37 66C35 45 42 27 60 10z\" fill=\"#eef4ff\" stroke=\"#173b5e\" stroke-width=\"4\"/><circle cx=\"60\" cy=\"42\" r=\"10\" fill=\"#77d4ff\" stroke=\"#173b5e\" stroke-width=\"3\"/><path d=\"M39 61L24 78l22-5M81 61l15 17-22-5\" fill=\"#ff6b6b\" stroke=\"#173b5e\" stroke-width=\"3\"/><path d=\"M52 82l8 14 8-14\" fill=\"#f4a900\"/></svg>","VELA":"<svg class=\"rc57-icon\" viewBox=\"0 0 120 100\" aria-hidden=\"true\"><rect x=\"48\" y=\"37\" width=\"24\" height=\"50\" rx=\"5\" fill=\"#fff2b5\" stroke=\"#d1a534\" stroke-width=\"3\"/><path d=\"M60 34c-12-9-1-20 4-27 8 11 9 21-4 27z\" fill=\"#ff8a34\" stroke=\"#d95e1b\" stroke-width=\"3\"/><path d=\"M60 37v50\" stroke=\"#efcf70\" stroke-width=\"3\"/></svg>","BULE":"<svg class=\"rc57-icon\" viewBox=\"0 0 120 100\" aria-hidden=\"true\"><ellipse cx=\"58\" cy=\"58\" rx=\"31\" ry=\"25\" fill=\"#63b7e6\" stroke=\"#173b5e\" stroke-width=\"4\"/><path d=\"M86 50q19 2 20 14q-11 8-22 3\" fill=\"none\" stroke=\"#173b5e\" stroke-width=\"5\"/><path d=\"M29 50q-18 5-18 18q7 9 18 1\" fill=\"none\" stroke=\"#173b5e\" stroke-width=\"5\"/><path d=\"M44 31h28M50 25h16\" stroke=\"#173b5e\" stroke-width=\"4\" stroke-linecap=\"round\"/></svg>","PENA":"<svg class=\"rc57-icon\" viewBox=\"0 0 120 100\" aria-hidden=\"true\"><path d=\"M87 15C45 14 25 46 31 80c22-9 44-24 56-65z\" fill=\"#e9f7ff\" stroke=\"#4c8ebd\" stroke-width=\"4\"/><path d=\"M34 83L84 20M48 65L31 61M57 54L41 48M66 43L53 35\" stroke=\"#4c8ebd\" stroke-width=\"3\" stroke-linecap=\"round\"/></svg>","NUVEM":"<svg class=\"rc57-icon\" viewBox=\"0 0 120 100\" aria-hidden=\"true\"><path d=\"M32 73h57c12 0 20-8 20-19 0-10-8-18-18-19-4-14-16-23-31-21-13 1-23 10-26 22-13 0-23 8-23 19 0 10 9 18 21 18z\" fill=\"#e9f4fb\" stroke=\"#7aa9c8\" stroke-width=\"4\"/></svg>","DADO":"<svg class=\"rc57-icon\" viewBox=\"0 0 120 100\" aria-hidden=\"true\"><rect x=\"27\" y=\"17\" width=\"66\" height=\"66\" rx=\"13\" fill=\"#fff\" stroke=\"#173b5e\" stroke-width=\"5\"/><g fill=\"#173b5e\"><circle cx=\"45\" cy=\"35\" r=\"5\"/><circle cx=\"75\" cy=\"35\" r=\"5\"/><circle cx=\"60\" cy=\"50\" r=\"5\"/><circle cx=\"45\" cy=\"65\" r=\"5\"/><circle cx=\"75\" cy=\"65\" r=\"5\"/></g></svg>","BANANA":"<svg class=\"rc57-icon\" viewBox=\"0 0 120 100\" aria-hidden=\"true\"><path d=\"M25 28c10 34 41 50 71 32-8 28-42 37-66 18C13 65 11 43 25 28z\" fill=\"#ffd84a\" stroke=\"#c79c19\" stroke-width=\"4\"/><path d=\"M24 28l-3-9M96 60l7-5\" stroke=\"#6d5320\" stroke-width=\"5\" stroke-linecap=\"round\"/></svg>","GATO":"<svg class=\"rc57-icon\" viewBox=\"0 0 120 100\" aria-hidden=\"true\"><path d=\"M34 31L24 10l24 12M86 31l10-21-24 12\" fill=\"#f0a35b\" stroke=\"#7a4c2b\" stroke-width=\"4\"/><circle cx=\"60\" cy=\"55\" r=\"34\" fill=\"#f0a35b\" stroke=\"#7a4c2b\" stroke-width=\"4\"/><circle cx=\"48\" cy=\"51\" r=\"4\" fill=\"#173b5e\"/><circle cx=\"72\" cy=\"51\" r=\"4\" fill=\"#173b5e\"/><path d=\"M56 62h8l-4 6z\" fill=\"#d76f77\"/><path d=\"M44 67q16 10 32 0M32 61H14M34 68H16M88 61h18M86 68h18\" fill=\"none\" stroke=\"#7a4c2b\" stroke-width=\"3\" stroke-linecap=\"round\"/></svg>","PATO":"<svg class=\"rc57-icon\" viewBox=\"0 0 120 100\" aria-hidden=\"true\"><ellipse cx=\"57\" cy=\"62\" rx=\"37\" ry=\"22\" fill=\"#ffd64d\" stroke=\"#b9871f\" stroke-width=\"4\"/><circle cx=\"78\" cy=\"39\" r=\"20\" fill=\"#ffd64d\" stroke=\"#b9871f\" stroke-width=\"4\"/><path d=\"M96 41l20 8-20 8z\" fill=\"#ff9b42\"/><circle cx=\"84\" cy=\"34\" r=\"3\" fill=\"#173b5e\"/><path d=\"M42 61q14-14 26 0q-13 12-26 0z\" fill=\"#f5bd2d\"/></svg>","SAPO":"<svg class=\"rc57-icon\" viewBox=\"0 0 120 100\" aria-hidden=\"true\"><ellipse cx=\"60\" cy=\"62\" rx=\"36\" ry=\"25\" fill=\"#64c76a\" stroke=\"#2f7c3a\" stroke-width=\"4\"/><circle cx=\"44\" cy=\"36\" r=\"14\" fill=\"#75d77a\" stroke=\"#2f7c3a\" stroke-width=\"4\"/><circle cx=\"76\" cy=\"36\" r=\"14\" fill=\"#75d77a\" stroke=\"#2f7c3a\" stroke-width=\"4\"/><circle cx=\"44\" cy=\"35\" r=\"4\" fill=\"#173b5e\"/><circle cx=\"76\" cy=\"35\" r=\"4\" fill=\"#173b5e\"/><path d=\"M48 66q12 8 24 0\" fill=\"none\" stroke=\"#2f7c3a\" stroke-width=\"4\" stroke-linecap=\"round\"/></svg>","MACACO":"<svg class=\"rc57-icon\" viewBox=\"0 0 120 100\" aria-hidden=\"true\"><circle cx=\"60\" cy=\"52\" r=\"34\" fill=\"#a86f45\" stroke=\"#6f442b\" stroke-width=\"4\"/><circle cx=\"29\" cy=\"50\" r=\"13\" fill=\"#a86f45\" stroke=\"#6f442b\" stroke-width=\"4\"/><circle cx=\"91\" cy=\"50\" r=\"13\" fill=\"#a86f45\" stroke=\"#6f442b\" stroke-width=\"4\"/><ellipse cx=\"60\" cy=\"61\" rx=\"23\" ry=\"19\" fill=\"#e6b982\"/><circle cx=\"49\" cy=\"47\" r=\"4\" fill=\"#173b5e\"/><circle cx=\"71\" cy=\"47\" r=\"4\" fill=\"#173b5e\"/><path d=\"M52 68q8 7 16 0\" fill=\"none\" stroke=\"#6f442b\" stroke-width=\"3\"/></svg>","VACA":"<svg class=\"rc57-icon\" viewBox=\"0 0 120 100\" aria-hidden=\"true\"><ellipse cx=\"60\" cy=\"55\" rx=\"36\" ry=\"29\" fill=\"#fff\" stroke=\"#173b5e\" stroke-width=\"4\"/><path d=\"M32 37L17 23v25M88 37l15-14v25\" fill=\"#fff\" stroke=\"#173b5e\" stroke-width=\"4\"/><path d=\"M39 36q13-15 21 2q9-14 20-1\" fill=\"#444\"/><ellipse cx=\"60\" cy=\"68\" rx=\"20\" ry=\"13\" fill=\"#f4b6bd\"/><circle cx=\"48\" cy=\"51\" r=\"4\" fill=\"#173b5e\"/><circle cx=\"72\" cy=\"51\" r=\"4\" fill=\"#173b5e\"/></svg>","GALO":"<svg class=\"rc57-icon\" viewBox=\"0 0 120 100\" aria-hidden=\"true\"><ellipse cx=\"57\" cy=\"60\" rx=\"30\" ry=\"25\" fill=\"#f3b34f\" stroke=\"#8d5c27\" stroke-width=\"4\"/><circle cx=\"78\" cy=\"42\" r=\"17\" fill=\"#f3b34f\" stroke=\"#8d5c27\" stroke-width=\"4\"/><path d=\"M93 43l20 7-18 9\" fill=\"#ff8a34\"/><path d=\"M72 24q5-18 12 0q7-15 12 2\" fill=\"#e8504f\"/><path d=\"M29 51q-16-16-20-2q8 18 24 23\" fill=\"#4a98d0\" stroke=\"#173b5e\" stroke-width=\"4\"/><circle cx=\"82\" cy=\"38\" r=\"3\" fill=\"#173b5e\"/></svg>","MOTO":"<svg class=\"rc57-icon\" viewBox=\"0 0 120 100\" aria-hidden=\"true\"><circle cx=\"33\" cy=\"70\" r=\"17\" fill=\"#eef4f8\" stroke=\"#173b5e\" stroke-width=\"5\"/><circle cx=\"89\" cy=\"70\" r=\"17\" fill=\"#eef4f8\" stroke=\"#173b5e\" stroke-width=\"5\"/><path d=\"M33 70l18-25h24l14 25M51 45l11 25H33M75 45l10-14M82 31h13\" fill=\"none\" stroke=\"#e74c3c\" stroke-width=\"6\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/></svg>","LOBO":"<svg class=\"rc57-icon\" viewBox=\"0 0 120 100\" aria-hidden=\"true\"><path d=\"M30 35L18 9l31 16M90 35l12-26-31 16\" fill=\"#8f9aa5\" stroke=\"#4d5963\" stroke-width=\"4\"/><path d=\"M60 20c25 0 40 19 35 43-4 21-19 31-35 31S29 84 25 63C20 39 35 20 60 20z\" fill=\"#8f9aa5\" stroke=\"#4d5963\" stroke-width=\"4\"/><circle cx=\"47\" cy=\"50\" r=\"4\" fill=\"#173b5e\"/><circle cx=\"73\" cy=\"50\" r=\"4\" fill=\"#173b5e\"/><path d=\"M55 62h10l-5 7z\" fill=\"#3e454b\"/><path d=\"M49 73q11 8 22 0\" fill=\"none\" stroke=\"#4d5963\" stroke-width=\"3\"/></svg>","MULA":"<svg class=\"rc57-icon\" viewBox=\"0 0 120 100\" aria-hidden=\"true\"><ellipse cx=\"55\" cy=\"60\" rx=\"35\" ry=\"22\" fill=\"#9b6b4c\" stroke=\"#65432f\" stroke-width=\"4\"/><path d=\"M80 55q6-26 18-20q12 6 4 28\" fill=\"#9b6b4c\" stroke=\"#65432f\" stroke-width=\"4\"/><path d=\"M91 37l-4-25q10 4 14 21M80 38l-9-23q10 1 15 20\" fill=\"#9b6b4c\" stroke=\"#65432f\" stroke-width=\"3\"/><circle cx=\"99\" cy=\"47\" r=\"3\" fill=\"#173b5e\"/><path d=\"M33 76l-3 17M67 77l3 16\" stroke=\"#65432f\" stroke-width=\"5\" stroke-linecap=\"round\"/></svg>","VOVÓ":"<svg class=\"rc57-icon\" viewBox=\"0 0 120 100\" aria-hidden=\"true\"><circle cx=\"60\" cy=\"54\" r=\"31\" fill=\"#f3c6a5\" stroke=\"#8a5c48\" stroke-width=\"3\"/><path d=\"M29 47q3-34 31-34q28 0 31 34q-12-14-31-13q-19-1-31 13z\" fill=\"#e9edf1\" stroke=\"#8a8f95\" stroke-width=\"4\"/><circle cx=\"48\" cy=\"53\" r=\"8\" fill=\"none\" stroke=\"#173b5e\" stroke-width=\"3\"/><circle cx=\"72\" cy=\"53\" r=\"8\" fill=\"none\" stroke=\"#173b5e\" stroke-width=\"3\"/><path d=\"M56 53h8M51 70q9 7 18 0\" stroke=\"#8a5c48\" stroke-width=\"3\" fill=\"none\" stroke-linecap=\"round\"/></svg>"};
const RC57_SCENE_MAP={"🐱💤":["GATO"],"🦆🌊":["PATO"],"👧⚽":["BOLA"],"☀️✨":["SOL"],"👵🕯️":["VOVÓ","VELA"],"🐸🌿":["SAPO"],"🐒🍌":["MACACO","BANANA"],"🐄🌱":["VACA"],"🌙🏠":["LUA","CASA"],"🪁🌤️":["PIPA"],"🐓🌅":["GALO","SOL"],"🏍️🛣️":["MOTO"],"🎲🪑":["DADO","MESA"],"🪁👧":["PIPA"],"🐺🌙":["LOBO","LUA"],"🍅🪑":["TOMATE","MESA"],"🚀🌙":["NAVE","LUA"],"🫖🪑":["BULE","MESA"],"🪶🌬️":["PENA"],"☁️🌙":["NUVEM","LUA"],"🐄🏠":["VACA","CASA"],"🕯️🪑":["VELA","MESA"],"🐴🌱":["MULA"]};
WORLD_IMG.sounds="/assets/caf325e6ca4f98e080003fb014a0f63e706d36b8a78866102865479757275a44.png";
const RC57_PREV_WORDPIC=wordPic;
wordPic=function(value,fallback){const key=RC57_WORD_SVG[String(value||'').toUpperCase()];return key||RC57_PREV_WORDPIC(value,fallback)};
const RC57_PREV_STIMULUS=stimulus;
function RC57_sceneArt(scene){const words=RC57_SCENE_MAP[String(scene||'')];if(!words)return null;return '<div class="rc57-scene" role="img" aria-label="Cena ilustrada">'+words.map(w=>RC57_WORD_SVG[w]||'').join('')+'</div>';}
stimulus=function(task){const s=task?.stimulus;if(s?.type==='direction')return '<div class="stimulus"><div class="rc57-direction" role="img" aria-label="Leitura da esquerda para a direita e de cima para baixo"><div class="line"><span class="arrow">→</span><span>O GATO DORME.</span></div><div class="down">↓</div><div class="line"><span class="arrow">→</span><span>A LUA BRILHA.</span></div></div></div>';if(s?.type==='scene'){const art=RC57_sceneArt(s.text);if(art)return '<div class="stimulus">'+art+'</div>';}return RC57_PREV_STIMULUS(task);};
function RC57_makeDirectionTask(){return uniqueTask(()=>({world:'sentences',skill:'reading:directionality',key:'direction:left-right-top-bottom',sig:'rc57-direction:'+Math.random(),command:'Como seguimos a leitura destas duas linhas?',audio:[],kind:'sentence',stimulus:{type:'direction'},options:shuffle(['Da esquerda para a direita e depois para a linha de baixo.','Da direita para a esquerda e depois para a linha de cima.','Começamos pelo final e voltamos para o início.']),answer:'Da esquerda para a direita e depois para a linha de baixo.'}));}
const RC57_CURSIVE_MODELS=['casa','bola','gato','pipa','o gato dorme','a pipa voa'];
function RC57_makeCursiveCopyTask(){const text=pick(RC57_CURSIVE_MODELS);return{world:text.includes(' ')?'sentences':'words',skill:'writing:cursive-copy',key:'cursive-copy:'+text,sig:'rc57-cursive-copy:'+text+':'+Math.random(),command:text.includes(' ')?'Copie a frase em letra cursiva no espaço abaixo.':'Copie a palavra em letra cursiva no espaço abaixo.',audio:[],kind:'trace',traceLetter:text,cursiveCopy:true,stimulus:null,options:[],answer:'TRACE'};}
const RC57_PREV_MAKE_TASK=makeTask;
makeTask=function(i){if(i===5&&state.grade==='1º Ano'&&Math.random()<.16)return RC57_makeDirectionTask();if(state.grade==='2º Ano'&&(i===4||i===5)&&Math.random()<.16)return RC57_makeCursiveCopyTask();return RC57_PREV_MAKE_TASK(i);};
const RC57_PREV_WEAK=RC43_taskForWeakSkill;
RC43_taskForWeakSkill=function(i,id){if(state.grade==='1º Ano'&&i===5&&id==='reading:directionality')return RC57_makeDirectionTask();if(state.grade==='2º Ano'&&(i===4||i===5)&&id==='writing:cursive-copy')return RC57_makeCursiveCopyTask();return RC57_PREV_WEAK(i,id);};
const RC57_PREV_CODES=RC56_worldCodes;
RC56_worldCodes=function(i,grade=state.grade){let codes=[...RC57_PREV_CODES(i,grade)];if(grade==='1º Ano'&&i===5)codes.push('EF01LP01');if(grade==='2º Ano'&&(i===4||i===5))codes.push('EF02LP07');return[...new Set(codes)];};
const RC57_PREV_ACTIVITY=activity;
activity=function(isDiag){RC57_PREV_ACTIVITY(isDiag);if(isDiag||!current)return;const card=document.querySelector('.card.lesson');if(!card)return;if(current.cursiveCopy){card.classList.add('rc57-cursive-copy');const wrap=card.querySelector('.rc47-trace-wrap');if(wrap&&!card.querySelector('.rc57-copy-model')){const model=document.createElement('div');model.className='rc57-copy-model rc47-cursive';model.textContent=current.traceLetter;wrap.insertAdjacentElement('beforebegin',model);}const note=card.querySelector('#rc47TraceNote');if(note)note.textContent='Observe o modelo e escreva em cursiva no espaço. A atividade registra prática acompanhada; o aplicativo não atribui nota à caligrafia.';const done=card.querySelector('#rc47TraceDone');if(done)done.textContent='Terminei minha escrita cursiva';}}
const RC57_PREV_ADULT=adult;
adult=function(){RC57_PREV_ADULT();const card=document.querySelector('.card.adult');if(!card)return;const trace=card.querySelector('.rc47-bncc-trace');if(trace&&!trace.querySelector('.rc57-note')){const p=document.createElement('p');p.className='rc57-note';p.textContent=state.grade==='1º Ano'?'EF01LP01 é apoiada por atividade explícita de direção convencional da leitura: esquerda para direita e passagem para a linha de baixo.':state.grade==='2º Ano'?'EF02LP07 inclui prática de escrita cursiva de palavras e frases em superfície de desenho, sem falsa correção automática da caligrafia.':'As experiências da Educação Infantil continuam separadas das habilidades formais do Ensino Fundamental.';trace.appendChild(p);}};
// Retira emojis instrucionais das experiências visuais; as cenas continuam acessíveis por descrição e ilustração.
if(typeof RC50_EI_VISUAL_SEQUENCES!=='undefined')RC50_EI_VISUAL_SEQUENCES.forEach(x=>x.command='Observe a sequência. O que vem depois?');
if(typeof RC50_EI_VISUAL_INFERENCES!=='undefined')RC50_EI_VISUAL_INFERENCES.forEach(x=>x.command='Observe a cena e escolha a imagem que faz mais sentido.');
window.RC57_AUDIT={version:RC57_VERSION,directionality:true,cursiveWordSentencePractice:true,aiWallpaper:true,cartoonTeacher:true,semanticVectorArt:Object.keys(RC57_WORD_SVG).length};
render();



/* ===== rc58-characters-sound ===== */

(()=>{
const RC58_VERSION='RC58';
const RC58_AVATARS=[
 {id:'aventureira',name:'Aventureira',src:'/assets/4cc6d5349a31673e8aa0cecc467a5565926d2cf35c59a584b9f2d118341d3898.webp',desc:'curiosa e destemida'},
 {id:'aventureiro',name:'Aventureiro',src:'/assets/e56438f2cbeb96ad6f420996100e797fb71410b58be36e6c7bc74fa306c76d68.webp',desc:'animado e explorador'},
 {id:'coruja',name:'Coruja Leitora',src:'/assets/3f61e0f6d7dd38d5992ce0c3ea208051688350c7bba27d9bd306ba2f96aaa1f0.webp',desc:'amiga dos livros'},
 {id:'panda',name:'Panda Amigo',src:'/assets/68a6c32514e807f81e9b2c7da39675d9f7f7410533379e91c982b95c70bd67e9.webp',desc:'fofo e companheiro'},
 {id:'leao',name:'Leão Corajoso',src:'/assets/b245cb967f927fd6f181a71523af76a1035cb209cda7d07d8d31382b8a767b54.webp',desc:'valente e sorridente'},
 {id:'raposa',name:'Raposa Esperta',src:'/assets/a1f8426627b762438cc177bf24fbb42b2715299ee3e2f3e48e7476919086edfe.webp',desc:'curiosa e atenta'},
 {id:'coelha',name:'Coelha Feliz',src:'/assets/f5f84fcbdc740ea06ff67c76eed7a22401b9e4b84460e3686393a69b53ac7b36.webp',desc:'alegre e gentil'},
 {id:'astronauta',name:'Mini Astronauta',src:'/assets/6e6daf5a7d9ddf80af34b593a37643bdcdfb5c0a938194ffb98847aac6ba7e49.webp',desc:'pronto para descobrir'}
];
const RC58_GUIDES=[
 {id:'lia',name:'Lia',title:'Profª',src:'/assets/e16a2f228739d95a46bfa4b2c38c8e9d835110c86ee507ee619ed849aa87575a.webp',desc:'acolhedora e carinhosa'},
 {id:'aline',name:'Aline',title:'Profª',src:'/assets/337601c336eb9d4fbc20fad41d61bf6f0c6b4a0ca7602615ff686359b430335d.webp',desc:'criativa e incentivadora'},
 {id:'daniel',name:'Daniel',title:'Prof.',src:'/assets/3dae29ff5bf3d8f330785c37d708eca7828e6a2f4eeaac7a34b584f0e3d2147b.webp',desc:'curioso e encorajador'},
 {id:'caio',name:'Caio',title:'Prof.',src:'/assets/d6d877feeb2b1d54eddde3e4f36665bf5481eee24a94472b8fedce0fc6b5c82b.webp',desc:'divertido e parceiro'}
];
window.RC58_AVATARS=RC58_AVATARS;window.RC58_GUIDES=RC58_GUIDES;
const avatarLegacy={'🦊':'raposa','🐼':'panda','🦁':'leao','🐰':'coelha','🐯':'aventureiro','🐨':'aventureira','🦄':'coruja','🐸':'astronauta'};
function avatar(){return RC58_AVATARS.find(x=>x.id===state.avatarId)||RC58_AVATARS[5]}
function guide(){return RC58_GUIDES.find(x=>x.id===state.guideId)||RC58_GUIDES[0]}
function migrate(){let changed=false;if(!state.avatarId){state.avatarId=avatarLegacy[state.avatar]||'raposa';changed=true}if(!state.guideId){const g=String(state.guide||'').toLowerCase();state.guideId=RC58_GUIDES.find(x=>x.name.toLowerCase()===g)?.id||'lia';changed=true}if(!state.guide||state.guide==='Professora'){state.guide=guide().name;changed=true}if(changed)safeSave()}
function card(item,kind,selected){return `<button type="button" class="rc58-character-card ${selected?'sel':''}" data-${kind}="${item.id}" aria-pressed="${selected?'true':'false'}"><img src="${item.src}" alt=""><b>${kind==='guide'?item.title+' ':''}${escapeHtml(item.name)}</b><small>${escapeHtml(item.desc)}</small></button>`}
function avatarMarkup(){const a=avatar();return `<img class="rc58-avatar-img" src="${a.src}" alt="Avatar ${escapeHtml(a.name)}">`}
function syncGuide(){const g=guide();state.guide=g.name;safeSave()}

// Music remains cheerful on navigation screens and becomes unobtrusive during pedagogy.
let RC58_musicFactor=1;
musicBase=function(){return .16*(musicLevel/100)*RC58_musicFactor};
function applyMusicPolicy(){const lessonLike=view==='lesson'||view==='diagnostic';const reading=current?.world==='comprehension'||current?.world==='sounds'||current?.world==='graphemes'||current?.world==='words';RC58_musicFactor=lessonLike?(reading ? .16 : .28):(view==='micro' ? .48 : 1);if(musicAudio&&musicOn)musicAudio.volume=musicBase()}

// Five-step onboarding: profile, stage, avatar, guide, sound.
onboarding=function(){
 setTop(false);migrate();
 const idx={onboardName:0,onboardGrade:1,onboardAvatar:2,onboardGuide:3,onboardSound:4}[view]??0;let body='';
 if(view==='onboardName')body=`<h1>Como podemos chamar a criança?</h1><p>Esse nome aparece apenas neste aparelho.</p><input id="name" aria-label="Nome da criança" class="big-input" maxlength="20" value="${escapeHtml(state.name||'')}"><button class="primary-xl" id="next">Continuar</button>`;
 if(view==='onboardGrade')body=`<h1>Em que etapa ela está?</h1><p>Isso ajuda a começar no ritmo certo, com desafios adequados à etapa da criança.</p><div class="grid" id="grades">${GRADES.map(g=>`<button class="secondary" data-grade="${g}" ${state.grade===g?'style="border-color:#19b957"':''}>${g}</button>`).join('')}</div><button class="primary-xl" id="next">Continuar</button>`;
 if(view==='onboardAvatar')body=`<h1>Escolha um personagem</h1><p>A criança pode ser quem quiser nesta aventura.</p><div class="rc58-choice-grid">${RC58_AVATARS.map(x=>card(x,'avatar',state.avatarId===x.id)).join('')}</div><button class="primary-xl" id="next">Continuar</button>`;
 if(view==='onboardGuide')body=`<h1>Escolha quem vai acompanhar a aventura</h1><p>Quatro guias pedagógicos, com diversidade de gênero e representação racial. A escolha é visual; a narração das atividades permanece a mesma.</p><div class="rc58-choice-grid rc58-guide-grid">${RC58_GUIDES.map(x=>card(x,'guide',state.guideId===x.id)).join('')}</div><button class="primary-xl" id="next">Continuar</button>`;
 if(view==='onboardSound')body=`<h1>Som da aventura</h1><p>Uma trilha mais alegre acompanha os momentos de exploração e baixa automaticamente nas atividades de escuta e leitura.</p><div class="rc58-sound-card"><button type="button" class="rc58-toggle" id="musicToggle" aria-pressed="${musicOn?'true':'false'}">${musicOn?'♫ Música ligada':'♩ Música desligada'}</button><div class="rc58-sound-row"><label for="musicSetup">Música</label><input id="musicSetup" type="range" min="0" max="100" step="5" value="${musicLevel}"><output id="musicSetupOut">${musicLevel}%</output></div><div class="rc58-sound-row"><label for="voiceSetup">Voz das atividades</label><input id="voiceSetup" type="range" min="0" max="100" step="5" value="${voiceLevel}"><output id="voiceSetupOut">${voiceLevel}%</output></div><p class="rc58-sound-note">A música não compete com ditados, consciência fonológica ou leitura: o volume é reduzido automaticamente nesses momentos.</p></div><button class="primary-xl" id="next">Começar minha aventura</button>`;
 $('#view').innerHTML=`<section class="view"><div class="onboarding card"><div class="steps">${[0,1,2,3,4].map(i=>`<i class="${i<=idx?'on':''}"></i>`).join('')}</div>${body}${footer()}</div></section>`;
 if(view==='onboardName')$('#next').onclick=()=>{state.name=$('#name').value.trim()||'Criança';view='onboardGrade';render()};
 if(view==='onboardGrade'){$$('[data-grade]').forEach(b=>b.onclick=()=>{state.grade=b.dataset.grade;render()});$('#next').onclick=()=>{view='onboardAvatar';render()}};
 if(view==='onboardAvatar'){$$('[data-avatar]').forEach(b=>b.onclick=()=>{state.avatarId=b.dataset.avatar;safeSave();render()});$('#next').onclick=()=>{view='onboardGuide';render()}};
 if(view==='onboardGuide'){$$('[data-guide]').forEach(b=>b.onclick=()=>{state.guideId=b.dataset.guide;syncGuide();render()});$('#next').onclick=()=>{syncGuide();view='onboardSound';render()}};
 if(view==='onboardSound'){$('#musicToggle').onclick=()=>{toggleMusic();render()};$('#musicSetup').oninput=e=>{setMusicLevel(e.target.value);$('#musicSetupOut').textContent=musicLevel+'%';if(musicOn&&musicLevel>0)startMusic()};$('#voiceSetup').oninput=e=>{setVoiceLevel(e.target.value);$('#voiceSetupOut').textContent=voiceLevel+'%'};$('#next').onclick=()=>{syncGuide();state.diagnosticVersion=3;state.onboarded=true;safeSave();view='diagnosticIntro';render()}};
};

home=function(){migrate();setTop(true);const n=nextWorldIndex(),w=worlds[n],g=guide();$('#view').innerHTML=`<section class="view home-view"><div class="hero"><div class="avatar-big">${avatarMarkup()}</div><div><h1>Oi, ${escapeHtml(state.name||'Criança')}!</h1><p>${g.title} ${escapeHtml(g.name)} está com você nessa aventura.</p></div></div><div class="mission"><img class="teacher-mini" src="${g.src}" alt="${g.title} ${escapeHtml(g.name)}, guia da aventura"><div class="mission-copy"><span class="kicker">MISSÃO COM ${escapeHtml(g.name).toUpperCase()}</span><b>${w.name}</b><p>Vamos aprender brincando!</p></div><button class="primary mission-play" id="guided" aria-label="Jogar missão ${escapeHtml(w.name)}"><span class="play-mark">▶</span> Jogar</button></div><div class="section-title"><h2>Trilha de aprendizagem</h2></div><div class="world-grid">${worlds.map((x,i)=>worldCard(x,i,n)).join('')}</div>${footer()}</section>`;$('#guided').onclick=()=>openGuided();$$('[data-world]').forEach(b=>{b.onclick=()=>prepareWorld(Number(b.dataset.world));b.onkeydown=e=>{if(e.key==='Enter'||e.key===' '){e.preventDefault();prepareWorld(Number(b.dataset.world))}}});$$('[data-skip]').forEach(b=>b.onclick=e=>{e.stopPropagation();requestGate(Number(b.dataset.skip))})};

const baseAdult=adult;
adult=function(){baseAdult();migrate();const g=guide();const family=$('.family-teacher');if(family){const img=family.querySelector('img');if(img){img.src=g.src;img.alt=`${g.title} ${g.name}, guia da aventura`};const span=family.querySelector('span');if(span)span.textContent='GUIA DA AVENTURA';const b=family.querySelector('b');if(b)b.textContent=`${g.title} ${g.name}`;const sm=family.querySelector('small');if(sm)sm.textContent='A criança pode trocar o avatar e o guia sem apagar nenhum progresso.'}
 const settings=$('.profile-settings');if(settings){const extra=document.createElement('div');extra.className='rc58-profile-personalize';extra.innerHTML=`<h2>Personagens da aventura</h2><p>Trocar esses personagens muda apenas a experiência visual. O progresso pedagógico permanece intacto.</p><h3>Avatar da criança</h3><div class="rc58-choice-grid">${RC58_AVATARS.map(x=>card(x,'adult-avatar',state.avatarId===x.id)).join('')}</div><h3>Guia pedagógico</h3><div class="rc58-choice-grid rc58-guide-grid">${RC58_GUIDES.map(x=>card(x,'adult-guide',state.guideId===x.id)).join('')}</div>`;settings.after(extra);$$('[data-adult-avatar]').forEach(b=>b.onclick=()=>{state.avatarId=b.dataset.adultAvatar;safeSave();adult()});$$('[data-adult-guide]').forEach(b=>b.onclick=()=>{state.guideId=b.dataset.adultGuide;syncGuide();adult()})}
 const guideInput=$('#profileGuide');if(guideInput){guideInput.value=g.name;guideInput.readOnly=true;guideInput.setAttribute('aria-readonly','true');const lab=guideInput.closest('label');if(lab&&lab.firstChild)lab.firstChild.textContent='Guia selecionado'}
 const soundText=$('.sound-settings>p');if(soundText)soundText.textContent='A nova trilha musical fica mais presente na exploração e baixa automaticamente nas atividades pedagógicas.';const voiceLabel=$('label[for="voiceVol"]');if(voiceLabel)voiceLabel.textContent='Voz das atividades';
};

function applyCharacters(){migrate();const g=guide();const hero=$('.avatar-big');if(hero&&view==='home')hero.innerHTML=avatarMarkup();$$('.teacher-mini,.teacher-feedback-photo,.family-teacher img').forEach(img=>{img.src=g.src;img.alt=`${g.title} ${g.name}, guia da aventura`})}
const baseRender=render;render=function(){const out=baseRender();applyCharacters();applyMusicPolicy();return out};

migrate();applyMusicPolicy();
window.RC58_applyMusicPolicy=applyMusicPolicy;
window.RC58_AUDIT={version:RC58_VERSION,avatars:RC58_AVATARS.length,guides:RC58_GUIDES.length,music:MUSIC,contextDucking:true};
// Re-render once so restored profiles immediately receive the selected artwork.
render();
})();


/* ===== rc59-pedagogical-system ===== */

(()=>{
'use strict';
const RC59_VERSION=59;
state.rcPedagogicalVersion=RC59_VERSION;
state.rc59=state.rc59&&typeof state.rc59==='object'?state.rc59:{};
state.rc59.mode=state.rc59.mode||'guided';
state.rc59.dailyMinutes=Number(state.rc59.dailyMinutes)||15;
state.rc59.daysPerWeek=Number(state.rc59.daysPerWeek)||4;
state.rc59.challenge=state.rc59.challenge||{};state.rc59.bonus=state.rc59.bonus||{};state.rc59.adult=state.rc59.adult||{};state.rc59.meta=state.rc59.meta||{};
safeSave();

const S=(id,label,world,source,opts={})=>({id,label,world,source,bncc:opts.bncc||[],desc:opts.desc||'',adult:opts.adult||'',minutes:opts.minutes||75,attempts:opts.attempts||5,rate:opts.rate||.80});
const RC59_CURRICULUM={
'Pré-escola':[
 S('ei-rhyme','Perceber rimas e semelhanças sonoras',1,'phonology:rhyme',{bncc:['EI03EF02'],desc:'Brincar com sons que terminam de forma parecida.'}),
 S('ei-initial','Perceber sons iniciais das palavras',1,'phonology:initial',{bncc:['EI03EF02'],desc:'Comparar como as palavras começam.'}),
 S('ei-syl-first','Perceber o primeiro pedaço da palavra',3,'syllable:first',{bncc:['EI03EF02']}),
 S('ei-syl-last','Perceber o último pedaço da palavra',3,'syllable:last',{bncc:['EI03EF02']}),
 S('ei-syl-count','Contar oralmente os pedaços das palavras',3,'syllable:count',{bncc:['EI03EF02']}),
 S('ei-letters','Explorar letras e diferentes formas gráficas',0,'letters-ei',{bncc:['EI03EF09'],attempts:6,desc:'Contato lúdico com letras, sem antecipar exigências formais do 1º ano.'}),
 S('ei-sequence','Organizar acontecimentos em sequência',5,'ei:visual-sequence',{bncc:['EI03EF04']}),
 S('ei-inference','Usar pistas visuais para construir sentidos',6,'ei:visual-inference',{bncc:['EI03EF03']}),
 S('ei-expression','Expressar ideias oralmente',5,'adult',{bncc:['EI03EF01'],adult:'Conte para um adulto algo que aconteceu hoje usando começo, meio e fim.',minutes:45}),
 S('ei-recount','Recontar uma história ouvida',6,'adult',{bncc:['EI03EF04'],adult:'Ouça uma história curta e reconte para um adulto o que aconteceu.',minutes:60}),
 S('ei-emergent-writing','Experimentar escrita espontânea',4,'adult',{bncc:['EI03EF09'],adult:'Faça um desenho e tente escrever, do seu jeito, uma palavra que combine com ele.',minutes:60}),
 S('ei-books','Explorar livros, títulos e imagens',6,'adult',{bncc:['EI03EF03'],adult:'Escolha um livro com um adulto, observe capa e imagens e diga sobre o que você acha que ele fala.',minutes:45})
],
'1º Ano':[
 S('ef1-direction','Seguir a direção convencional da leitura',5,'reading:directionality',{bncc:['EF01LP01'],attempts:3}),
 S('ef1-letters','Reconhecer as 26 letras em maiúsculas e minúsculas',0,'letters-all',{bncc:['EF01LP04','EF01LP10','EF01LP11'],attempts:10,minutes:180}),
 S('ef1-order','Usar a ordem alfabética',0,'letters:alphabet-order',{bncc:['EF01LP10'],attempts:4}),
 S('ef1-rhyme','Reconhecer rimas',1,'phonology:rhyme',{bncc:['EF01LP13'],attempts:4}),
 S('ef1-initial','Identificar e comparar sons iniciais',1,'phonology:initial',{bncc:['EF01LP07','EF01LP09'],attempts:6}),
 S('ef1-final','Identificar e comparar sons finais',1,'phonology:final',{bncc:['EF01LP09','EF01LP13'],attempts:4}),
 S('ef1-grapheme','Relacionar sons e grafemas',2,'grapheme-world',{bncc:['EF01LP05','EF01LP07','EF01LP08'],attempts:8,minutes:150}),
 S('ef1-first-syl','Identificar sílaba inicial',3,'syllable:first',{bncc:['EF01LP06'],attempts:4}),
 S('ef1-last-syl','Identificar sílaba final',3,'syllable:last',{bncc:['EF01LP06'],attempts:4}),
 S('ef1-count-syl','Segmentar e contar sílabas',3,'syllable:count',{bncc:['EF01LP06'],attempts:4}),
 S('ef1-join-syl','Juntar sílabas para formar palavras',3,'syllable:join',{bncc:['EF01LP08'],attempts:4}),
 S('ef1-middle-syl','Perceber sílaba medial',3,'syllable:middle',{bncc:['EF01LP08','EF01LP09','EF01LP13'],attempts:4}),
 S('ef1-manip-syl','Retirar e manipular sílabas',3,'syllable:manipulation',{bncc:['EF01LP08'],attempts:4}),
 S('ef1-word-read','Ler palavras progressivamente',4,'word-world',{bncc:['EF12LP01'],attempts:8,minutes:150}),
 S('ef1-word-write','Escrever palavras com apoio fonológico',4,'word:productive-writing',{bncc:['EF01LP02'],attempts:5}),
 S('ef1-sentence-read','Ler frases curtas',5,'sentence:reading',{bncc:['EF12LP01'],attempts:5}),
 S('ef1-sentence-write','Produzir frases com sentido',5,'sentence:productive-writing',{bncc:['EF01LP02'],attempts:4}),
 S('ef1-spacing','Reconhecer espaços entre as palavras',5,'sentence:spacing',{bncc:['EF01LP12'],attempts:4,desc:'Perceber que as palavras são separadas por espaços na escrita.'}),
 S('ef1-punctuation','Reconhecer ponto final, interrogação e exclamação',5,'sentence:punctuation',{bncc:['EF01LP14'],attempts:4,desc:'Relacionar os sinais à leitura e à entonação.'}),
 S('ef1-synant','Relacionar palavras de sentido parecido e contrário',4,'vocab:synant1',{bncc:['EF01LP15'],attempts:4,desc:'Ampliar vocabulário com sinônimos e antônimos.'}),
 S('ef1-literal','Localizar informação explícita',6,'comprehension:literal',{bncc:['EF15LP03'],attempts:5}),
 S('ef1-infer','Construir inferências simples',6,'comprehension:inferential',{bncc:['EF15LP02'],attempts:5}),
 S('ef1-oral-read','Ler oralmente para um adulto',6,'adult',{bncc:['EF12LP01'],adult:'Leia em voz alta três frases ou um pequeno texto. O adulto observa precisão, pausas e autonomia.',minutes:75}),
 S('ef1-recount','Recontar o que leu ou ouviu',6,'adult',{bncc:['EF15LP19'],adult:'Depois de uma história curta, reconte oralmente os fatos principais sem olhar o texto.',minutes:60}),
 S('ef1-handwrite','Registrar palavras à mão',4,'adult',{bncc:['EF01LP03'],adult:'Escreva à mão cinco palavras praticadas no aplicativo. Um adulto confere legibilidade e correspondência sonora.',minutes:60})
],
'2º Ano':[
 S('ef2-review-letters','Revisar alfabeto e formas das letras',0,'letters-all',{bncc:['EF12LP01'],attempts:8,minutes:120,desc:'Revisão de pré-requisitos para leitura e escrita.'}),
 S('ef2-order','Usar ordem alfabética com segurança',0,'letters:alphabet-order',{bncc:['EF01LP10'],attempts:5,desc:'Pré-requisito do 1º ano retomado funcionalmente no 2º ano; não é apresentado como habilidade nova do 2º ano.'}),
 S('ef2-acrophonic','Relacionar o nome da letra ao som inicial',0,'letters:acrophonic',{bncc:['EF02LP06'],attempts:5,desc:'Perceber o princípio acrofônico presente nos nomes das letras.'}),
 S('ef2-cursive','Reconhecer e produzir escrita cursiva',0,'writing:cursive-copy',{bncc:['EF02LP07'],attempts:5}),
 S('ef2-final','Comparar sons finais',1,'phonology:final',{bncc:['EF02LP02'],attempts:4,desc:'Revisão de consciência silábica para manipulação de palavras.'}),
 S('ef2-grapheme','Consolidar relações fonema-grafema',2,'grapheme-world',{bncc:['EF02LP03'],attempts:7}),
 S('ef2-context','Aplicar regularidades ortográficas contextuais',2,'grapheme:contextual',{bncc:['EF02LP03'],attempts:5}),
 S('ef2-extended','Ampliar repertório ortográfico',2,'grapheme:extended',{bncc:['EF02LP03'],attempts:5}),
 S('ef2-nasal','Reconhecer e escrever marcas de nasalidade',2,'grapheme:nasal',{bncc:['EF02LP05'],attempts:5}),
 S('ef2-middle','Identificar sílaba medial',3,'syllable:middle',{bncc:['EF02LP02'],attempts:4}),
 S('ef2-manip','Manipular sílabas',3,'syllable:manipulation',{bncc:['EF02LP02'],attempts:4}),
 S('ef2-replace-i','Substituir sílaba inicial',3,'syllable:replace:initial',{bncc:['EF02LP02'],attempts:3}),
 S('ef2-replace-m','Substituir sílaba medial',3,'syllable:replace:medial',{bncc:['EF02LP02'],attempts:3}),
 S('ef2-replace-f','Substituir sílaba final',3,'syllable:replace:final',{bncc:['EF02LP02'],attempts:3}),
 S('ef2-pattern-v','Reconhecer padrão silábico V',3,'syllable:pattern:V',{bncc:['EF02LP04'],attempts:3}),
 S('ef2-pattern-cvc','Reconhecer padrão silábico CVC',3,'syllable:pattern:CVC',{bncc:['EF02LP04'],attempts:3}),
 S('ef2-pattern-ccv','Reconhecer padrão silábico CCV',3,'syllable:pattern:CCV',{bncc:['EF02LP04'],attempts:3}),
 S('ef2-word-read','Ler palavras com estruturas variadas',4,'word-world',{bncc:['EF02LP04'],attempts:8}),
 S('ef2-word-write','Escrever palavras de forma produtiva',4,'word:productive-writing',{bncc:['EF02LP07'],attempts:6}),
 S('ef2-sentence-read','Ler frases e pequenos enunciados',5,'sentence:reading',{bncc:['EF12LP01'],attempts:6}),
 S('ef2-sentence-write','Produzir frases completas',5,'sentence:productive-writing',{bncc:['EF02LP07'],attempts:5}),
 S('ef2-conventions','Aplicar convenções básicas ao escrever frases',5,'sentence:conventions',{bncc:['EF02LP01'],attempts:5,desc:'Grafia conhecida, maiúscula inicial, segmentação e pontuação.'}),
 S('ef2-spacing','Segmentar corretamente as palavras na frase',5,'sentence:spacing',{bncc:['EF02LP08'],attempts:5}),
 S('ef2-punctuation','Usar pontuação básica',5,'sentence:punctuation',{bncc:['EF02LP09'],attempts:5}),
 S('ef2-synant','Trabalhar sinônimos e antônimos com in-/im-',4,'vocab:synant2',{bncc:['EF02LP10'],attempts:5}),
 S('ef2-sizewords','Formar aumentativos e diminutivos',4,'word:morph-size',{bncc:['EF02LP11'],attempts:5}),
 S('ef2-literal','Localizar informações explícitas em textos',6,'comprehension:literal',{bncc:['EF15LP03'],attempts:6}),
 S('ef2-infer','Inferir informações a partir de pistas',6,'comprehension:inferential',{bncc:['EF15LP02'],attempts:6}),
 S('ef2-fluency','Ler texto curto com fluência crescente',6,'adult',{bncc:['EF12LP01'],adult:'Leia um texto curto em voz alta para um adulto. Observe precisão, continuidade, pausas e autocorreções.',minutes:90}),
 S('ef2-recount','Recontar e organizar fatos principais',6,'adult',{bncc:['EF15LP19'],adult:'Reconte uma narrativa curta destacando começo, problema, acontecimentos e final.',minutes:75}),
 S('ef2-text-write','Produzir pequeno texto com apoio',5,'adult',{bncc:['EF02LP01','EF02LP07'],adult:'Escreva à mão ou digite um pequeno texto de 3 a 5 frases sobre uma cena, experiência ou história. Um adulto revisa sentido, segmentação e legibilidade.',minutes:120})
]};
window.RC59_CURRICULUM=RC59_CURRICULUM;
function C(){return RC59_CURRICULUM[state.grade]||RC59_CURRICULUM['1º Ano']}
function entryRows(source){return Object.entries(state.skillLedger||{}).filter(([k])=>k===source||k.startsWith(source+':')||k.startsWith(source))}
function agg(source){const rows=entryRows(source);let attempts=0,points=0,last=0;rows.forEach(([,v])=>{attempts+=Number(v.attempts||0);points+=Number(v.points||0);last=Math.max(last,Number(v.last||0))});return{attempts,points,rate:attempts?points/attempts:0,last}}
function skillProgress(sk){
 if(state.rc59.challenge[sk.id])return{pct:100,state:'mastered',label:'Dominada',ready:true,mastered:true};
 if(sk.source==='adult'){const a=state.rc59.adult[sk.id]||{};if(a.alone>=2)return{pct:100,state:'mastered',label:'Dominada',ready:true,mastered:true};if((a.alone||0)+(a.help||0)>0)return{pct:65,state:'learning',label:'Consolidando',ready:false,mastered:false};return{pct:0,state:'',label:'Não iniciada',ready:false,mastered:false}}
 if(sk.source==='letters-all'){const x=typeof RC43_letterCoverage==='function'?RC43_letterCoverage():{ratio:0,pass:false};const pct=Math.round(Math.min(1,x.ratio||0)*100);return{pct,state:x.pass?'ready':pct?'learning':'',label:x.pass?'Pronta para desafio':pct?'Em aprendizagem':'Não iniciada',ready:!!x.pass,mastered:false}}
 if(sk.source==='letters-ei'){const x=typeof RC43_letterCoverage==='function'?RC43_letterCoverage():{ratio:0,pass:false};const pct=Math.round(Math.min(1,x.ratio||0)*100);return{pct,state:x.pass?'mastered':pct?'learning':'',label:x.pass?'Vivência concluída':pct?'Explorando':'Não iniciada',ready:!!x.pass,mastered:!!x.pass}}
 if(sk.source==='grapheme-world'||sk.source==='word-world'){const wi=sk.world,s=worldStats(wi),r=masteryReq(wi);const pct=Math.min(99,Math.round((Math.min(1,s.attempts/Math.max(1,r.attempts))*.55+Math.min(1,(s.accuracy||0)/80)*.45)*100));const ready=s.attempts>=Math.min(r.attempts,sk.attempts+4)&&(s.accuracy||0)>=75;return{pct:ready?90:pct,state:ready?'ready':pct?'learning':'',label:ready?'Pronta para desafio':pct?'Em aprendizagem':'Não iniciada',ready,mastered:false}}
 const a=agg(sk.source),min=sk.attempts,rate=sk.rate;const readiness=Math.min(1,a.attempts/min)*.6+Math.min(1,a.rate/rate)*.4;const ready=a.attempts>=min&&a.rate>=rate;return{pct:ready?90:Math.round(readiness*90),state:ready?'ready':a.attempts?'learning':'',label:ready?'Pronta para desafio':a.attempts?'Em aprendizagem':'Não iniciada',ready,mastered:false};
}
function currentSkill(){return C().find(s=>!skillProgress(s).mastered)||C()[C().length-1]}
function curriculumProgress(){const c=C();return Math.round(c.reduce((a,s)=>a+skillProgress(s).pct,0)/Math.max(1,c.length))}
function remainingHours(){const c=C();const total=c.reduce((a,s)=>a+s.minutes,0)/60;const done=c.reduce((a,s)=>a+(s.minutes*skillProgress(s).pct/100),0)/60;return Math.max(0,total-done)}
function estimate(){const hrs=remainingHours(),weekly=Math.max(.25,state.rc59.dailyMinutes*state.rc59.daysPerWeek/60),weeks=hrs/weekly;return{hrs:Math.round(hrs),weeks:Math.max(1,Math.round(weeks)),months:Math.max(1,Math.round(weeks/4.3))}}
function statusClass(p){return p.mastered?'mastered':p.ready?'ready':p.state||''}
function routineHtml(){const e=estimate();return `<div class="rc59-routine"><span class="rc59-chip">${state.rc59.dailyMinutes} min/dia</span><span class="rc59-chip">${state.rc59.daysPerWeek}× por semana</span><span class="rc59-chip">≈ ${e.months} ${e.months===1?'mês':'meses'} restantes*</span></div>`}
function roadmapHtml(){const sk=currentSkill(),p=skillProgress(sk),idx=C().indexOf(sk)+1;return `<div class="rc59-roadmap"><div class="rc59-roadmap-head"><div><span class="kicker">HABILIDADE ${idx} DE ${C().length}</span><h2>${escapeHtml(sk.label)}</h2><p>${escapeHtml(sk.desc||'A trilha organiza o percurso do mais simples ao mais complexo e retoma o que ainda precisa de consolidação.')}</p></div><span class="rc59-status ${statusClass(p)}">${p.label}</span></div><div class="rc59-skillmeter"><i style="width:${p.pct}%"></i></div>${routineHtml()}<div class="rc59-roadmap-actions"><button class="primary" id="rc59Continue">${sk.source==='adult'?'Fazer missão acompanhada':'▶ Praticar esta habilidade'}</button><button class="rc59-map-btn" id="rc59Map">Mapa de habilidades</button></div></div>`}

const EXTRA={
'BALA':`<svg class="rc57-icon" viewBox="0 0 120 100"><rect x="38" y="31" width="44" height="38" rx="12" fill="#ff7da5"/><path d="M38 37L17 25l5 24-5 25 21-12M82 37l21-12-5 24 5 25-21-12" fill="#ffd85c"/><path d="M48 42h24M48 52h24M48 62h18" stroke="#fff" stroke-width="5" stroke-linecap="round"/></svg>`,
'BOCA':`<svg class="rc57-icon" viewBox="0 0 120 100"><path d="M22 50Q42 28 60 42Q78 28 98 50Q77 76 60 66Q43 76 22 50Z" fill="#e85b72"/><path d="M28 51Q60 62 92 51Q60 47 28 51Z" fill="#fff"/><path d="M36 55Q60 69 84 55" fill="none" stroke="#9e2848" stroke-width="4"/></svg>`,
'DEDO':`<svg class="rc57-icon" viewBox="0 0 120 100"><path d="M45 84V39q0-9 8-9t8 9V17q0-9 8-9t8 9v34l8-7q7-6 13 0q5 6-1 13L78 80q-7 9-18 9H51q-6 0-6-5Z" fill="#f1b37e" stroke="#bd7b52" stroke-width="4"/><circle cx="69" cy="15" r="4" fill="#f8d2ae"/></svg>`,
'FADA':`<svg class="rc57-icon" viewBox="0 0 120 100"><circle cx="60" cy="34" r="13" fill="#ffd3ad"/><path d="M45 49q15-10 30 0l10 34H35z" fill="#a88df0"/><path d="M44 46L22 30q-8 23 17 30M76 46l22-16q8 23-17 30" fill="#bfefff" stroke="#66b7e3" stroke-width="3"/><path d="M80 18l6 12 14 2-10 9 3 13-13-7-12 7 3-13-10-9 14-2z" fill="#ffd64b"/></svg>`,
'FITA':`<svg class="rc57-icon" viewBox="0 0 120 100"><circle cx="60" cy="45" r="12" fill="#ff7aaa"/><path d="M51 42Q25 15 19 38q-3 21 31 17M69 42Q95 15 101 38q3 21-31 17" fill="#ff9bc0" stroke="#d95688" stroke-width="4"/><path d="M52 56L40 91l20-13 20 13-12-35" fill="#ff7aaa" stroke="#d95688" stroke-width="4"/></svg>`,
'FOCA':`<svg class="rc57-icon" viewBox="0 0 120 100"><ellipse cx="58" cy="62" rx="39" ry="24" fill="#91a9b8"/><circle cx="78" cy="40" r="22" fill="#a9bdc8"/><circle cx="71" cy="37" r="3"/><circle cx="86" cy="37" r="3"/><ellipse cx="79" cy="45" rx="5" ry="3" fill="#344955"/><path d="M20 63L7 52l7 25zM39 77l-9 15 20-9" fill="#7f98a7"/><path d="M89 47l17-4M89 51l18 3" stroke="#556c78" stroke-width="2"/></svg>`,
'LATA':`<svg class="rc57-icon" viewBox="0 0 120 100"><rect x="34" y="18" width="52" height="68" rx="8" fill="#b8d8df" stroke="#5e8791" stroke-width="4"/><ellipse cx="60" cy="19" rx="26" ry="7" fill="#dceff2" stroke="#5e8791" stroke-width="4"/><path d="M42 43h36v20H42z" fill="#60c47b"/><path d="M48 53h24" stroke="#fff" stroke-width="5"/></svg>`,
'MALA':`<svg class="rc57-icon" viewBox="0 0 120 100"><rect x="24" y="32" width="72" height="55" rx="10" fill="#e3984b" stroke="#8e552d" stroke-width="4"/><path d="M45 32v-9q0-8 8-8h14q8 0 8 8v9" fill="none" stroke="#8e552d" stroke-width="6"/><path d="M38 32v55M82 32v55" stroke="#c97934" stroke-width="4"/><circle cx="60" cy="59" r="6" fill="#ffd76a"/></svg>`,
'NARIZ':`<svg class="rc57-icon" viewBox="0 0 120 100"><path d="M65 16q-4 30-12 51-5 14 8 17 17 3 28-10" fill="#f0b58c" stroke="#bd7b5c" stroke-width="4"/><path d="M57 80q-7 6-15 0" fill="none" stroke="#bd7b5c" stroke-width="4"/><circle cx="76" cy="78" r="3" fill="#8f5642"/></svg>`,
'POTE':`<svg class="rc57-icon" viewBox="0 0 120 100"><path d="M35 30h50l-5 57H40z" fill="#d9edf1" stroke="#5c8891" stroke-width="4"/><rect x="30" y="18" width="60" height="14" rx="5" fill="#6bb7d0"/><path d="M47 48h26v24H47z" fill="#ffd15c"/><circle cx="60" cy="60" r="7" fill="#ff8d5b"/></svg>`,
'TATU':`<svg class="rc57-icon" viewBox="0 0 120 100"><ellipse cx="55" cy="58" rx="38" ry="24" fill="#b77a4f"/><path d="M27 48q28-27 57 0M34 40l10 38M48 34l8 47M62 34l6 46M75 40l4 34" fill="none" stroke="#e0b47e" stroke-width="5"/><ellipse cx="92" cy="59" rx="15" ry="11" fill="#c89062"/><circle cx="98" cy="55" r="2.5"/><path d="M18 61q-14 5-8 11q10 1 20-4" fill="#9c603f"/></svg>`,
'TELA':`<svg class="rc57-icon" viewBox="0 0 120 100"><rect x="17" y="16" width="86" height="58" rx="7" fill="#293c5f"/><rect x="24" y="23" width="72" height="44" rx="3" fill="#83d9ff"/><path d="M50 75h20l4 12H46zM36 88h48" stroke="#405578" stroke-width="6" stroke-linecap="round"/><circle cx="88" cy="70" r="3" fill="#77dd77"/></svg>`,
'TUBO':`<svg class="rc57-icon" viewBox="0 0 120 100"><path d="M24 28h48q24 0 24 24v18" fill="none" stroke="#3cb8dc" stroke-width="24" stroke-linecap="round"/><ellipse cx="24" cy="28" rx="13" ry="16" fill="#86e0f2" stroke="#197fa8" stroke-width="4"/><ellipse cx="96" cy="70" rx="13" ry="16" fill="#86e0f2" stroke="#197fa8" stroke-width="4"/></svg>`,
'VASO':`<svg class="rc57-icon" viewBox="0 0 120 100"><path d="M38 18h44l-6 18q16 18 10 45-3 13-26 13T34 81q-6-27 10-45z" fill="#6db8d0" stroke="#32768d" stroke-width="4"/><path d="M43 58q17-13 34 0M43 72q17-13 34 0" fill="none" stroke="#d6f1f6" stroke-width="5"/></svg>`,
'CAMA':`<svg class="rc57-icon" viewBox="0 0 120 100"><path d="M18 50h84v30H18z" fill="#77b8e8"/><rect x="20" y="36" width="80" height="26" rx="8" fill="#d8efff" stroke="#4b86b4" stroke-width="4"/><rect x="25" y="40" width="30" height="17" rx="7" fill="#fff"/><path d="M18 34v58M102 34v58" stroke="#3b6b8d" stroke-width="6"/></svg>`,
'COPO':`<svg class="rc57-icon" viewBox="0 0 120 100"><path d="M35 15h50l-7 72H42z" fill="#9fe2f1" stroke="#3c91a5" stroke-width="4"/><path d="M42 55h36" stroke="#fff" stroke-width="5"/><path d="M48 26l22 44" stroke="#ff6f7e" stroke-width="5" stroke-linecap="round"/></svg>`,
'GOTA':`<svg class="rc57-icon" viewBox="0 0 120 100"><path d="M60 10Q93 51 93 67q0 29-33 29T27 67Q27 51 60 10Z" fill="#55b9e9" stroke="#247eae" stroke-width="4"/><path d="M45 63q3-13 14-22" fill="none" stroke="#dff7ff" stroke-width="6" stroke-linecap="round"/></svg>`,
'SACO':`<svg class="rc57-icon" viewBox="0 0 120 100"><path d="M43 18h34l-8 16q23 18 23 43 0 20-32 20T28 77q0-25 23-43z" fill="#d6a35b" stroke="#8e5d2c" stroke-width="4"/><path d="M42 35h36" stroke="#7c4b25" stroke-width="5"/><path d="M52 60q8-10 16 0M60 54v25" stroke="#f6d99e" stroke-width="5" stroke-linecap="round"/></svg>`,
'SINO':`<svg class="rc57-icon" viewBox="0 0 120 100"><path d="M32 70h56q-10-12-10-33 0-18-18-18T42 37q0 21-10 33Z" fill="#ffd04d" stroke="#b98612" stroke-width="4"/><path d="M25 72h70" stroke="#b98612" stroke-width="7" stroke-linecap="round"/><circle cx="60" cy="82" r="7" fill="#d99b1c"/></svg>`
};
if(typeof RC57_WORD_SVG==='object')Object.assign(RC57_WORD_SVG,EXTRA);

const RC62_VOCAB1=[
 {base:'FELIZ',syn:'CONTENTE',ant:'TRISTE',other:'REDONDO'},
 {base:'RÁPIDO',syn:'VELOZ',ant:'LENTO',other:'DOCE'},
 {base:'BONITO',syn:'BELO',ant:'FEIO',other:'CURTO'},
 {base:'COMEÇAR',syn:'INICIAR',ant:'TERMINAR',other:'PULAR'},
 {base:'GRANDE',syn:'ENORME',ant:'PEQUENO',other:'AZUL'}
];
const RC62_VOCAB2=[
 {base:'POSSÍVEL',syn:'REALIZÁVEL',ant:'IMPOSSÍVEL',other:'BARULHENTO'},
 {base:'FELIZ',syn:'CONTENTE',ant:'INFELIZ',other:'QUADRADO'},
 {base:'CORRETO',syn:'CERTO',ant:'INCORRETO',other:'RÁPIDO'},
 {base:'PACIENTE',syn:'CALMO',ant:'IMPACIENTE',other:'BRILHANTE'},
 {base:'PERFEITO',syn:'EXATO',ant:'IMPERFEITO',other:'MACIO'}
];
const RC62_SIZE=[
 {base:'GATO',small:'GATINHO',big:'GATÃO'},
 {base:'BOLA',small:'BOLINHA',big:'BOLÃO'},
 {base:'PATO',small:'PATINHO',big:'PATÃO'},
 {base:'COPO',small:'COPINHO',big:'COPÃO'},
 {base:'SAPO',small:'SAPINHO',big:'SAPÃO'}
];
function RC62_makeSpacingTask(){return uniqueTask(()=>{const x=pick(RC47_SENTENCE_WRITING),correct=x.model,joined=correct.replace(' ',''),all=correct.replace(/ /g,'');return{world:'sentences',skill:'sentence:spacing',key:'spacing:'+x.key,sig:'rc62-spacing:'+x.key+':'+Math.random(),command:'Qual frase separa corretamente as palavras com espaços?',audio:[],kind:'sentence',stimulus:{type:'scene',text:x.scene},options:shuffle([correct,joined,all]),answer:correct}})}
function RC62_makeConventionsTask(){return uniqueTask(()=>{const x=pick(RC47_SENTENCE_WRITING),correct=x.model,lower=correct.toLowerCase(),nopunct=correct.replace(/[.!?]$/,''),joined=correct.replace(' ',''),bad=shuffle([lower,nopunct,joined]);return{world:'sentences',skill:'sentence:conventions',key:'conv:'+x.key,sig:'rc62-conv:'+x.key+':'+Math.random(),command:'Qual frase está escrita com início em maiúscula, palavras separadas e pontuação final?',audio:[],kind:'sentence',stimulus:{type:'scene',text:x.scene},options:shuffle([correct,bad[0],bad[1]]),answer:correct}})}
function RC62_makeVocabTask(level=1){return uniqueTask(()=>{const x=pick(level===2?RC62_VOCAB2:RC62_VOCAB1),ant=Math.random()<.5,ans=ant?x.ant:x.syn;return{world:'words',skill:level===2?'vocab:synant2':'vocab:synant1',key:`vocab:${level}:${x.base}:${ant?'ant':'syn'}`,sig:`rc62-vocab:${level}:${x.base}:${ant}:${Math.random()}`,command:ant?(level===2?'Qual palavra tem sentido contrário? Observe que algumas usam in- ou im-.':'Qual palavra tem sentido contrário?'):'Qual palavra tem sentido parecido?',audio:[],kind:'word',stimulus:{type:'word',text:x.base},options:shuffle([ans,ant?x.syn:x.ant,x.other]),answer:ans}})}
function RC62_makeAcrophonicTask(){return uniqueTask(()=>{const letters=['B','D','F','L','M','N','P','T','V','C','G','S'],L=pick(letters),good=pick(WORDS.filter(w=>w.w.startsWith(L))),bad=shuffle(WORDS.filter(w=>!w.w.startsWith(L))).slice(0,2);return{world:'letters',skill:'letters:acrophonic',key:'acro:'+L+':'+good.w,sig:'rc62-acro:'+L+':'+good.w+':'+Math.random(),command:`Qual figura começa com o som representado pela letra ${L}?`,audio:[],kind:'picture',stimulus:{type:'letter',text:L},options:shuffle([good,...bad].map(w=>({value:w.w,pic:wordPic(w.w,w.pic)}))),answer:good.w}})}
function RC62_makeSizeTask(){return uniqueTask(()=>{const x=pick(RC62_SIZE),small=Math.random()<.5,ans=small?x.small:x.big;return{world:'words',skill:'word:morph-size',key:`size:${x.base}:${small?'small':'big'}`,sig:`rc62-size:${x.base}:${small}:${Math.random()}`,command:small?'Qual é o diminutivo desta palavra?':'Qual é o aumentativo desta palavra?',audio:[],kind:'word',stimulus:{type:'word',text:x.base},options:shuffle([ans,small?x.big:x.small,x.base]),answer:ans}})}
function makeTargetTask(sk){
 const s=sk.source;
 if(s==='adult')return null;
 if(s==='reading:directionality'&&typeof RC57_makeDirectionTask==='function')return RC57_makeDirectionTask();
 if(s==='letters:alphabet-order'&&typeof RC56_makeAlphabetOrderTask==='function')return RC56_makeAlphabetOrderTask();if(s==='letters:acrophonic')return RC62_makeAcrophonicTask();
 if(s==='letters-all'||s==='letters-ei')return RC43_makeLetterTask();
 if(s==='writing:cursive-copy'&&typeof RC57_makeCursiveCopyTask==='function')return RC57_makeCursiveCopyTask();
 if(s==='phonology:rhyme')return RC43_makeSoundTask('rhyme');if(s==='phonology:initial')return RC43_makeSoundTask('initial');if(s==='phonology:final'&&typeof RC47_makeFinalSoundTask==='function')return RC47_makeFinalSoundTask();
 if(s==='grapheme:contextual'||s==='grapheme:extended'||s==='grapheme:nasal')return RC48_makeOrthoTask(s.split(':')[1]);
 if(s==='grapheme-world')return makeTask(2);
 if(s==='syllable:first')return RC43_makeSyllableTask('first');if(s==='syllable:last')return RC43_makeSyllableTask('last');if(s==='syllable:count')return RC43_makeSyllableTask('count');if(s==='syllable:join')return RC43_makeSyllableTask('join');if(s==='syllable:manipulation')return RC43_makeSyllableTask('remove');if(s==='syllable:middle')return RC47_makeMiddleSyllableTask();if(s==='syllable:replace:initial'||s==='syllable:replace:medial'||s==='syllable:replace:final')return RC47_makeReplaceSyllableTask();if(s.startsWith('syllable:pattern:'))return RC47_makePatternTask();
 if(s==='word:productive-writing')return RC47_makeWordWritingTask();if(s==='word:morph-size')return RC62_makeSizeTask();if(s==='vocab:synant1')return RC62_makeVocabTask(1);if(s==='vocab:synant2')return RC62_makeVocabTask(2);if(s==='word-world')return makeTask(4);
 if(s==='sentence:productive-writing')return RC47_makeSentenceWritingTask();if(s==='sentence:spacing')return RC62_makeSpacingTask();if(s==='sentence:conventions')return RC62_makeConventionsTask();if(s==='sentence:punctuation')return RC47_makePunctuationTask();if(s==='sentence:reading')return makeTask(5);
 if(s==='comprehension:literal')return RC43_makeComprehensionTask('literal');if(s==='comprehension:inferential')return RC43_makeComprehensionTask('inferential');
 if(s==='ei:visual-sequence')return RC50_makeEISequence();if(s==='ei:visual-inference')return RC50_makeEIInference();
 return makeTask(sk.world);
}
function startSkill(sk,kind='practice'){
 if(sk.source==='adult'){state.rc59.activeSkill=sk.id;view='rc59Adult';render();return}
 state.rc59.activeSkill=sk.id;const goal=kind==='challenge'?6:kind==='bonus'?5:(state.grade==='Pré-escola'?4:5);session={world:sk.world,goal,done:0,independent:0,gate:false,guided:true,retryQueue:[],extra:0,rc59SkillId:sk.id,rc59Kind:kind};current=makeTargetTask(sk);attempt={wrong:0,done:false};view='lesson';render();RC55_scheduleTaskAudio(160);
}
const PREV_NEXT_TASK=nextSessionTask;nextSessionTask=function(){if(session?.rc59SkillId){const sk=C().find(x=>x.id===session.rc59SkillId);if(sk)return makeTargetTask(sk)}return PREV_NEXT_TASK()};
const PREV_SESSION_END=sessionEnd;sessionEnd=function(){if(!session?.rc59SkillId)return PREV_SESSION_END();const sk=C().find(x=>x.id===session.rc59SkillId),kind=session.rc59Kind,ind=session.independent||0,total=session.done||session.goal;if(kind==='challenge'&&ind>=Math.ceil(total*.80)){state.rc59.challenge[sk.id]={at:Date.now(),score:ind,total};safeSave()}if(kind==='bonus'){state.rc59.bonus[sk.id]=(Number(state.rc59.bonus[sk.id])||0)+1;safeSave()}state.rc59.lastFeedback={skill:sk.id,kind,ind,total};view='rc59Feedback';render()};

function skillMap(world=null){setTop(true);const list=world==null?C():C().filter(x=>x.world===world),cur=currentSkill();$('#view').innerHTML=`<section class="view"><div class="card rc59-skill-screen"><div class="rc59-skill-header"><button class="back" id="rc59Back">‹</button><div><h1>${world==null?'Mapa da alfabetização':escapeHtml(worlds[world]?.name||'Habilidades')}</h1><p>${C().filter(s=>skillProgress(s).mastered).length}/${C().length} habilidades concluídas · ${curriculumProgress()}% do percurso</p></div></div><div class="rc59-skill-list">${list.map((s,i)=>{const p=skillProgress(s),n=C().indexOf(s)+1;return `<div class="rc59-skill-card ${s.id===cur.id?'current':''}"><div class="rc59-skill-num">${n}</div><div><b>${escapeHtml(s.label)}</b><small>${escapeHtml(s.bncc.join(' · '))}${s.desc?' · '+escapeHtml(s.desc):''}</small></div><span class="rc59-skill-state ${statusClass(p)}">${p.label}</span><div class="rc59-skill-open"><button class="rc59-practice" data-rc59-practice="${s.id}">Praticar</button>${!p.mastered&&s.source!=='adult'?`<button class="rc59-challenge" data-rc59-challenge="${s.id}">Eu já sei · desafio</button>`:''}${(p.ready||p.mastered)&&s.source!=='adult'?`<button class="rc59-bonus" data-rc59-bonus="${s.id}">Bônus</button>`:''}</div></div>`}).join('')}</div>${footer()}</div></section>`;$('#rc59Back').onclick=()=>{view='home';render()};$$('[data-rc59-practice]').forEach(b=>b.onclick=()=>startSkill(C().find(x=>x.id===b.dataset.rc59Practice),'practice'));$$('[data-rc59-challenge]').forEach(b=>b.onclick=()=>startSkill(C().find(x=>x.id===b.dataset.rc59Challenge),'challenge'));$$('[data-rc59-bonus]').forEach(b=>b.onclick=()=>startSkill(C().find(x=>x.id===b.dataset.rc59Bonus),'bonus'))}
function adultMission(){setTop(true);const sk=C().find(x=>x.id===state.rc59.activeSkill)||currentSkill();$('#view').innerHTML=`<section class="view"><div class="card rc59-adult-mission"><div class="icon">📝</div><span class="kicker">MISSÃO COM UM ADULTO</span><h1>${escapeHtml(sk.label)}</h1><p class="instruction">${escapeHtml(sk.adult)}</p><div class="rc59-adult-choices"><button class="rc59-alone" data-r="alone">Concluiu sozinho</button><button class="rc59-help" data-r="help">Concluiu com ajuda</button><button class="rc59-learning" data-r="learning">Ainda está aprendendo</button></div><button class="secondary" style="width:100%;margin-top:10px" id="rc59AdultBack">Voltar</button>${footer()}</div></section>`;$('#rc59AdultBack').onclick=()=>{view='home';render()};$$('[data-r]').forEach(b=>b.onclick=()=>{const a=state.rc59.adult[sk.id]||{alone:0,help:0,learning:0};a[b.dataset.r]=(a[b.dataset.r]||0)+1;a.last=Date.now();state.rc59.adult[sk.id]=a;safeSave();state.rc59.lastFeedback={skill:sk.id,kind:'adult',ind:b.dataset.r==='alone'?1:0,total:1};view='rc59Feedback';render()})}
function feedback(){setTop(true);const f=state.rc59.lastFeedback||{},sk=C().find(x=>x.id===f.skill)||currentSkill(),p=skillProgress(sk),passed=p.mastered||p.ready;const next=C()[Math.min(C().length-1,C().indexOf(sk)+1)];$('#view').innerHTML=`<section class="view"><div class="card rc59-feedback"><div class="big">${p.mastered?'⭐':passed?'🏆':'🌱'}</div><h1>${p.mastered?'Habilidade dominada!':passed?'Você terminou esta etapa da habilidade!':'Vamos consolidar mais um pouco!'}</h1><p><b>${escapeHtml(sk.label)}</b><br>${p.mastered?'Você demonstrou domínio e pode avançar.':passed?'A habilidade está pronta para o desafio de domínio.':'Mais algumas práticas vão deixar esta habilidade firme.'}</p><div class="rc59-feedback-box"><b>${f.ind||0} de ${f.total||1} resolvidas sem ajuda nesta missão</b><small>${next&&next.id!==sk.id?'Próxima habilidade: '+escapeHtml(next.label):'Última etapa do percurso selecionado.'}</small></div><div class="rc59-feedback-actions">${!p.mastered&&sk.source!=='adult'?`<button class="fix" id="rc59Bonus">Bônus de fixação</button><button class="advance" id="rc59Challenge">Desafio de domínio</button>`:`<button class="fix" id="rc59Bonus">Bônus de fixação</button><button class="advance" id="rc59Advance">Vamos avançar</button>`}<button class="home" id="rc59Home">Voltar à trilha</button></div>${footer()}</div></section>`;const bonus=$('#rc59Bonus');if(bonus)bonus.onclick=()=>startSkill(sk,'bonus');const ch=$('#rc59Challenge');if(ch)ch.onclick=()=>startSkill(sk,'challenge');const adv=$('#rc59Advance');if(adv)adv.onclick=()=>{view='home';render()};$('#rc59Home').onclick=()=>{view='home';render()}}

const RC59_PREV_RENDER=render;render=function(){if(view==='rc59SkillMap'){skillMap(state.rc59.mapWorld??null);return}if(view==='rc59Adult'){adultMission();return}if(view==='rc59Feedback'){feedback();return}return RC59_PREV_RENDER()};
const RC59_PREV_HOME=home;home=function(){RC59_PREV_HOME();const viewEl=$('.home-view');if(!viewEl)return;const hero=viewEl.querySelector('.hero');if(hero&&!viewEl.querySelector('.rc59-modebar'))hero.insertAdjacentHTML('afterend',`<div class="rc59-modebar"><button class="${state.rc59.mode==='guided'?'sel':''}" data-rc59-mode="guided">Trilha Guiada</button><button class="${state.rc59.mode==='free'?'sel':''}" data-rc59-mode="free">Exploração Livre</button></div>${roadmapHtml()}`);$$('[data-rc59-mode]').forEach(b=>b.onclick=()=>{state.rc59.mode=b.dataset.rc59Mode;safeSave();home()});const c=$('#rc59Continue');if(c)c.onclick=()=>startSkill(currentSkill(),'practice');const m=$('#rc59Map');if(m)m.onclick=()=>{state.rc59.mapWorld=null;view='rc59SkillMap';render()};if(state.rc59.mode==='free')$$('[data-world]').forEach(b=>b.onclick=()=>{state.rc59.mapWorld=Number(b.dataset.world);view='rc59SkillMap';render()})};
const RC59_PREV_ADULT=adult;adult=function(){RC59_PREV_ADULT();const card=$('.card.adult');if(!card||card.querySelector('.rc59-family-block'))return;const e=estimate(),annualHours=Math.round((state.rc59.dailyMinutes*state.rc59.daysPerWeek*52/60)*10)/10,stageHours=Math.round((C().reduce((a,s)=>a+s.minutes,0)/60)*10)/10,block=document.createElement('div');block.className='rc59-family-block';block.innerHTML=`<h2>Plano de alfabetização</h2><p><b>Rotina recomendada: 15 minutos por dia, 4 vezes por semana.</b> Na <b>Trilha Guiada</b>, o aplicativo segue um roteiro do mais simples ao mais complexo. Na <b>Exploração Livre</b>, a criança pode escolher conteúdos e comprovar domínio por desafios. O percurso é recalculado conforme o desempenho.</p><div class="rc59-routine-grid"><label>Minutos por dia<select id="rc59Minutes">${[10,15,20,25,30].map(x=>`<option ${x===state.rc59.dailyMinutes?'selected':''}>${x}</option>`).join('')}</select></label><label>Dias por semana<select id="rc59Days">${[3,4,5,6].map(x=>`<option ${x===state.rc59.daysPerWeek?'selected':''}>${x}</option>`).join('')}</select></label></div><div class="rc59-estimate"><b>${curriculumProgress()}% do percurso concluído</b><br>Estimativa atual: cerca de <b>${e.hrs} horas</b> de prática distribuídas por aproximadamente <b>${e.weeks} semanas (${e.months} ${e.months===1?'mês':'meses'})</b>, considerando a rotina selecionada.</div><div class="rc591-value-card"><span class="kicker">SEU RITMO → SEU PERCURSO</span><div class="rc591-value-flow"><b>${state.rc59.dailyMinutes} min/dia</b><i>→</i><b>${state.rc59.daysPerWeek}×/semana</b><i>→</i><b>≈ ${Math.round(state.rc59.dailyMinutes*state.rc59.daysPerWeek/60*10)/10} h/semana</b><i>→</i><b>≈ ${annualHours} h/ano</b></div><p>Esta etapa reúne aproximadamente <b>${stageHours} horas</b> de experiências planejadas antes dos ajustes por diagnóstico, desafios de domínio, bônus e retomadas.</p></div><div class="rc591-annual-card"><div><span class="kicker">ACOMPANHAMENTO CONTÍNUO</span><b>Uma rotina consistente ajuda a acompanhar o percurso pedagógico.</b><small>Diagnóstico, progressão, prática, fixação, desafios e revisões são organizados ao longo do tempo sem transformar aprendizagem em oferta comercial para a criança.</small></div></div><button class="soft" style="width:100%;margin-top:10px" id="rc59OpenMap">Ver mapa completo de habilidades</button><div class="rc59-disclaimer">* Horas, semanas e meses são estimativas pedagógicas, não prazo fixo nem promessa de resultado. O Intelectus <b>oferece</b> um percurso sistemático de alfabetização e registra evidências de domínio; o desenvolvimento individual depende também de frequência, desenvolvimento da criança, mediação e experiências de leitura e escrita fora da tela.</div>`;const grid=card.querySelector('.adult-grid');(grid||card).insertAdjacentElement(grid?'beforebegin':'beforeend',block);$('#rc59Minutes').onchange=e=>{state.rc59.dailyMinutes=Number(e.target.value);safeSave();adult()};$('#rc59Days').onchange=e=>{state.rc59.daysPerWeek=Number(e.target.value);safeSave();adult()};$('#rc59OpenMap').onclick=()=>{state.rc59.mapWorld=null;view='rc59SkillMap';render()}};

window.RC59_API=Object.freeze({C,skillProgress,curriculumProgress,startSkill,agg});
window.RC59_AUDIT={version:RC59_VERSION,grades:Object.fromEntries(Object.entries(RC59_CURRICULUM).map(([g,v])=>[g,v.length])),guided:true,freeWithChallenge:true,bonus:true,adultMissions:true,stableVisualFallbacks:Object.keys(EXTRA).length};
document.title='Intelectus Alfabetização — RC59';
safeSave();render();
})();


/* ===== rc59-1-audit ===== */
window.RC59_1_AUDIT={missionNoOverlap:true,commercialJourney:true,claimLanguage:"oferece",annualPlanPositioning:"recommended",productionChanged:false};document.title="Intelectus Alfabetização — RC59.1";

/* ===== rc60-layer ===== */

(()=>{
 const RC62_VERSION=62;
 const R59=window.RC59_API;
 if(!R59) throw new Error('RC59 curriculum API unavailable');
 const C=R59.C,skillProgress=R59.skillProgress,curriculumProgress=R59.curriculumProgress,startSkill=R59.startSkill,agg=R59.agg;
 state.rcPedagogicalVersion=RC62_VERSION;
 state.rc60=state.rc60&&typeof state.rc60==='object'?state.rc60:{};
 state.rc60.consolidationCycles=Number(state.rc60.consolidationCycles)||0;
 state.rc60.recommendedMinutes=15;
 state.rc60.recommendedDays=4;
 safeSave();
 const stageHoursByGrade={'Pré-escola':13.5,'1º Ano':35,'2º Ano':40.5};
 const skillCountsByGrade={'Pré-escola':12,'1º Ano':25,'2º Ano':31};
 const productHours=89;
 const productSkillEntries=68;
 function rc60Fmt(n){return Number(n).toLocaleString('pt-BR',{maximumFractionDigits:2})}
 function rc60StageHours(){return stageHoursByGrade[state.grade]||35}
 function rc60BaselineWeeks(){return Math.ceil(rc60StageHours()/(15*4/60))}
 function rc60BaselineMonths(){return Math.round(rc60BaselineWeeks()/4.3*10)/10}
 function rc60ReviewSkill(){
   const rows=C().filter(s=>s.source!=='adult'&&skillProgress(s).mastered);
   if(!rows.length)return C().find(s=>s.source!=='adult')||C()[0];
   return rows.slice().sort((a,b)=>(agg(a.source).last||0)-(agg(b.source).last||0))[0];
 }
 const RC62_PREV_HOME=home;
 home=function(){
   RC62_PREV_HOME();
   const root=document.querySelector('.home-view');if(!root)return;
   if(curriculumProgress()>=100){
     const road=root.querySelector('.rc59-roadmap');
     if(road&&!road.classList.contains('rc60-done')){
       road.classList.add('rc60-done');
       road.innerHTML=`<span class="kicker">ETAPA CONCLUÍDA</span><h2>Parabéns! A trilha principal desta etapa foi concluída.</h2><p>Agora o aplicativo entra em <b>Ciclo de Consolidação</b>: revisões curtas retomam habilidades já dominadas para fortalecer fluência, memória e autonomia.</p><div class="rc60-consolidation"><span class="kicker">CICLO DE CONSOLIDAÇÃO</span><h2>Continue praticando sem repetir o percurso inteiro</h2><p>O Intelectus escolhe uma habilidade dominada para uma revisão curta. Você também pode abrir o mapa e escolher um bônus.</p><div class="rc60-consolidation-actions"><button class="rc60-review" id="rc60Review">↻ Revisão inteligente</button><button class="rc60-map" id="rc60Map">Mapa de habilidades</button></div><div class="rc60-post-note">Ciclos de consolidação concluídos: ${state.rc60.consolidationCycles}</div></div>`;
       const r=document.getElementById('rc60Review');if(r)r.onclick=()=>startSkill(rc60ReviewSkill(),'consolidation');
       const m=document.getElementById('rc60Map');if(m)m.onclick=()=>{state.rc59.mapWorld=null;view='rc59SkillMap';render()};
     }
   }
 };
 const RC62_PREV_SESSION_END=sessionEnd;
 sessionEnd=function(){
   if(session?.rc59Kind==='consolidation'){
      state.rc60.consolidationCycles=(Number(state.rc60.consolidationCycles)||0)+1;
      safeSave();
   }
   return RC62_PREV_SESSION_END();
 };
 const RC62_PREV_RENDER=render;
 render=function(){
   RC62_PREV_RENDER();
   if(view==='rc59Feedback'&&state.rc59?.lastFeedback?.kind==='consolidation'){
      const card=document.querySelector('.rc59-feedback');if(!card)return;
      const big=card.querySelector('.big');if(big)big.textContent='↻';
      const h=card.querySelector('h1');if(h)h.textContent='Revisão concluída!';
      const p=card.querySelector('p');if(p)p.innerHTML='<b>Habilidade retomada com sucesso.</b><br>Revisões curtas ajudam a manter o que já foi aprendido sem reiniciar toda a trilha.';
   }
 };
 const RC62_PREV_ADULT=adult;
 adult=function(){
   RC62_PREV_ADULT();
   const card=document.querySelector('.card.adult');if(!card||card.querySelector('.rc60-stage-summary'))return;
   const family=card.querySelector('.rc59-family-block');if(!family)return;
   const weeks=rc60BaselineWeeks(),months=rc60BaselineMonths(),hours=rc60StageHours(),skills=skillCountsByGrade[state.grade]||C().length;
   const summary=document.createElement('div');summary.className='rc60-stage-summary';
   summary.innerHTML=`<h3>O que esta etapa oferece</h3><p>A etapa <b>${escapeHtml(state.grade)}</b> reúne ${skills} habilidades/vivências organizadas em progressão. A referência abaixo usa a rotina recomendada de 15 minutos, 4 vezes por semana; os desafios de domínio podem encurtar o percurso.</p><div class="rc60-stage-metrics"><div><b>${rc60Fmt(hours)} h</b><small>experiências planejadas nesta etapa</small></div><div><b>≈ ${weeks} sem.</b><small>referência em 15 min · 4×/semana</small></div><div><b>≈ ${months} meses</b><small>antes dos ajustes individuais</small></div></div><div class="rc60-post-note">O produto completo reúne ${productSkillEntries} habilidades/vivências mapeadas e aproximadamente ${productHours} horas planejadas entre Pré-escola, 1º e 2º Ano. A criança não precisa refazer etapas anteriores quando o diagnóstico ou os desafios mostram que já domina a habilidade.</div>`;
   const routine=document.createElement('div');routine.className='rc60-routine15';
   routine.innerHTML=`<h3>Como usar 15 minutos</h3><div class="rc60-routine15-grid"><div><b>2 min</b><span>aquecimento e retomada</span></div><div><b>9 min</b><span>habilidade principal</span></div><div><b>3 min</b><span>bônus ou revisão</span></div><div><b>1 min</b><span>feedback e próxima meta</span></div></div><div class="rc60-post-note">É uma sugestão de rotina, não um cronômetro obrigatório. Sessões podem ser mais curtas conforme idade, atenção e tipo de atividade.</div>`;
   family.appendChild(summary);family.appendChild(routine);
 };
 window.RC62_AUDIT={version:60,recommendedRoutine:'15min-4x',stageHours:stageHoursByGrade,productHours,productSkillEntries,consolidationCycle:true,estimateMinimumWeeklyHours:.25,claimLanguage:'oferece',productionChanged:false};
 document.title='Intelectus Alfabetização — RC62';
 render();
})();

