const CACHE = 'intelectus-tabuada-quality-6-7-2-logo-bncc-contrast';
const PREFIX = 'intelectus-tabuada-';
const ROOT = new URL('./', self.location.href).href;
const DEADLINE = 6000;

// App shell and visual identity must be available offline after a successful first install.
const REQUIRED_ASSETS = [
  'family-standard.css',
  'family-standard.js',
  'family-controls.css',
  'family-controls.js',
  'src/main.js',
  'src/curriculum.js',
  'src/pedagogy.js',
  'src/miniGames.js',
  'src/contentBank.js',
  'src/progression.js',
  'src/styles.css',
  'src/quality.css',
  'src/evolution.css',
  'manifest.webmanifest',
  'icon.svg',
  'icon-192.png',
  'icon-512.png',
  'icon-maskable-192.png',
  'icon-maskable-512.png',
  'apple-touch-icon.png',
  'resources/branding/logo-tabuada.webp',
  'resources/branding/cover-tabuada.webp',
  'resources/branding/background-tabuada.webp',
  'resources/family/avatar-aventureira.webp',
  'resources/family/avatar-aventureiro.webp',
  'resources/family/avatar-coruja.webp',
  'resources/family/avatar-panda.webp',
  'resources/family/avatar-leao.webp',
  'resources/family/avatar-raposa.webp',
  'resources/family/avatar-coelha.webp',
  'resources/family/avatar-astronauta.webp',
  'resources/family/guide-lia.webp',
  'resources/family/guide-aline.webp',
  'resources/family/guide-daniel.webp',
  'resources/family/guide-caio.webp',
  'resources/icons/game-grupos.svg',
  'resources/icons/game-fator.svg',
  'resources/icons/game-divisao.svg',
  'resources/icons/game-mercado.svg',
  'resources/icons/game-padroes.svg',
  'resources/icons/game-combinacoes.svg',
  'resources/icons/game-porcentagem.svg',
  'resources/icons/game-multiplos.svg',
  'resources/icons/game-divisores.svg',
  'resources/icons/game-primos.svg',
  'resources/icons/game-potencias.svg',
  'resources/icons/game-expressoes.svg',
  'resources/icons/grade-3.svg',
  'resources/icons/grade-4.svg',
  'resources/icons/grade-5.svg',
  'resources/icons/grade-6.svg'
];

// Audio enriches the experience but must never block PWA installation/offline shell.
const OPTIONAL_ASSETS = [
  'resources/audio/musica-aventura.mp3',
  'resources/audio/welcome.mp3',
  'resources/audio/instruction.mp3',
  'resources/audio/practice.mp3',
  'resources/audio/hint.mp3',
  'resources/audio/praise.mp3',
  'resources/audio/retry.mp3',
  'resources/audio/finish.mp3',
  'resources/audio/boss.mp3',
  'resources/audio/learn.mp3'
];

async function openCache() {
  try { return await caches.open(CACHE); } catch { return null; }
}

async function cached(cache, request) {
  try { return cache ? await cache.match(request) : null; } catch { return null; }
}

async function putSafe(cache, request, response) {
  try {
    if (!cache) return false;
    await cache.put(request, response);
    return true;
  } catch { return false; }
}

async function network(request, options = {}) {
  const controller = new AbortController();
  let timer;
  try {
    return await Promise.race([
      fetch(request, { ...options, signal: controller.signal }),
      new Promise((_, reject) => {
        timer = setTimeout(() => {
          controller.abort();
          reject(new Error('Network timeout'));
        }, DEADLINE);
      }),
    ]);
  } finally { clearTimeout(timer); }
}

function validAsset(url, response) {
  if (!response || !response.ok || response.status !== 200) return false;
  const type = (response.headers.get('content-type') || '').toLowerCase().split(';')[0].trim();
  const path = new URL(url, ROOT).pathname;
  if (/\.js$/.test(path)) return /(?:java|ecma)script$/.test(type);
  if (/\.css$/.test(path)) return type === 'text/css';
  if (/\.(?:svg|png|webp|jpe?g)$/.test(path)) return type.startsWith('image/');
  if (/\.webmanifest$/.test(path)) return type === 'application/manifest+json' || type === 'application/json';
  if (/\.(?:mp3|wav)$/.test(path)) return type.startsWith('audio/');
  return false;
}

async function fetchAndCache(cache, path, required = true) {
  const url = new URL(path, ROOT).href;
  try {
    const existing = await cached(cache, url);
    if (validAsset(url, existing)) return true;
    const response = await network(url, { cache: 'reload' });
    if (!validAsset(url, response)) {
      if (required) throw new Error(`Invalid asset: ${path}`);
      return false;
    }
    if (!(await putSafe(cache, url, response.clone())) && required) throw new Error(`Cache unavailable: ${path}`);
    return true;
  } catch (error) {
    if (required) throw error;
    return false;
  }
}

async function prepareShell(cache, response) {
  if (!cache || !response.ok || !(response.headers.get('content-type') || '').toLowerCase().includes('text/html')) {
    throw new Error('Invalid app shell');
  }
  const html = await response.clone().text();
  if (!/\bid\s*=\s*["']app["']/i.test(html)) throw new Error('Missing app root');
  if (!(await putSafe(cache, ROOT, response.clone()))) throw new Error('App shell cache unavailable');
}

self.addEventListener('install', (event) => {
  event.waitUntil((async () => {
    const cache = await openCache();
    const response = await network(new URL('index.html', ROOT), { cache: 'reload' });
    await prepareShell(cache, response);
    await Promise.all(REQUIRED_ASSETS.map((path) => fetchAndCache(cache, path, true)));
    await Promise.allSettled(OPTIONAL_ASSETS.map((path) => fetchAndCache(cache, path, false)));
    // The new worker waits until active learning tabs are closed, preserving the current session version.
  })());
});

self.addEventListener('activate', (event) => {
  event.waitUntil((async () => {
    try {
      const keys = await caches.keys();
      await Promise.allSettled(keys.filter((key) => key.startsWith(PREFIX) && key !== CACHE).map((key) => caches.delete(key)));
    } catch {
      // App remains usable even if cache enumeration is restricted.
    }
    // Open tabs remain on the active version; the new worker controls the next navigation/reopen.
  })());
});

self.addEventListener('fetch', (event) => {
  const request = event.request;
  const url = new URL(request.url);
  if (request.method !== 'GET' || url.origin !== self.location.origin || !url.href.startsWith(ROOT) || url.pathname.includes('/api/')) return;

  if (request.mode === 'navigate') {
    event.respondWith((async () => {
      const cache = await openCache();
      try {
        const response = await network(request, { cache: 'no-store' });
        if (response.ok) {
          if (cache) event.waitUntil(prepareShell(cache, response.clone()).catch(() => undefined));
          return response;
        }
        return (await cached(cache, ROOT)) || response;
      } catch {
        return (await cached(cache, ROOT)) || new Response(
          'Abra o aplicativo com internet uma vez para preparar o modo offline. O progresso salvo não foi apagado.',
          { status: 503, headers: { 'Content-Type': 'text/plain; charset=utf-8' } },
        );
      }
    })());
    return;
  }

  if (!/\.(?:js|css|svg|png|webp|jpe?g|webmanifest|mp3|wav)$/.test(url.pathname)) return;
  event.respondWith((async () => {
    const cache = await openCache();
    const existing = await cached(cache, request);
    if (validAsset(url.href, existing)) return existing;
    try {
      const response = await network(request);
      if (response.ok && !validAsset(url.href, response)) return new Response('', { status: 502 });
      if (validAsset(url.href, response)) await putSafe(cache, request, response.clone());
      return response;
    } catch { return new Response('', { status: 503 }); }
  })());
});
