


import { RELEASE, KEY, LEGACY_KEYS, fresh, normalize, getFact, getSkillProgress, question, strategy, sum, equation, prompt, record, recover, recordSkill, recordGameSession, recordBossAttempt, consolidated, metrics, validateBackup, dominantSkillError, escape as esc, } from './pedagogy.js';
import { GRADE_META, GRADE_ORDER, GRADES, GAMES, BNCC_CODES, skillsForGrade, findSkill, } from './curriculum.js';
import { generateMiniQuestion } from './miniGames.js';
import { STORIES, BOSSES, missionsForGrade, collectiblesForGrade, allCollectibles, achievements, bossUnlocked, bossCompleted, } from './progression.js';
const $ = (id) => document.getElementById(id);
const app = $('app');
app.classList.add('app');
let storageWarning = '';
function read(key) {
    try {
        return localStorage.getItem(key);
    }
    catch {
        storageWarning =
            'O navegador bloqueou o armazenamento. O progresso só ficará nesta sessão; exporte uma cópia.';
        return null;
    }
}
function write(key, value) {
    try {
        localStorage.setItem(key, value);
        return true;
    }
    catch {
        storageWarning = 'Não foi possível salvar no navegador. Exporte seu progresso antes de sair.';
        const element = $('storageStatus');
        if (element) {
            element.hidden = false;
            element.textContent = storageWarning;
        }
        return false;
    }
}
function load() {
    try {
        const current = read(KEY);
        if (current)
            return normalize(JSON.parse(current));
        for (const legacyKey of LEGACY_KEYS) {
            const legacy = read(legacyKey);
            if (!legacy)
                continue;
            const migrated = normalize(JSON.parse(legacy));
            migrated.migrated = true;
            write(KEY, JSON.stringify(migrated));
            return migrated;
        }
    }
    catch {
        storageWarning =
            'Há dados locais inválidos. O aplicativo abriu em modo de recuperação sem apagar automaticamente a cópia anterior.';
    }
    return fresh();
}
let state = load();
const save = () => write(KEY, JSON.stringify(state));
const TRIAL_KEY = 'intelectus_tabuada_trial_v1';
const WEEK = 7 * 86400000;
const portalEntitled = () => document.documentElement.dataset.intelectusPortal === 'entitled' ||
    window.__INTELECTUS_PORTAL_ENTITLED__ === true;
function trial() {
    if (portalEntitled())
        return { start: Date.now(), last: Date.now() };
    try {
        const value = JSON.parse(read(TRIAL_KEY) || 'null');
        if (value &&
            Number.isFinite(value.start) &&
            value.start > 0 &&
            Number.isFinite(value.last) &&
            value.last >= value.start) {
            return { start: value.start, last: value.last };
        }
    }
    catch {
        return null;
    }
    return null;
}
function expired() {
    if (portalEntitled())
        return false;
    const value = trial();
    return Boolean(value && Math.max(Date.now(), value.last) - value.start >= WEEK);
}
function allow(explicit = false) {
    if (portalEntitled())
        return true;
    let value = trial();
    if (!value) {
        if (!explicit &&
            !confirm('Iniciar a avaliação gratuita de 7 dias neste dispositivo? Depois, o acesso é pago. Não haverá cobrança automática.')) {
            return false;
        }
        value = { start: Date.now(), last: Date.now() };
        write(TRIAL_KEY, JSON.stringify(value));
    }
    else {
        value.last = Math.max(value.last, Date.now());
        write(TRIAL_KEY, JSON.stringify(value));
    }
    if (expired()) {
        go('family');
        say('A avaliação terminou. O relatório e o backup continuam disponíveis.');
        return false;
    }
    return true;
}
let route = state.name ? 'home' : 'splash';
let setupStep = 1;
if ('speechSynthesis' in window) {
    window.speechSynthesis.onvoiceschanged = () => {
        if (route === 'setup' && setupStep === 5)
            render();
        const dialog = $('settings');
        if (dialog?.open)
            settings();
    };
}
let intent = 'map';
let learnA = 2;
let learnB = 3;
let practiceSession = null;
let miniSession = null;
let bossSession = null;
let placementSession = null;
const avatars = [
    { id: 'aventureira', name: 'Aventureira', src: './resources/family/avatar-aventureira.webp', desc: 'curiosa e destemida' },
    { id: 'aventureiro', name: 'Aventureiro', src: './resources/family/avatar-aventureiro.webp', desc: 'animado e explorador' },
    { id: 'coruja', name: 'Coruja Leitora', src: './resources/family/avatar-coruja.webp', desc: 'amiga das descobertas' },
    { id: 'panda', name: 'Panda Amigo', src: './resources/family/avatar-panda.webp', desc: 'fofo e companheiro' },
    { id: 'leao', name: 'Leão Corajoso', src: './resources/family/avatar-leao.webp', desc: 'valente e sorridente' },
    { id: 'raposa', name: 'Raposa Esperta', src: './resources/family/avatar-raposa.webp', desc: 'curiosa e atenta' },
    { id: 'coelha', name: 'Coelha Feliz', src: './resources/family/avatar-coelha.webp', desc: 'alegre e gentil' },
    { id: 'astronauta', name: 'Mini Astronauta', src: './resources/family/avatar-astronauta.webp', desc: 'pronto para descobrir' },
];
const guides = [
    { id: 'lia', name: 'Lia', title: 'Profª', src: './resources/family/guide-lia.webp', desc: 'acolhedora e carinhosa' },
    { id: 'aline', name: 'Aline', title: 'Profª', src: './resources/family/guide-aline.webp', desc: 'criativa e incentivadora' },
    { id: 'daniel', name: 'Daniel', title: 'Prof.', src: './resources/family/guide-daniel.webp', desc: 'curioso e encorajador' },
    { id: 'caio', name: 'Caio', title: 'Prof.', src: './resources/family/guide-caio.webp', desc: 'divertido e parceiro' },
];
const MUSIC_URL = './resources/audio/musica-aventura.mp3';
const VOICE_CLIPS = {
    welcome: './resources/audio/welcome.mp3',
    instruction: './resources/audio/instruction.mp3',
    practice: './resources/audio/practice.mp3',
    hint: './resources/audio/hint.mp3',
    praise: './resources/audio/praise.mp3',
    retry: './resources/audio/retry.mp3',
    finish: './resources/audio/finish.mp3',
    boss: './resources/audio/boss.mp3',
    learn: './resources/audio/learn.mp3',
};
const VOICE_TEXT = {
    welcome: 'Olá! Bem-vindo à aventura da tabuada. Vamos aprender, jogar e evoluir juntos.',
    instruction: 'Leia com atenção e escolha a melhor resposta. Você pode pensar com calma.',
    practice: 'Agora é sua vez. Resolva o desafio usando a estratégia que fizer mais sentido para você.',
    hint: 'Quer uma ajuda? Observe os números, procure um padrão e tente novamente.',
    praise: 'Muito bem! Seu raciocínio está ficando cada vez mais forte.',
    retry: 'Ainda não foi dessa vez. Reveja a ideia, use uma pista se precisar e tente de novo.',
    finish: 'Missão concluída! Veja o que você aprendeu e escolha seu próximo desafio.',
    boss: 'Chegou o Chefão Matemático. Use tudo o que você aprendeu e resolva um desafio de cada vez.',
    learn: 'Vamos aprender uma estratégia nova. Observe o exemplo, descubra o padrão e depois experimente sozinho.',
};
const avatarChoice = (id) => avatars.find((item) => item.id === id) || avatars[5];
const guideChoice = (id) => guides.find((item) => item.id === id) || guides[0];
const guideName = (id = state.guide) => {
    const guide = guideChoice(id);
    return `${guide.title} ${guide.name}`;
};
const characterCard = (item, kind, selected) => {
    const title = 'title' in item ? `${item.title} ${item.name}` : item.name;
    return `<button type='button' class='character-card ${selected ? 'sel' : ''}' data-${kind}='${item.id}' aria-pressed='${selected}'><img src='${item.src}' alt='' aria-hidden='true'><b>${esc(title)}</b><small>${esc(item.desc)}</small></button>`;
};
const guideCoachMarkup = (message) => {
    const guide = guideChoice(state.guide);
    return `<div class='guide-coach'><img src='${guide.src}' alt='' aria-hidden='true'><div><strong>${esc(guideName())}</strong><p>${esc(message)}</p></div></div>`;
};
const sessionGuideMarkup = () => {
    const guide = guideChoice(state.guide);
    return `<span class='session-guide'><img src='${guide.src}' alt=''><span>${esc(guideName())}</span></span>`;
};
const button = (id, text, style = 'primary') => `<button type='button' class='btn ${style}' id='${id}'>${text}</button>`;
const navButton = (id, text, style, current) => `<button type='button' class='btn ${style} ${current ? 'nav-current' : ''}' id='${id}' ${current ? "aria-current='page'" : ''}>${text}</button>`;
const GAME_ICON_PATH = {
    grupos: './resources/icons/game-grupos.svg',
    fator: './resources/icons/game-fator.svg',
    divisao: './resources/icons/game-divisao.svg',
    mercado: './resources/icons/game-mercado.svg',
    padroes: './resources/icons/game-padroes.svg',
    combinacoes: './resources/icons/game-combinacoes.svg',
    porcentagem: './resources/icons/game-porcentagem.svg',
    multiplos: './resources/icons/game-multiplos.svg',
    divisores: './resources/icons/game-divisores.svg',
    primos: './resources/icons/game-primos.svg',
    potencias: './resources/icons/game-potencias.svg',
    expressoes: './resources/icons/game-expressoes.svg',
};
const GRADE_ICON_PATH = {
    '3º Ano': './resources/icons/grade-3.svg',
    '4º Ano': './resources/icons/grade-4.svg',
    '5º Ano': './resources/icons/grade-5.svg',
    '6º Ano': './resources/icons/grade-6.svg',
};
function pictogram(src, alt = '', className = 'app-pictogram') {
    return `<img class='${className}' src='${src}' alt='${esc(alt)}' ${alt ? '' : "aria-hidden='true'"}>`;
}
function gameIcon(gameId, alt = '', className = 'app-pictogram') {
    return pictogram(GAME_ICON_PATH[gameId], alt, className);
}
function gradeIcon(grade, alt = '', className = 'app-pictogram') {
    return pictogram(GRADE_ICON_PATH[grade], alt, className);
}
function skillIcon(skill, alt = '', className = 'app-pictogram') {
    return gameIcon(skill.games[0], alt, className);
}
const ERROR_CATEGORY_LABELS = {
    fact: 'fatos básicos', operation: 'escolha da operação', inverse: 'relação inversa', division: 'divisão e resto',
    pattern: 'regularidades', proportion: 'proporcionalidade', percentage: 'porcentagens', divisibility: 'divisibilidade',
    expression: 'ordem das operações', power: 'potenciação', combination: 'combinações', prime: 'primos e divisores',
};
function errorCategoryForGame(gameId) {
    const map = {
        grupos: 'fact', fator: 'inverse', divisao: 'division', mercado: 'proportion', padroes: 'pattern',
        combinacoes: 'combination', porcentagem: 'percentage', multiplos: 'divisibility', divisores: 'divisibility',
        primos: 'prime', potencias: 'power', expressoes: 'expression',
    };
    return map[gameId];
}
const FAMILY_MISSIONS = {
    '3º Ano': [
        { id: '3-grupos-casa', title: 'Grupos no cotidiano', description: 'Separe objetos da casa em grupos iguais e explique a multiplicação formada.' },
        { id: '3-dividir-lanche', title: 'Dividir e conferir', description: 'Reparta uma pequena quantidade de objetos entre pessoas e observe se sobra algo.' },
        { id: '3-pular-contagem', title: 'Contagem com saltos', description: 'Conte oralmente de 2 em 2, 5 em 5 ou 10 em 10 e procure regularidades.' },
    ],
    '4º Ano': [
        { id: '4-estrategia', title: 'Explique sua estratégia', description: 'Resolva uma multiplicação sem algoritmo escrito e conte como pensou.' },
        { id: '4-combinar', title: 'Combinações reais', description: 'Escolha dois conjuntos de objetos e descubra quantas combinações diferentes são possíveis.' },
        { id: '4-inversa', title: 'Operação inversa', description: 'Crie uma multiplicação e use a divisão para conferir o resultado.' },
    ],
    '5º Ano': [
        { id: '5-precos', title: 'Preço e quantidade', description: 'Calcule o custo de várias unidades do mesmo produto usando uma estratégia mental.' },
        { id: '5-porcentagem', title: 'Porcentagem no cotidiano', description: 'Encontre 10%, 25% ou 50% de uma quantidade real e explique a estratégia.' },
        { id: '5-combinacoes', title: 'Mapa de possibilidades', description: 'Monte uma pequena tabela ou árvore de combinações para duas escolhas sucessivas.' },
    ],
    '6º Ano': [
        { id: '6-divisibilidade', title: 'Caça à divisibilidade', description: 'Escolha cinco números do cotidiano e teste critérios de divisibilidade diferentes.' },
        { id: '6-desconto', title: 'Desconto real', description: 'Escolha um preço e calcule mentalmente um desconto ou acréscimo percentual.' },
        { id: '6-expressao', title: 'Crie uma expressão', description: 'Escreva uma expressão com duas operações, resolva e explique a ordem usada.' },
    ],
};
const OFFLINE_STATUS_LABELS = {
    independent: 'Fez com autonomia', helped: 'Fez com ajuda', learning: 'Ainda aprendendo',
};
function familyMissionMarkup() {
    return FAMILY_MISSIONS[state.grade].map((mission) => {
        const current = state.offlineMissions[mission.id];
        return `<article class='offline-mission-card'><div><strong>${esc(mission.title)}</strong><p>${esc(mission.description)}</p>${current ? `<span class='offline-status current-${current}'>${OFFLINE_STATUS_LABELS[current]}</span>` : ''}</div><div class='offline-mission-actions' role='group' aria-label='Registrar ${esc(mission.title)}'>${['independent', 'helped', 'learning'].map((status) => `<button type='button' class='btn ghost offline-status-btn ${current === status ? 'selected' : ''}' data-offline-mission='${mission.id}' data-offline-status='${status}' aria-pressed='${current === status}'>${OFFLINE_STATUS_LABELS[status]}</button>`).join('')}</div></article>`;
    }).join('');
}
const on = (id, handler) => {
    const element = $(id);
    if (element)
        element.onclick = handler;
};
function say(text) {
    const settingsOpen = $('settings')?.hasAttribute('open');
    const element = settingsOpen ? $('soundNotice') : $('notice');
    if (element)
        element.textContent = text;
}
let musicAudio = null;
let voiceAudio = null;
let speechUtterance = null;
function speechAvailable() {
    return 'speechSynthesis' in window && 'SpeechSynthesisUtterance' in window;
}
function naturalVoices() {
    if (!speechAvailable())
        return [];
    const voices = window.speechSynthesis.getVoices()
        .filter((voice) => /^pt(?:-|$)/i.test(voice.lang))
        .sort((a, b) => {
        const score = (voice) => /^pt-BR$/i.test(voice.lang) ? 0 : /^pt-/i.test(voice.lang) ? 1 : 2;
        return score(a) - score(b) || a.name.localeCompare(b.name, 'pt-BR');
    });
    const seen = new Set();
    return voices.filter((voice) => {
        const key = `${voice.name}|${voice.lang}`;
        if (seen.has(key))
            return false;
        seen.add(key);
        return true;
    });
}
function selectedNaturalVoice() {
    const voices = naturalVoices();
    if (!voices.length)
        return null;
    if (!state.voice.startsWith('natural:') || state.voice === 'natural:auto') {
        return voices.find((voice) => /^pt-BR$/i.test(voice.lang)) || voices[0];
    }
    const wanted = state.voice.slice('natural:'.length);
    return voices.find((voice) => voice.name === wanted || voice.voiceURI === wanted)
        || voices.find((voice) => /^pt-BR$/i.test(voice.lang))
        || voices[0];
}
function voiceChoiceOptions() {
    const voices = naturalVoices();
    const current = state.voice || 'natural:auto';
    const naturalOptions = [
        `<option value='natural:auto' ${current === 'natural:auto' ? 'selected' : ''}>Natural automática (recomendada)</option>`,
        ...voices.map((voice) => {
            const value = `natural:${voice.name}`;
            const selected = current === value || current === `natural:${voice.voiceURI}`;
            return `<option value='${esc(value)}' ${selected ? 'selected' : ''}>${esc(voice.name)} · ${esc(voice.lang)}</option>`;
        }),
    ];
    naturalOptions.push(`<option value='local' ${current === 'local' ? 'selected' : ''}>Voz local clássica (offline)</option>`);
    return naturalOptions.join('');
}
function ensureMusic() {
    if (!musicAudio) {
        musicAudio = new Audio(MUSIC_URL);
        musicAudio.loop = true;
        musicAudio.preload = 'auto';
    }
    return musicAudio;
}
function musicVolume(duck = 1) {
    if (state.muted || !state.musicOn)
        return 0;
    return Math.max(0, Math.min(1, (state.musicLevel / 100) * duck));
}
function syncMusicVolume(duck = 1) {
    if (!musicAudio)
        return;
    musicAudio.volume = musicVolume(duck);
    if (state.muted || !state.musicOn || state.musicLevel === 0)
        musicAudio.pause();
}
async function startMusic() {
    const music = ensureMusic();
    syncMusicVolume();
    if (state.muted || !state.musicOn || state.musicLevel === 0)
        return;
    try {
        await music.play();
    }
    catch {
        // Autoplay pode exigir gesto do usuário. O próximo clique tenta novamente.
    }
}
function stopVoice() {
    if (voiceAudio) {
        voiceAudio.pause();
        voiceAudio.currentTime = 0;
        voiceAudio = null;
    }
    if (speechAvailable())
        window.speechSynthesis.cancel();
    speechUtterance = null;
    syncMusicVolume();
}
async function playLocalVoice(key) {
    const audio = new Audio(VOICE_CLIPS[key]);
    voiceAudio = audio;
    audio.preload = 'auto';
    audio.volume = Math.max(0, Math.min(1, state.voiceLevel / 100));
    const restore = () => {
        if (voiceAudio === audio)
            voiceAudio = null;
        syncMusicVolume();
    };
    audio.onended = restore;
    audio.onerror = restore;
    try {
        await audio.play();
    }
    catch {
        restore();
        say('O navegador bloqueou a reprodução automática. Toque novamente em Ouvir.');
    }
}
async function playNaturalVoice(text) {
    if (!speechAvailable())
        return false;
    return await new Promise((resolve) => {
        try {
            const utterance = new SpeechSynthesisUtterance(text);
            speechUtterance = utterance;
            const voice = selectedNaturalVoice();
            if (voice) {
                utterance.voice = voice;
                utterance.lang = voice.lang || 'pt-BR';
            }
            else {
                utterance.lang = 'pt-BR';
            }
            utterance.volume = Math.max(0, Math.min(1, state.voiceLevel / 100));
            utterance.rate = 0.93;
            utterance.pitch = 1;
            const done = (ok) => {
                if (speechUtterance === utterance)
                    speechUtterance = null;
                syncMusicVolume();
                resolve(ok);
            };
            utterance.onend = () => done(true);
            utterance.onerror = () => done(false);
            window.speechSynthesis.speak(utterance);
        }
        catch {
            resolve(false);
        }
    });
}
async function playVoice(key) {
    if (state.muted || state.voiceLevel === 0) {
        say('A voz das atividades está silenciada. Abra Som para ajustar.');
        return;
    }
    stopVoice();
    syncMusicVolume(0.24);
    if (state.voice !== 'local') {
        const spoken = await playNaturalVoice(VOICE_TEXT[key]);
        if (spoken)
            return;
    }
    await playLocalVoice(key);
}
function tone(correct = true) {
    void playVoice(correct ? 'praise' : 'retry');
}
function go(nextRoute) {
    stopVoice();
    route = nextRoute;
    render();
    document.documentElement.scrollTop = 0;
    document.body.scrollTop = 0;
    window.scrollTo({ top: 0, left: 0, behavior: 'auto' });
    requestAnimationFrame(() => $('main')?.focus({ preventScroll: true }));
}
function enter(mode) {
    intent = mode;
    if (!state.name) {
        setupStep = 1;
        go('setup');
        return;
    }
    if (mode === 'report') {
        go('report');
        return;
    }
    if (mode === 'learn') {
        if (allow())
            go('learn');
        return;
    }
    if (mode === 'map') {
        if (allow())
            go('map');
        return;
    }
    startPractice(!state.diag);
}
function settings() {
    const dialog = $('settings');
    if (!dialog)
        return;
    dialog.innerHTML = `
    <div class='dialog-head'>
      <h2>Som e conforto</h2>
      ${button('closeSound', 'Fechar', 'ghost')}
    </div>
    <label class='switch'>
      <input id='mute' type='checkbox' ${state.muted ? 'checked' : ''}>
      Silenciar todos os sons
    </label>
    <button type='button' class='sound-toggle' id='musicToggle' aria-pressed='${state.musicOn}'>${state.musicOn ? '♫ Música ligada' : '♩ Música desligada'}</button>
    <label class='field' for='musicLevel'>
      Música <output id='musicValue'>${state.musicLevel}%</output>
      <input id='musicLevel' type='range' min='0' max='100' step='5' value='${state.musicLevel}'>
    </label>
    <label class='field' for='voiceChoice'>
      Tipo de voz
      <select id='voiceChoice'>${voiceChoiceOptions()}</select>
    </label>
    <p class='micro'>As vozes naturais vêm do próprio aparelho. A opção clássica usa os áudios locais do aplicativo.</p>
    <label class='field' for='voiceLevel'>
      Voz das atividades <output id='voiceValue'>${state.voiceLevel}%</output>
      <input id='voiceLevel' type='range' min='0' max='100' step='5' value='${state.voiceLevel}'>
    </label>
    <div class='actions'>
      ${button('testMusic', 'Testar música', 'blue')}
      ${button('testVoice', '▶ Ouvir esta voz', 'ghost')}
    </div>
    <p class='micro'>Sem API paga e sem custo por uso. Se uma voz natural não estiver disponível, o app usa automaticamente a voz local offline.</p>
    <label class='switch'>
      <input id='quiet' type='checkbox' ${state.quiet ? 'checked' : ''}>
      Reduzir movimentos
    </label>
    <p id='soundNotice' role='status' aria-live='polite'></p>
  `;
    on('closeSound', () => dialog.close());
    on('musicToggle', () => {
        state.musicOn = !state.musicOn;
        save();
        settings();
        if (state.musicOn)
            void startMusic();
        else
            syncMusicVolume();
    });
    on('testMusic', () => void startMusic());
    on('testVoice', () => void playVoice('welcome'));
    const voiceChoice = $('voiceChoice');
    if (voiceChoice) {
        voiceChoice.onchange = (event) => {
            state.voice = event.target.value || 'natural:auto';
            stopVoice();
            save();
            void playVoice('welcome');
        };
    }
    const mute = $('mute');
    if (mute) {
        mute.onchange = (event) => {
            state.muted = event.target.checked;
            if (state.muted) {
                stopVoice();
                syncMusicVolume();
            }
            else {
                void startMusic();
            }
            save();
        };
    }
    const musicLevel = $('musicLevel');
    if (musicLevel) {
        musicLevel.oninput = (event) => {
            state.musicLevel = Number(event.target.value);
            const output = $('musicValue');
            if (output)
                output.textContent = `${state.musicLevel}%`;
            syncMusicVolume();
            save();
        };
    }
    const voiceLevel = $('voiceLevel');
    if (voiceLevel) {
        voiceLevel.oninput = (event) => {
            state.voiceLevel = Number(event.target.value);
            state.volume = state.voiceLevel / 100;
            const output = $('voiceValue');
            if (output)
                output.textContent = `${state.voiceLevel}%`;
            if (voiceAudio)
                voiceAudio.volume = Math.max(0, Math.min(1, state.voiceLevel / 100));
            save();
        };
    }
    const quiet = $('quiet');
    if (quiet) {
        quiet.onchange = (event) => {
            state.quiet = event.target.checked;
            document.body.classList.toggle('quiet', state.quiet);
            save();
        };
    }
    if (!dialog.open)
        dialog.showModal();
}
let installer = null;
window.addEventListener('beforeinstallprompt', (event) => {
    event.preventDefault();
    installer = event;
});
async function install() {
    if (installer) {
        await installer.prompt();
        await installer.userChoice;
        installer = null;
        return;
    }
    say('Para instalar, use Instalar aplicativo ou Adicionar à tela inicial no menu do navegador. No iPhone/iPad, abra no Safari e use Compartilhar.');
}
function shell(content) {
    document.body.classList.toggle('quiet', state.quiet);
    document.body.classList.toggle('grade-mature', state.grade === '5º Ano' || state.grade === '6º Ano');
    document.body.dataset.grade = String(GRADE_ORDER.indexOf(state.grade) + 3);
    const currentGrade = GRADE_META[state.grade];
    app.innerHTML = `
    <a class='skip-link' href='#main'>Ir ao conteúdo</a>
    ${route === 'splash'
        ? ''
        : `<header class='quality-header'>
            <div class='brand-lockup'><img src='./resources/branding/logo-tabuada.webp' alt='Intelectus Tabuada' class='header-logo brand-logo-image'></div>
            ${state.name ? `<div class='grade-chip'>${gradeIcon(state.grade, '', 'grade-inline-icon')} ${state.grade} · ${currentGrade.title}</div>` : ''}
            <nav aria-label='Navegação principal'>
              ${navButton('homeBtn', 'Início', 'ghost', route === 'home')}
              ${navButton('mapBtn', 'Evolução', 'blue', ['map', 'placement', 'placementSummary', 'miniGame', 'miniSummary', 'boss', 'bossSummary'].includes(route))}
              ${navButton('learnBtn', 'Aprender', 'ghost', ['learn', 'practice', 'practiceSummary'].includes(route))}
              ${navButton('progBtn', 'Progresso', 'ghost', route === 'report')}
              ${button('soundBtn', 'Som', 'ghost')}
            </nav>
          </header>`}
    <p id='storageStatus' class='storage-warning' role='alert' ${storageWarning ? '' : 'hidden'}>${esc(storageWarning)}</p>
    <main id='main' tabindex='-1'>${content}</main>
    <p id='notice' class='notice' role='status' aria-live='polite'></p>
    <footer class='footer'>
      <strong>Intelectus Soluções Pedagógicas — percurso de raciocínio multiplicativo do 3º ao 6º ano, com referência à <span>BNCC</span>.</strong>
      <p>Intelectus Soluções Pedagógicas — Todos os direitos reservados.</p>
      <div class='footer-tools'>
        ${button('familyBtn', 'Área do responsável', 'ghost')}
        ${button('installBtn', 'Instalar aplicativo', 'ghost')}
        ${route === 'splash' ? button('soundBtn', 'Som', 'ghost') : ''}
      </div>
      <small>Versão ${RELEASE} · Progresso neste dispositivo · sem infraestrutura paga obrigatória</small>
    </footer>
    <dialog id='settings' aria-label='Som e conforto'></dialog>
  `;
    on('homeBtn', () => go(state.name ? 'home' : 'splash'));
    on('mapBtn', () => enter('map'));
    on('learnBtn', () => enter('learn'));
    on('progBtn', () => go('report'));
    on('soundBtn', settings);
    on('familyBtn', () => go('family'));
    on('installBtn', () => void install());
}
function render() {
    if (route === 'splash')
        splash();
    else if (route === 'setup')
        setup();
    else if (route === 'home')
        home();
    else if (route === 'map')
        evolutionMap();
    else if (route === 'placement')
        placement();
    else if (route === 'placementSummary')
        placementSummary();
    else if (route === 'learn')
        learn();
    else if (route === 'practice')
        practice();
    else if (route === 'practiceSummary')
        practiceSummary();
    else if (route === 'miniGame')
        miniGame();
    else if (route === 'miniSummary')
        miniSummary();
    else if (route === 'boss')
        bossGame();
    else if (route === 'bossSummary')
        bossSummary();
    else if (route === 'collection')
        collection();
    else if (route === 'family')
        family();
    else
        report();
}
function splash() {
    shell(`
    <section class='splash-stage splash-cover' aria-label='Aventura Intelectus Tabuada'>
      <h1 class='sr-only'>Intelectus Tabuada: aprender, jogar e evoluir</h1>
      <div class='splash-cover-copy'>
        <strong>Do 3º ao 6º ano</strong>
        <span>Tabuada · cálculo · raciocínio matemático</span>
      </div>
      <div class='splash-modes'>
        <button type='button' class='mode-btn learn' data-enter='learn'><span aria-hidden='true'>📖</span><b>Aprender</b></button>
        <button type='button' class='mode-btn practice' data-enter='map'><span aria-hidden='true'>🎮</span><b>Jogar</b></button>
        <button type='button' class='mode-btn evolve' data-enter='report'><span aria-hidden='true'>🏆</span><b>Evoluir</b></button>
      </div>
    </section>
    <div class='positioning-strip'>
      <strong>3º ao 6º ano</strong>
      <span>Do concreto ao abstrato</span>
      <span>Games por habilidade</span>
      <span>Habilidades de referência da BNCC</span>
    </div>
  `);
    document.querySelectorAll('[data-enter]').forEach((element) => {
        element.onclick = () => { void startMusic(); enter(element.dataset.enter || 'map'); };
    });
}
function setup() {
    const stepLabel = `PASSO ${setupStep} DE 5`;
    if (setupStep === 1) {
        shell(`
      <section class='card onboarding'>
        <div class='setup-progress'>${[1, 2, 3, 4, 5].map((step) => `<i class='${step <= setupStep ? 'on' : ''}'></i>`).join('')}</div>
        <span class='eyebrow'>${stepLabel}</span>
        <h1>Qual é o seu nome?</h1>
        <p class='lead'>Um apelido já é suficiente. Nada de e-mail ou nome completo.</p>
        <form id='profileForm' novalidate>
          <div class='field'>
            <label for='nm'>Nome ou apelido</label>
            <input id='nm' maxlength='30' autocomplete='off' value='${esc(state.name)}' placeholder='Ex.: Alice' aria-describedby='nameError'>
          </div>
          <p id='nameError' role='alert'></p>
          <div class='actions'><button class='btn primary' type='submit'>Continuar →</button></div>
        </form>
      </section>
    `);
        const form = $('profileForm');
        if (form)
            form.onsubmit = (event) => {
                event.preventDefault();
                const input = $('nm');
                const name = input?.value.trim() || '';
                if (!name) {
                    const error = $('nameError');
                    if (error)
                        error.textContent = 'Digite um nome ou apelido para continuar.';
                    input?.focus();
                    return;
                }
                state.name = name.slice(0, 30);
                save();
                setupStep = 2;
                render();
            };
        return;
    }
    if (setupStep === 2) {
        shell(`
      <section class='card onboarding'>
        <div class='setup-progress'>${[1, 2, 3, 4, 5].map((step) => `<i class='${step <= setupStep ? 'on' : ''}'></i>`).join('')}</div>
        <span class='eyebrow'>${stepLabel}</span>
        <h1>Em que ano você está?</h1>
        <p class='lead'>A trilha ajusta os desafios ao 3º, 4º, 5º ou 6º ano.</p>
        <div class='grade-choice-grid'>${GRADE_ORDER.map((grade) => `<button type='button' class='grade-choice ${grade === state.grade ? 'sel' : ''}' data-grade='${grade}' aria-pressed='${grade === state.grade}'>${gradeIcon(grade, '', 'grade-choice-icon')}<b>${grade}</b><small>${GRADE_META[grade].title}</small></button>`).join('')}</div>
        <div class='actions'>${button('back', '← Voltar', 'ghost')}${button('next', 'Continuar →')}</div>
      </section>
    `);
        document.querySelectorAll('[data-grade]').forEach((element) => {
            element.onclick = () => {
                const grade = element.dataset.grade;
                if (!GRADE_ORDER.includes(grade))
                    return;
                if (state.grade !== grade) {
                    state.grade = grade;
                    state.diag = false;
                    state.placement = state.placements[grade] || null;
                    practiceSession = null;
                    miniSession = null;
                    bossSession = null;
                    placementSession = null;
                }
                save();
                render();
                document.querySelector(`[data-grade="${state.grade}"]`)?.focus({ preventScroll: true });
            };
        });
        on('back', () => { setupStep = 1; render(); });
        on('next', () => { setupStep = 3; render(); });
        return;
    }
    if (setupStep === 3) {
        shell(`
      <section class='card onboarding'>
        <div class='setup-progress'>${[1, 2, 3, 4, 5].map((step) => `<i class='${step <= setupStep ? 'on' : ''}'></i>`).join('')}</div>
        <span class='eyebrow'>${stepLabel}</span>
        <h1>Escolha seu personagem</h1>
        <p class='lead'>Os mesmos personagens da família Intelectus acompanham sua aventura.</p>
        <div class='character-grid'>${avatars.map((item) => characterCard(item, 'avatar', state.avatar === item.id)).join('')}</div>
        <div class='actions'>${button('back', '← Voltar', 'ghost')}${button('next', 'Continuar →')}</div>
      </section>
    `);
        document.querySelectorAll('[data-avatar]').forEach((element) => {
            element.onclick = () => {
                state.avatar = element.dataset.avatar || 'raposa';
                save();
                render();
                document.querySelector(`[data-avatar="${state.avatar}"]`)?.focus({ preventScroll: true });
            };
        });
        on('back', () => { setupStep = 2; render(); });
        on('next', () => { setupStep = 4; render(); });
        return;
    }
    if (setupStep === 4) {
        shell(`
      <section class='card onboarding'>
        <div class='setup-progress'>${[1, 2, 3, 4, 5].map((step) => `<i class='${step <= setupStep ? 'on' : ''}'></i>`).join('')}</div>
        <span class='eyebrow'>${stepLabel}</span>
        <h1>Escolha seu guia</h1>
        <p class='lead'>Profª Lia, Profª Aline, Prof. Daniel ou Prof. Caio: o mesmo time pedagógico dos demais aplicativos.</p>
        <div class='character-grid guide-grid'>${guides.map((item) => characterCard(item, 'guide', state.guide === item.id)).join('')}</div>
        <div class='actions'>${button('back', '← Voltar', 'ghost')}${button('next', 'Som da aventura →')}</div>
      </section>
    `);
        document.querySelectorAll('[data-guide]').forEach((element) => {
            element.onclick = () => {
                state.guide = element.dataset.guide || 'lia';
                save();
                render();
                document.querySelector(`[data-guide="${state.guide}"]`)?.focus({ preventScroll: true });
            };
        });
        on('back', () => { setupStep = 3; render(); });
        on('next', () => { setupStep = 5; render(); });
        return;
    }
    shell(`
    <section class='card onboarding'>
      <div class='setup-progress'>${[1, 2, 3, 4, 5].map((step) => `<i class='${step <= setupStep ? 'on' : ''}'></i>`).join('')}</div>
      <span class='eyebrow'>${stepLabel}</span>
      <h1>Som da aventura</h1>
      <p class='lead'>Escolha uma voz mais natural no próprio aparelho, sem serviço pago em runtime.</p>
      <div class='sound-card'>
        <button type='button' class='sound-toggle' id='musicSetup' aria-pressed='${state.musicOn}'>${state.musicOn ? '♫ Música ligada' : '♩ Música desligada'}</button>
        <label class='sound-row' for='musicSetupLevel'><span>Música</span><input id='musicSetupLevel' type='range' min='0' max='100' step='5' value='${state.musicLevel}'><output id='musicSetupOut'>${state.musicLevel}%</output></label>
        <label class='field' for='voiceSetupChoice'><span>Escolha da voz</span><select id='voiceSetupChoice'>${voiceChoiceOptions()}</select></label>
        <label class='sound-row' for='voiceSetupLevel'><span>Voz das atividades</span><input id='voiceSetupLevel' type='range' min='0' max='100' step='5' value='${state.voiceLevel}'><output id='voiceSetupOut'>${state.voiceLevel}%</output></label>
        <div class='actions'>${button('testSetupVoice', '▶ Ouvir esta voz', 'ghost')}</div>
        <p class='micro'>A voz é independente do guia visual. Você poderá trocá-la depois em Som e conforto.</p>
      </div>
      ${portalEntitled() ? `<div class='trial-box'><strong>Acesso autorizado</strong><p>Sua licença já foi validada pela Área do Cliente.</p></div>` : `<div class='trial-box'><strong>Período de experimentação</strong><p>O responsável pode acompanhar o status do acesso na Área da Família.</p></div>`}
      <div class='actions'>${button('back', '← Voltar', 'ghost')}${button('done', portalEntitled() ? 'Salvar e continuar' : trial() ? 'Salvar e continuar' : 'Iniciar meus 7 dias')}</div>
    </section>
  `);
    on('musicSetup', () => {
        state.musicOn = !state.musicOn;
        save();
        render();
        if (state.musicOn)
            void startMusic();
        else
            syncMusicVolume();
    });
    const musicLevel = $('musicSetupLevel');
    if (musicLevel)
        musicLevel.oninput = (event) => {
            state.musicLevel = Number(event.target.value);
            const output = $('musicSetupOut');
            if (output)
                output.textContent = `${state.musicLevel}%`;
            syncMusicVolume();
            save();
        };
    const voiceSetupChoice = $('voiceSetupChoice');
    if (voiceSetupChoice)
        voiceSetupChoice.onchange = (event) => {
            state.voice = event.target.value || 'natural:auto';
            stopVoice();
            save();
            void playVoice('welcome');
        };
    const voiceLevel = $('voiceSetupLevel');
    if (voiceLevel)
        voiceLevel.oninput = (event) => {
            state.voiceLevel = Number(event.target.value);
            state.volume = state.voiceLevel / 100;
            const output = $('voiceSetupOut');
            if (output)
                output.textContent = `${state.voiceLevel}%`;
            save();
        };
    on('testSetupVoice', () => void playVoice('welcome'));
    on('back', () => { setupStep = 4; render(); });
    on('done', () => {
        save();
        void startMusic();
        if (!allow(true))
            return;
        if (intent === 'learn')
            go('learn');
        else if (intent === 'report')
            go('report');
        else if (intent === 'map')
            go('map');
        else
            startPlacement();
    });
}
function stat(value, label) {
    return `<div class='stat'><b>${value}</b><small>${label}</small></div>`;
}
function skillStars(skillId) {
    const progress = getSkillProgress(state, skillId);
    return `${'★'.repeat(progress.stars)}${'☆'.repeat(3 - progress.stars)}`;
}
function currentPlacement() {
    return state.placements[state.grade] || (state.placement?.grade === state.grade ? state.placement : null);
}
function recommendedSkillForGrade() {
    const gradeSkills = skillsForGrade(state.grade);
    const placement = currentPlacement();
    if (placement) {
        const placed = findSkill(placement.skillId);
        if (placed?.grade === state.grade)
            return placed;
    }
    return gradeSkills
        .slice()
        .sort((a, b) => {
        const pa = getSkillProgress(state, a.id);
        const pb = getSkillProgress(state, b.id);
        return pa.stars - pb.stars || pa.played - pb.played;
    })[0];
}
function missionCardsMarkup() {
    return missionsForGrade(state, state.grade)
        .map((mission) => {
        const percent = mission.target ? Math.min(100, Math.round((mission.current / mission.target) * 100)) : 0;
        return `<article class='mission-card ${mission.done ? 'done' : ''}'><span class='mission-icon'>${mission.done ? '✅' : mission.icon}</span><div><strong>${mission.title}</strong><p>${mission.description}</p><progress class='mission-progress semantic-progress' value='${percent}' max='100' aria-label='Progresso da missão: ${percent}%'></progress><small>${mission.done ? 'Concluída' : `${mission.current}/${mission.target}`}</small></div></article>`;
    })
        .join('');
}
function relicsMarkup() {
    return collectiblesForGrade(state, state.grade)
        .map((item) => `<article class='relic-card ${item.unlocked ? 'unlocked' : 'locked'}'><span>${item.unlocked ? item.icon : '❔'}</span><b>${item.unlocked ? item.title : 'Relíquia bloqueada'}</b><small>${item.unlocked ? item.description : 'Continue as missões do capítulo para descobrir.'}</small></article>`)
        .join('');
}
function home() {
    const m = metrics(state);
    const meta = GRADE_META[state.grade];
    const recommended = recommendedSkillForGrade();
    const placementReady = Boolean(currentPlacement());
    const story = STORIES[state.grade];
    const currentMissions = missionsForGrade(state, state.grade);
    const missionDone = currentMissions.filter((mission) => mission.done).length;
    const relics = collectiblesForGrade(state, state.grade);
    const unlockedRelics = relics.filter((item) => item.unlocked).length;
    const finalBoss = BOSSES[state.grade];
    const canBoss = bossUnlocked(state, state.grade);
    const clearedBoss = bossCompleted(state, state.grade);
    const avatar = avatarChoice(state.avatar);
    shell(`
    <section class='card welcome-card grade-${GRADE_ORDER.indexOf(state.grade) + 3}'>
      <div>
        <span class='eyebrow'>SUA JORNADA · ${state.grade}</span>
        <h1>Olá, ${esc(state.name)}!</h1>
        <p class='lead'>${meta.subtitle}</p>
      </div>
      <div class='hero-grade-emblem'>${gradeIcon(state.grade, '', 'grade-emblem-icon')}<img src='${avatar.src}' alt='${esc(avatar.name)}'></div>
    </section>

    ${state.migrated
        ? `<div class='migration-note'><strong>Trilha atualizada.</strong> O Intelectus Tabuada agora trabalha do 3º ao 6º ano. Seu histórico anterior foi preservado e o perfil foi encaixado na nova progressão.</div>`
        : ''}

    <div class='dashboard-modes dashboard-modes-rc4'>
      ${button('evolution', '🗺️ Mapa de Evolução', 'blue')}
      ${button('mainMission', placementReady ? '🧭 Reavaliar meu ponto de partida' : '🧭 Descobrir meu ponto de partida')}
      ${button('quick', '⚡ Missão rápida', 'orange')}
      ${button('collectionBtn', '🎒 Conquistas e coleção', 'ghost')}
    </div>

    <section class='card story-card'>
      <div class='story-emblem' aria-hidden='true'>${story.icon}</div>
      <div class='story-copy'>
        <span class='eyebrow'>CAPÍTULO · ${state.grade}</span>
        <h2>${story.title}</h2>
        <p>${story.intro}</p>
        <strong>${story.goal}</strong>
        <progress class='chapter-meter semantic-progress' value='${missionDone}' max='${currentMissions.length}' aria-label='${missionDone} de ${currentMissions.length} missões concluídas'></progress>
        <small>${missionDone}/${currentMissions.length} missões concluídas · ${unlockedRelics}/${relics.length} relíquias encontradas</small>
      </div>
      <div class='story-boss-box ${clearedBoss ? 'cleared' : canBoss ? 'ready' : 'locked'}'>
        <span>${finalBoss.icon}</span>
        <b>${finalBoss.title}</b>
        <small>${clearedBoss ? 'Chefão superado' : canBoss ? 'Desafio liberado' : 'Libera com 1 estrela em cada habilidade'}</small>
        ${canBoss || clearedBoss ? `<button type='button' class='btn ${clearedBoss ? 'ghost' : 'primary'}' id='homeBoss'>${clearedBoss ? 'Jogar novamente' : 'Enfrentar chefão'}</button>` : ''}
      </div>
    </section>

    ${recommended
        ? `<section class='card recommendation-card'>
            <div>
              <span class='eyebrow'>PRÓXIMO PASSO RECOMENDADO</span>
              <h2>${skillIcon(recommended, '', 'heading-pictogram')} ${recommended.title}</h2>
              <p>${recommended.description}</p>
              <div class='bncc-row'>${recommended.bncc.map((code) => `<span class='${recommended.partialBncc?.includes(code) ? 'partial' : 'central'}'>${code} · ${recommended.partialBncc?.includes(code) ? 'parcial' : 'central'}</span>`).join('')}</div>
            </div>
            ${button('recommended', `Jogar · ${skillStars(recommended.id)}`)}
          </section>`
        : ''}

    <section class='card'>
      <div class='stats'>
        ${stat(state.xp, 'XP conquistados')}
        ${stat(m.skillStars, 'Estrelas de habilidade')}
        ${stat(`${m.skillAccuracy}%`, 'Acertos nos games')}
        ${stat(`${unlockedRelics}/${relics.length}`, 'Relíquias do capítulo')}
      </div>
    </section>

    <section class='card journey-overview'>
      <div class='section-head'>
        <div>
          <span class='eyebrow'>EVOLUÇÃO 3º → 6º ANO</span>
          <h2>Uma trilha que cresce com o raciocínio</h2>
        </div>
        ${button('openMap', 'Ver mapa completo', 'ghost')}
      </div>
      <div class='grade-track'>
        ${GRADE_ORDER.map((grade) => {
        const item = GRADE_META[grade];
        const active = grade === state.grade;
        return `<div class='grade-node ${active ? 'active' : ''}'>${gradeIcon(grade, '', 'grade-node-icon')}<b>${grade}</b><small>${item.title}</small></div>`;
    }).join('')}
      </div>
    </section>

    ${guideCoachMarkup('Você pode rever habilidades anteriores e avançar sem cronômetro punitivo.')}
  `);
    on('evolution', () => go('map'));
    on('openMap', () => go('map'));
    on('mainMission', startPlacement);
    on('quick', () => startPractice(false, 6));
    on('collectionBtn', () => go('collection'));
    on('homeBoss', startBoss);
    if (recommended)
        on('recommended', () => startMini(recommended.id, recommended.games[0]));
}
function evolutionMap() {
    if (expired()) {
        go('family');
        return;
    }
    const meta = GRADE_META[state.grade];
    const gradeSkills = skillsForGrade(state.grade);
    const recommended = recommendedSkillForGrade();
    const placementReady = Boolean(currentPlacement());
    const story = STORIES[state.grade];
    const finalBoss = BOSSES[state.grade];
    const canBoss = bossUnlocked(state, state.grade);
    const clearedBoss = bossCompleted(state, state.grade);
    shell(`
    <section class='card evolution-hero'>
      <div>
        <span class='eyebrow'>MAPA DE EVOLUÇÃO · ${state.grade}</span>
        <h1>${gradeIcon(state.grade, '', 'heading-pictogram')} ${meta.title}</h1>
        <p class='lead'>${meta.subtitle}</p>
      </div>
      <div class='evolution-legend'>
        <span>☆ iniciar</span><span>★ em construção</span><span>★★ avançando</span><span>★★★ consolidando</span>
      </div>
    </section>

    <section class='card chapter-map-card'>
      <div class='chapter-map-head'>
        <div><span class='story-place'>${story.icon}</span><div><span class='eyebrow'>NARRATIVA DO ANO</span><h2>${story.title}</h2><p>${story.intro}</p></div></div>
        <div class='actions'>${button('mapCollection', '🎒 Abrir coleção', 'ghost')}${canBoss || clearedBoss ? button('mapBoss', `${finalBoss.icon} ${clearedBoss ? 'Rejogar chefão' : 'Chefão liberado'}`, clearedBoss ? 'ghost' : 'primary') : ''}</div>
      </div>
      <h3>Missões do capítulo</h3>
      <div class='mission-grid'>${missionCardsMarkup()}</div>
      <h3>Relíquias</h3>
      <div class='relic-grid compact'>${relicsMarkup()}</div>
    </section>

    <section class='grade-switcher' aria-label='Anos da progressão'>
      ${GRADE_ORDER.map((grade) => `<button type='button' class='grade-tab ${grade === state.grade ? 'active' : ''}' data-grade='${grade}'>${gradeIcon(grade, '', 'grade-tab-icon')}<b>${grade}</b><small>${GRADE_META[grade].title}</small></button>`).join('')}
    </section>

    <section class='skill-path'>
      ${gradeSkills
        .map((skill, index) => {
        const progress = getSkillProgress(state, skill.id);
        const accuracy = progress.played ? Math.round((progress.correct / progress.played) * 100) : 0;
        return `<article class='skill-card level-${skill.level} ${recommended?.id === skill.id ? 'recommended-skill' : ''}'>
            <div class='skill-step'>${index + 1}</div>
            <div class='skill-main'>
              <div class='skill-title-row'>${skillIcon(skill, '', 'skill-icon-img')}<div><h2>${skill.title}</h2>${recommended?.id === skill.id ? `<span class='recommended-badge'>Ponto de partida sugerido</span>` : ''}<div class='bncc-row'>${skill.bncc.map((code) => `<span class='${skill.partialBncc?.includes(code) ? 'partial' : 'central'}'>${code} · ${skill.partialBncc?.includes(code) ? 'parcial' : 'central'}</span>`).join('')}</div></div></div>
              <p>${skill.description}</p>
              <div class='skill-progress-line'>
                <strong>${skillStars(skill.id)}</strong>
                <span>${progress.played} desafios · ${accuracy}% de acertos</span>
              </div>
              <div class='game-cards'>
                ${skill.games
            .map((gameId) => {
            const game = GAMES[gameId];
            return `<button type='button' class='game-card' data-skill='${skill.id}' data-game='${gameId}'>${gameIcon(gameId, '', 'game-card-icon')}<b>${game.title}</b><small>${game.short}</small></button>`;
        })
            .join('')}
              </div>
            </div>
          </article>`;
    })
        .join('')}
    </section>

    <section class='card placement-card'>
      <div>
        <span class='eyebrow'>DIAGNÓSTICO DE HABILIDADES</span>
        <h2>${placementReady ? 'Ponto de partida já identificado' : 'Descubra onde começar'}</h2>
        <p>${placementReady && recommended ? `A última sondagem recomenda começar por <strong>${recommended.title}</strong>.` : 'Uma sondagem curta percorre as habilidades centrais do ano escolar. Ela não dá nota, não gera XP e não interfere nas estrelas de prática.'}</p>
      </div>
      <div class='actions'>${button('placementBtn', placementReady ? 'Refazer sondagem' : 'Fazer sondagem', 'blue')}</div>
    </section>

    <section class='card fluency-card'>
      <div>
        <span class='eyebrow'>FLUÊNCIA DA TABUADA</span>
        <h2>Treino adaptativo continua dentro da jornada</h2>
        <p>O motor prioriza fatos ainda não explorados, dificuldades e revisões espaçadas. A criança pode usar pistas sem transformar ajuda em falsa consolidação.</p>
      </div>
      <div class='actions'>${button('adaptive', state.diag ? 'Treino adaptativo' : 'Fazer diagnóstico')}${button('lab', 'Laboratório visual', 'ghost')}</div>
    </section>
  `);
    document.querySelectorAll('[data-grade]').forEach((element) => {
        element.onclick = () => {
            const grade = element.dataset.grade;
            if (!GRADE_ORDER.includes(grade))
                return;
            if (grade === state.grade)
                return;
            if (!confirm(`Mudar a trilha ativa para ${grade}? O histórico anterior será preservado.`))
                return;
            state.grade = grade;
            state.diag = false;
            state.placement = state.placements[grade] || null;
            practiceSession = null;
            miniSession = null;
            bossSession = null;
            placementSession = null;
            save();
            render();
        };
    });
    document.querySelectorAll('[data-skill][data-game]').forEach((element) => {
        element.onclick = () => startMini(element.dataset.skill || '', element.dataset.game);
    });
    on('placementBtn', startPlacement);
    on('mapCollection', () => go('collection'));
    on('mapBoss', startBoss);
    on('adaptive', () => startPractice(!state.diag));
    on('lab', () => go('learn'));
}
function groupsMarkup(a, b) {
    if (a === 0)
        return `<p class='empty-quantity'>Nenhum grupo: não há elementos para contar.</p>`;
    return `<div class='group-board' role='img' aria-label='${a} grupos com ${b} elementos em cada'>${Array.from({ length: a }, (_, index) => `<div class='count-group' aria-hidden='true'><span class='group-number'>${index + 1}</span><div class='tokens'>${b
        ? Array.from({ length: b }, () => `<i class='token'></i>`).join('')
        : `<span class='empty-group'>vazio</span>`}</div></div>`).join('')}</div>`;
}
function labMarkup() {
    return `
    <div class='learn-equation' aria-live='polite'>${learnA} × ${learnB} = ${learnA * learnB}</div>
    ${groupsMarkup(learnA, learnB)}
    <div class='concept-card'>
      <strong>Grupos iguais → adição → multiplicação</strong>
      <p class='sum-line'>${sum(learnA, learnB)} = ${learnA * learnB}</p>
      <p>${strategy(learnA, learnB)}</p>
      <p>A ordem muda; o produto não: ${learnA} × ${learnB} = ${learnB} × ${learnA}.</p>
    </div>
  `;
}
function learn() {
    if (expired()) {
        go('family');
        return;
    }
    if (!GRADES[state.grade].includes(learnA))
        learnA = GRADES[state.grade][0];
    shell(`
    <section class='card learning-card'>
      <span class='eyebrow'>LABORATÓRIO DA MULTIPLICAÇÃO</span>
      <h1>Veja a tabuada acontecer</h1>
      <p class='lead'>Antes de automatizar, a criança pode enxergar os grupos, a soma de parcelas iguais e a estratégia de cálculo.</p>
      <div class='learn-controls'>
        <div class='field'>
          <label for='learnA'>Quantidade de grupos</label>
          <select id='learnA'>${GRADES[state.grade].map((a) => `<option value='${a}' ${a === learnA ? 'selected' : ''}>${a} ${a === 1 ? 'grupo' : 'grupos'}</option>`).join('')}</select>
        </div>
        <div class='field'>
          <label for='learnB'>Elementos por grupo: <output id='bValue'>${learnB}</output></label>
          <input id='learnB' type='range' min='0' max='10' value='${learnB}'>
        </div>
      </div>
      <div id='learnBoard'>${labMarkup()}</div>
      <div class='actions'>
        ${button('learnPractice', 'Praticar esta tabuada')}
        ${button('listenLearn', 'Ouvir explicação', 'blue')}
        ${button('backMap', 'Voltar ao mapa', 'ghost')}
      </div>
      <p class='micro'>Explorar com a resposta visível não aumenta o indicador de consolidação.</p>
    </section>
  `);
    const select = $('learnA');
    if (select) {
        select.onchange = (event) => {
            learnA = Number(event.target.value);
            render();
            $('learnA')?.focus({ preventScroll: true });
        };
    }
    const range = $('learnB');
    if (range) {
        const update = (event) => {
            learnB = Math.max(0, Math.min(10, Math.round(Number(event.target.value) || 0)));
            const output = $('bValue');
            if (output)
                output.textContent = String(learnB);
            const board = $('learnBoard');
            if (board)
                board.innerHTML = labMarkup();
        };
        range.oninput = update;
        range.onchange = update;
    }
    on('learnPractice', () => startPractice(false, 8, learnA));
    on('listenLearn', () => void playVoice('learn'));
    on('backMap', () => go('map'));
}
function startPractice(diag = false, len, only) {
    if (!state.name) {
        intent = 'practice';
        setupStep = 1;
        go('setup');
        return;
    }
    if (!allow())
        return;
    practiceSession = {
        diag,
        len: len || (diag ? 12 : 12),
        only,
        round: 0,
        used: [],
        q: question(state, 0, diag, only),
        phase: 'question',
        helped: false,
        feedback: '',
        result: '',
        independent: 0,
        recoveries: 0,
        startxp: state.xp,
    };
    go('practice');
}
function practiceHint(q) {
    if (q.kind === 'missing') {
        return `Procure o número que, multiplicado por ${q.a}, resulta em ${q.a * q.b}.`;
    }
    if (q.kind === 'swap')
        return 'Na multiplicação, trocar a ordem dos fatores mantém o produto.';
    return strategy(q.a, q.b);
}
function practice() {
    if (!practiceSession) {
        go('home');
        return;
    }
    const session = practiceSession;
    const q = session.q;
    const renderedPhase = session.phase;
    const guardedSubmit = (raw) => {
        if (practiceSession === session && session.q === q && session.phase === renderedPhase)
            submitPractice(raw);
    };
    const visual = q.kind === 'groups'
        ? groupsMarkup(q.a, q.b)
        : q.kind === 'repeated'
            ? `<div class='concept-card sum-line'>${sum(q.a, q.b)} = ?</div>`
            : '';
    shell(`
    <section class='card game quality-game'>
      <div class='gamehead'>
        <span class='eyebrow'>${session.diag ? 'PONTO DE PARTIDA' : 'FLUÊNCIA ADAPTATIVA'}</span>
        <div class='gamehead-meta'>${sessionGuideMarkup()}<strong>Questão ${session.round + 1} de ${session.len}</strong></div>
      </div>
      <progress class='mission-progress' value='${session.round}' max='${session.len}' aria-label='Progresso da missão'></progress>
      <div class='question-content'>
        <h1 class='game-prompt'>${prompt(q)}</h1>
        ${visual}
        <div class='equation' aria-label='${esc(equation(q).replace(/×/g, 'vezes').replace(/\?/g, 'número desconhecido'))}'>${equation(q)}</div>
        ${session.helped
        ? `<div class='hint guide-hint'><img src='${guideChoice(state.guide).src}' alt='' aria-hidden='true'><div><strong>${esc(guideName())}</strong><p>${esc(practiceHint(q))}</p><small>Esta resposta será registrada com apoio.</small></div></div>`
        : ''}
        <div id='answerarea'>
          ${session.phase === 'done'
        ? ''
        : q.kind === 'mc'
            ? `<div class='answers'>${q.options.map((value) => `<button type='button' class='answer' data-answer='${value}'>${value}</button>`).join('')}</div>`
            : `<form id='answerForm' class='inputline' novalidate><label class='sr-only' for='answer'>Sua resposta</label><input id='answer' type='text' inputmode='numeric' pattern='[0-9]*' maxlength='3' autocomplete='off' aria-describedby='inputError' placeholder='Resposta'><button class='btn primary' type='submit'>Responder</button></form>`}
        </div>
        <p id='inputError' class='input-error' role='alert'></p>
        <div id='feedback' class='feedback ${session.result}' role='status' aria-live='polite'>${esc(session.feedback)}</div>
        <div class='actions game-actions'>
          ${session.phase === 'done' ? button('nextQuestion', session.round + 1 === session.len ? 'Ver minha conquista' : 'Próxima questão →') : button('help', 'Quero uma pista', 'ghost')}
          ${button('readQuestion', 'Ouvir orientação', 'blue')}
        </div>
        <p class='micro'>Sem cronômetro punitivo. O objetivo é aprender a estratégia e ganhar fluência.</p>
      </div>
    </section>
  `);
    document.querySelectorAll('[data-answer]').forEach((element) => {
        element.onclick = () => guardedSubmit(element.dataset.answer || '');
    });
    const form = $('answerForm');
    if (form) {
        form.onsubmit = (event) => {
            event.preventDefault();
            guardedSubmit($('answer')?.value || '');
        };
    }
    on('help', () => {
        if (practiceSession !== session || session.phase === 'done')
            return;
        session.helped = true;
        practice();
    });
    on('readQuestion', () => void playVoice('practice'));
    on('nextQuestion', () => {
        if (practiceSession !== session || session.phase !== 'done')
            return;
        session.used.push(q.id);
        session.round += 1;
        if (session.round >= session.len) {
            if (session.diag)
                state.diag = true;
            save();
            go('practiceSummary');
            return;
        }
        session.q = question(state, session.round, session.diag, session.only, session.used);
        session.phase = 'question';
        session.helped = false;
        session.feedback = '';
        session.result = '';
        practice();
        $('main')?.focus({ preventScroll: true });
    });
}
function submitPractice(raw) {
    if (expired()) {
        go('family');
        return;
    }
    const session = practiceSession;
    if (!session || session.phase === 'done')
        return;
    const value = raw.trim();
    if (!/^\d{1,3}$/.test(value) || Number(value) > 200) {
        const error = $('inputError');
        if (error)
            error.textContent = 'Digite um número inteiro de 0 a 200.';
        $('answer')?.focus();
        return;
    }
    const q = session.q;
    const ok = Number(value) === q.expected;
    if (session.phase === 'question') {
        record(state, q, ok, session.helped);
        if (ok) {
            if (session.helped) {
                session.recoveries += 1;
                session.feedback = 'Você conseguiu com apoio! +4 XP.';
                session.result = 'help';
            }
            else {
                session.independent += 1;
                session.feedback = 'Você acertou sem pista! +12 XP.';
                session.result = 'good';
            }
            session.phase = 'done';
            tone();
        }
        else {
            session.phase = 'retry';
            session.helped = true;
            session.feedback = 'Ainda não. Use a pista e tente mais uma vez.';
            session.result = 'review';
            tone(false);
        }
    }
    else {
        session.phase = 'done';
        if (ok) {
            recover(state, q);
            session.recoveries += 1;
            session.feedback = 'Você conseguiu com a estratégia! +4 XP.';
            session.result = 'help';
            tone();
        }
        else {
            session.feedback = `Vamos aprender juntos: o número que faltava é ${q.expected}. ${q.a} × ${q.b} = ${q.a * q.b}.`;
            session.result = 'review';
            tone(false);
        }
    }
    save();
    practice();
    $('feedback')?.scrollIntoView({ block: 'nearest', behavior: 'auto' });
}
function practiceSummary() {
    if (!practiceSession) {
        go('home');
        return;
    }
    const session = practiceSession;
    shell(`
    <section class='card celebration'>
      <span class='celebration-icon' aria-hidden='true'>🌟</span>
      <span class='eyebrow'>MISSÃO CONCLUÍDA</span>
      <h1>Cada descoberta conta!</h1>
      <p class='lead'>${esc(state.name)}, você completou ${session.len} desafios.</p>
      <div class='stats'>
        ${stat(session.independent, 'Acertos sem pista')}
        ${stat(session.recoveries, 'Acertos com apoio')}
        ${stat(state.xp - session.startxp, 'XP nesta missão')}
        ${stat(session.len, 'Desafios concluídos')}
      </div>
      <p class='micro'>Os próximos treinos consideram as dificuldades registradas. Uma resposta lenta continua correta.</p>
      <div class='actions'>
        ${button('finish', 'Voltar à aventura')}
        ${button('seeMap', 'Mapa de Evolução', 'blue')}
        ${button('seeReport', 'Ver progresso', 'ghost')}
      </div>
    </section>
  `);
    on('finish', () => {
        practiceSession = null;
        go('home');
    });
    on('seeMap', () => {
        practiceSession = null;
        go('map');
    });
    on('seeReport', () => go('report'));
}
function startPlacement() {
    if (!state.name) {
        intent = 'map';
        setupStep = 1;
        go('setup');
        return;
    }
    if (!allow())
        return;
    const skills = skillsForGrade(state.grade);
    const tasks = [];
    for (const skill of skills) {
        const first = skill.games[0];
        const second = skill.games[1] || first;
        tasks.push({ skillId: skill.id, gameId: first, q: generateMiniQuestion(first, state.grade) });
        tasks.push({ skillId: skill.id, gameId: second, q: generateMiniQuestion(second, state.grade) });
    }
    placementSession = { tasks, round: 0, phase: 'question', feedback: '', result: '', scores: {} };
    go('placement');
}
function placement() {
    const session = placementSession;
    if (!session || !session.tasks.length) {
        go('map');
        return;
    }
    const task = session.tasks[session.round];
    const skill = findSkill(task.skillId);
    if (!skill) {
        placementSession = null;
        go('map');
        return;
    }
    const game = GAMES[task.gameId];
    const q = task.q;
    shell(`
    <section class='card mini-game-card placement-game'>
      <div class='gamehead'>
        <div><span class='eyebrow'>🧭 DESAFIO INICIAL · SEM NOTA</span><small class='mini-skill-name'>${skillIcon(skill, '', 'inline-pictogram')} ${skill.title} · ${game.title}</small></div>
        <div class='gamehead-meta'>${sessionGuideMarkup()}<strong>${session.round + 1} de ${session.tasks.length}</strong></div>
      </div>
      <progress class='mission-progress' value='${session.round}' max='${session.tasks.length}' aria-label='Progresso da sondagem'></progress>
      <div class='question-content'>
        <h1 class='game-prompt'>${q.prompt}</h1>
        <div class='mini-expression'>${q.expression}</div>
        <div class='answers mini-answers'>
          ${session.phase === 'done' ? '' : q.options.map((option) => `<button type='button' class='answer' data-placement-answer='${esc(option)}'>${esc(option)}</button>`).join('')}
        </div>
        <div class='feedback ${session.result}' role='status' aria-live='polite'>${esc(session.feedback)}</div>
        ${session.phase === 'done' ? guideCoachMarkup(session.result === 'good' ? 'Ótimo raciocínio. Observe a estratégia e leve essa ideia para o próximo desafio.' : 'O erro também ensina. Leia a estratégia e tente reconhecer o padrão no próximo desafio.') : ''}
        ${session.phase === 'done' ? `<div class='explanation-box'><strong>Como pensar</strong><p>${q.explanation}</p></div>` : ''}
        <p class='micro'>Esta sondagem apenas localiza o melhor ponto de entrada. Ela não concede XP, moedas ou estrelas.</p>
        <div class='actions game-actions'>
          ${session.phase === 'done' ? button('nextPlacement', session.round + 1 === session.tasks.length ? 'Ver meu ponto de partida' : 'Próximo desafio →') : ''}
          ${button('readPlacement', 'Ouvir', 'blue')}
          ${button('leavePlacement', 'Sair', 'ghost')}
        </div>
      </div>
    </section>
  `);
    document.querySelectorAll('[data-placement-answer]').forEach((element) => {
        element.onclick = () => submitPlacement(element.dataset.placementAnswer || '');
    });
    on('readPlacement', () => void playVoice('instruction'));
    on('leavePlacement', () => {
        placementSession = null;
        go('map');
    });
    on('nextPlacement', () => {
        if (!placementSession || placementSession.phase !== 'done')
            return;
        placementSession.round += 1;
        if (placementSession.round >= placementSession.tasks.length) {
            finishPlacement();
            return;
        }
        placementSession.phase = 'question';
        placementSession.feedback = '';
        placementSession.result = '';
        placement();
    });
}
function submitPlacement(answer) {
    const session = placementSession;
    if (!session || session.phase === 'done')
        return;
    const task = session.tasks[session.round];
    const correct = answer === task.q.expected;
    const score = session.scores[task.skillId] || { correct: 0, total: 0 };
    score.total += 1;
    if (correct)
        score.correct += 1;
    session.scores[task.skillId] = score;
    session.feedback = correct
        ? 'Muito bem. Esta resposta ajuda a localizar seu ponto de partida.'
        : `Tudo bem. A resposta é ${task.q.expected}; observe a estratégia antes de continuar.`;
    session.result = correct ? 'good' : 'review';
    session.phase = 'done';
    tone(correct);
    placement();
}
function finishPlacement() {
    const session = placementSession;
    if (!session)
        return;
    const skills = skillsForGrade(state.grade);
    let recommended = skills[skills.length - 1];
    for (const skill of skills) {
        const score = session.scores[skill.id] || { correct: 0, total: 0 };
        const accuracy = score.total ? score.correct / score.total : 0;
        if (accuracy < 0.75) {
            recommended = skill;
            break;
        }
    }
    state.placement = {
        grade: state.grade,
        skillId: recommended.id,
        scores: session.scores,
        at: Date.now(),
    };
    state.placements[state.grade] = state.placement;
    save();
    go('placementSummary');
}
function placementSummary() {
    const placementResult = state.placement;
    const recommended = placementResult ? findSkill(placementResult.skillId) : undefined;
    if (!placementResult || placementResult.grade !== state.grade || !recommended) {
        placementSession = null;
        go('map');
        return;
    }
    const skills = skillsForGrade(state.grade);
    shell(`
    <section class='card celebration placement-summary'>
      <span class='celebration-icon' aria-hidden='true'>🧭</span>
      <span class='eyebrow'>PONTO DE PARTIDA IDENTIFICADO</span>
      <h1>${skillIcon(recommended, '', 'heading-pictogram')} ${recommended.title}</h1>
      <p class='lead'>A sondagem sugere começar por esta habilidade e avançar conforme as evidências de aprendizagem.</p>
      <div class='placement-score-grid'>
        ${skills.map((skill) => {
        const score = placementResult.scores[skill.id] || { correct: 0, total: 0 };
        return `<article class='${skill.id === recommended.id ? 'recommended' : ''}'>${skillIcon(skill, '', 'inline-pictogram')}<strong>${skill.title}</strong><b>${score.correct}/${score.total}</b><small>${skill.bncc.map((code) => `${code} (${skill.partialBncc?.includes(code) ? 'parcial' : 'central'})`).join(' · ')}</small></article>`;
    }).join('')}
      </div>
      <div class='mastery-message'>
        <strong>Diagnóstico formativo, não classificatório.</strong>
        <p>O resultado não concede estrelas nem XP. Ele apenas organiza o início da trilha e pode ser refeito quando necessário.</p>
      </div>
      <div class='actions'>
        ${button('startRecommended', 'Começar habilidade recomendada')}
        ${button('backPlacementMap', 'Ver mapa completo', 'blue')}
        ${button('redoPlacement', 'Refazer sondagem', 'ghost')}
      </div>
    </section>
  `);
    on('startRecommended', () => {
        placementSession = null;
        startMini(recommended.id, recommended.games[0]);
    });
    on('backPlacementMap', () => {
        placementSession = null;
        go('map');
    });
    on('redoPlacement', startPlacement);
}
function startMini(skillId, gameId) {
    const skill = findSkill(skillId);
    if (!skill || !skill.games.includes(gameId)) {
        say('Este game não pertence à habilidade selecionada.');
        return;
    }
    if (!allow())
        return;
    miniSession = {
        skillId,
        gameId,
        round: 0,
        len: 6,
        q: generateMiniQuestion(gameId, state.grade),
        phase: 'question',
        feedback: '',
        result: '',
        correct: 0,
        streak: 0,
        bestStreak: 0,
        startxp: state.xp,
        recorded: false,
    };
    go('miniGame');
}
function renderMiniScene(q) {
    const scene = q.scene;
    if (scene.kind === 'groups') {
        return `<div class='mechanic-scene groups-scene' aria-label='${scene.groups} grupos de ${scene.perGroup} elementos'>
      <div class='groups-visual'>${Array.from({ length: scene.groups }, (_, groupIndex) => `<div class='visual-group'><b>${groupIndex + 1}</b><div>${Array.from({ length: scene.perGroup }, () => `<i></i>`).join('')}</div></div>`).join('')}</div>
      <small>Conte por grupos ou use uma estratégia de multiplicação.</small>
    </div>`;
    }
    if (scene.kind === 'factor') {
        return `<div class='mechanic-scene factor-scene'>
      <div class='factor-lock' aria-hidden='true'>${gameIcon('fator', '', 'scene-pictogram')}</div>
      <div class='factor-equation'>${scene.hidden === 'a' ? '?' : scene.a}<span>×</span>${scene.hidden === 'b' ? '?' : scene.b}<span>=</span>${scene.total}</div>
      <small>Use a operação inversa para encontrar a chave correta.</small>
    </div>`;
    }
    if (scene.kind === 'division') {
        return `<div class='mechanic-scene division-scene'>
      <div class='tower-stock'><span class='block-stack' aria-hidden='true'><i></i><i></i><i></i></span><b>${scene.total}</b><small>blocos disponíveis</small></div>
      <div class='tower-arrow' aria-hidden='true'>→</div>
      <div class='tower-shell'>${gameIcon('divisao', '', 'scene-pictogram')}<b>? andares</b><small>${scene.divisor} blocos em cada andar</small></div>
      ${scene.remainder ? `<div class='division-remainder'><span class='single-block' aria-hidden='true'></span><b>e sobra?</b><small>nem todo bloco precisa completar um andar</small></div>` : ''}
    </div>`;
    }
    if (scene.kind === 'market') {
        return `<div class='mechanic-scene market-scene'>
      <div class='price-tag'>${gameIcon('mercado', '', 'scene-pictogram')}<b>R$ ${scene.unit}</b><small>cada item</small></div>
      <div class='cart-visual'><span class='cart-icon'>${gameIcon('mercado', '', 'scene-pictogram')}</span><div>${Array.from({ length: scene.quantity }, () => `<i class='cart-box'></i>`).join('')}</div><small>${scene.quantity} itens no carrinho</small></div>
      <div class='receipt-question'><span class='receipt-lines' aria-hidden='true'><i></i><i></i><i></i></span><b>Total: ?</b></div>
    </div>`;
    }
    if (scene.kind === 'pattern') {
        return `<div class='mechanic-scene pattern-scene'>
      <div class='detective-badge' aria-hidden='true'>${gameIcon('padroes', '', 'scene-pictogram')}</div>
      <div class='pattern-trail'>${scene.values.map((value, index) => `<span><i>${index + 1}</i><b>${value}</b></span>`).join('')}<span class='mystery'><i>?</i><b>?</b></span></div>
      <small>A diferença entre as pistas é sempre ${scene.step}.</small>
    </div>`;
    }
    if (scene.kind === 'combinations') {
        return `<div class='mechanic-scene combinations-scene'>
      <div class='wardrobe-side'><b>Grupo A</b><div>${Array.from({ length: scene.first }, (_, index) => `<span class='combo-chip a' aria-label='opção A ${index + 1}'>A${index + 1}</span>`).join('')}</div></div>
      <div class='combo-sign' aria-hidden='true'>×</div>
      <div class='wardrobe-side'><b>Grupo B</b><div>${Array.from({ length: scene.second }, (_, index) => `<span class='combo-chip b' aria-label='opção B ${index + 1}'>B${index + 1}</span>`).join('')}</div></div>
      <div class='combo-question'>${gameIcon('combinacoes', '', 'scene-pictogram')}<b>? combinações</b></div>
    </div>`;
    }
    if (scene.kind === 'percentage') {
        return `<div class='mechanic-scene percentage-scene'>
      <div class='percent-dial'><b>${scene.percent}%</b><small>${scene.mode === 'part' ? `de ${scene.base}` : scene.mode === 'discount' ? 'desconto' : 'acréscimo'}</small></div>
      <progress class='percent-track semantic-progress' value='${Math.min(100, scene.percent)}' max='100' aria-label='${scene.percent} por cento'></progress>
      <div class='percent-context'><strong>Base: ${scene.base}</strong><span>Parcela percentual: ${scene.amount}</span>${scene.mode !== 'part' ? `<span>Resultado final: ?</span>` : ''}</div>
    </div>`;
    }
    if (scene.kind === 'multiples') {
        return `<div class='mechanic-scene multiples-scene'>
      <div class='target-rings'><span></span><span></span><span></span><b>${scene.mode === 'criterion' ? '÷' : '×'}${scene.base}</b></div>
      <div><strong>${scene.mode === 'criterion' ? 'Radar da divisibilidade' : 'Regra do alvo'}</strong><p>${scene.mode === 'criterion' ? `Procure um número que possa ser dividido por ${scene.criterion || scene.base} sem deixar resto.` : `O número precisa aparecer na sequência ${scene.base}, ${scene.base * 2}, ${scene.base * 3}, ...`}</p></div>
    </div>`;
    }
    if (scene.kind === 'divisors') {
        return `<div class='mechanic-scene divisors-scene'>
      <div class='lab-flask' aria-hidden='true'>${gameIcon('divisores', '', 'scene-pictogram')}</div>
      <div><strong>Amostra ${scene.value}</strong><p>Escolha um reagente que divida ${scene.value} e deixe resto zero.</p></div>
      <div class='lab-equation'>${scene.value} ÷ ?</div>
    </div>`;
    }
    if (scene.kind === 'power') {
        return `<div class='mechanic-scene power-scene'>
      <div class='power-planet' aria-hidden='true'>${gameIcon('potencias', '', 'scene-pictogram')}</div>
      <div><strong>Base ${scene.base}</strong><p>O expoente ${scene.exponent} indica quantas vezes a base aparece como fator.</p><div class='power-factors'>${Array.from({ length: scene.exponent }, () => `<span>${scene.base}</span>`).join('<i>×</i>')}</div></div>
      <div class='power-result'>${scene.base}<sup>${scene.exponent}</sup><b>= ?</b></div>
    </div>`;
    }
    if (scene.kind === 'expression') {
        return `<div class='mechanic-scene expression-scene'>
      <div class='expression-tower' aria-hidden='true'>${gameIcon('expressoes', '', 'scene-pictogram')}</div>
      <div><strong>Torre das Expressões</strong><p>Resolva um andar de cada vez, respeitando agrupamentos e prioridade das operações.</p><div class='expression-card'>${scene.expression}</div></div>
    </div>`;
    }
    return `<div class='mechanic-scene prime-scene'>
    <div class='prime-vault' aria-hidden='true'>${gameIcon('primos', '', 'scene-pictogram')}</div>
    <div class='prime-number'>${scene.value}</div>
    <div><strong>Scanner de divisores</strong><p>Um número primo tem exatamente dois divisores naturais: 1 e ele mesmo.</p></div>
  </div>`;
}
function renderMiniAnswers(q, gameId) {
    const labels = {
        grupos: 'Total',
        fator: 'Chave',
        divisao: 'Resultado',
        mercado: 'Total',
        padroes: 'Próxima pista',
        combinacoes: 'Combinações',
        porcentagem: 'Quantidade',
        multiplos: 'Alvo',
        divisores: 'Reagente',
        primos: 'Classificação',
        potencias: 'Resultado',
        expressoes: 'Resultado',
    };
    return `<div class='answers mini-answers answer-style-${gameId}'>${q.options
        .map((option) => {
        const display = gameId === 'mercado' ? `R$ ${esc(option)}` : esc(option);
        return `<button type='button' class='answer mechanic-answer' data-mini-answer='${esc(option)}'><small>${labels[gameId]}</small><b>${display}</b></button>`;
    })
        .join('')}</div>`;
}
function miniFeedback(gameId, correct) {
    if (!correct) {
        const review = {
            grupos: 'A construção ainda não fecha. Conte os grupos e confira a estratégia.',
            fator: 'Essa chave não abre o cadeado. Use a divisão para voltar ao fator.',
            divisao: 'A torre não fecha com essa quantidade de andares. Confira a relação inversa.',
            mercado: 'O caixa encontrou diferença no total. Multiplique quantidade pelo preço unitário.',
            padroes: 'A pista não mantém o padrão. Observe quanto a sequência aumenta a cada passo.',
            combinacoes: 'Ainda faltam ou sobraram possibilidades. Combine cada item do primeiro grupo com todos do segundo.',
            porcentagem: 'A barra não corresponde a essa quantidade. Relacione a porcentagem a uma fração conhecida.',
            multiplos: 'Esse alvo não pertence à sequência pedida. Procure um produto exato.',
            divisores: 'Esse reagente deixa resto. Um divisor precisa produzir quociente natural.',
            primos: 'O scanner indica outra classificação. Verifique quantos divisores naturais o número possui.',
            potencias: 'A nave perdeu a rota. Repita a base o número de vezes indicado pelo expoente e multiplique os fatores.',
            expressoes: 'A torre travou. Resolva primeiro parênteses e multiplicações antes de somar ou subtrair.',
        };
        return review[gameId];
    }
    const success = {
        grupos: 'Construção concluída! Os grupos formam o total correto.',
        fator: 'Cadeado aberto! Você encontrou o fator oculto.',
        divisao: 'Torre concluída! A repartição ficou exata.',
        mercado: 'Compra fechada! O total do carrinho está correto.',
        padroes: 'Caso resolvido! Você encontrou a regularidade.',
        combinacoes: 'Combinações mapeadas! Você usou o princípio multiplicativo.',
        porcentagem: 'Barra completa! A relação percentual está correta.',
        multiplos: 'Alvo atingido! Esse número pertence à sequência de múltiplos.',
        divisores: 'Experimento aprovado! A divisão ficou sem resto.',
        primos: 'Código decifrado! A classificação pelos divisores está correta.',
        potencias: 'Órbita calculada! Você interpretou a potência como produto de fatores iguais.',
        expressoes: 'Torre estabilizada! Você respeitou a ordem das operações.',
    };
    return `${success[gameId]} +10 XP.`;
}
function miniGame() {
    if (!miniSession) {
        go('map');
        return;
    }
    const session = miniSession;
    const skill = findSkill(session.skillId);
    if (!skill) {
        miniSession = null;
        go('map');
        return;
    }
    const game = GAMES[session.gameId];
    const q = session.q;
    shell(`
    <section class='card mini-game-card game-theme-${session.gameId}'>
      <div class='gamehead'>
        <div><span class='eyebrow pictogram-eyebrow'>${gameIcon(session.gameId, '', 'inline-pictogram')} ${game.title}</span><small class='mini-skill-name'>${skill.title}</small></div>
        <div class='gamehead-meta'>${sessionGuideMarkup()}<strong>${session.round + 1} de ${session.len}</strong></div>
      </div>
      <progress class='mission-progress' value='${session.round}' max='${session.len}' aria-label='Progresso do game'></progress>
      <div class='question-content'>
        <h1 class='game-prompt'>${q.prompt}</h1>
        ${renderMiniScene(q)}
        <div class='mini-expression'>${q.expression}</div>
        ${session.phase === 'done' ? '' : renderMiniAnswers(q, session.gameId)}
        <div class='feedback ${session.result}' role='status' aria-live='polite'>${session.feedback}</div>
        ${session.phase === 'done'
        ? `<div class='explanation-box'><strong>Estratégia</strong><p>${q.explanation}</p></div>`
        : ''}
        <div class='streak-line'><span>🔥 sequência: <b>${session.streak}</b></span><span>⭐ melhor: <b>${session.bestStreak}</b></span></div>
        <div class='actions game-actions'>
          ${session.phase === 'done' ? button('nextMini', session.round + 1 === session.len ? 'Ver conquista' : 'Próximo desafio →') : ''}
          ${button('readMini', 'Ouvir orientação', 'blue')}
          ${button('leaveMini', 'Sair do game', 'ghost')}
        </div>
      </div>
    </section>
  `);
    document.querySelectorAll('[data-mini-answer]').forEach((element) => {
        element.onclick = () => submitMini(element.dataset.miniAnswer || '');
    });
    on('readMini', () => void playVoice('instruction'));
    on('leaveMini', () => {
        if (session.round > 0 && !confirm('Sair deste game agora? O progresso já conquistado será mantido.'))
            return;
        miniSession = null;
        go('map');
    });
    on('nextMini', () => {
        if (!miniSession || miniSession.phase !== 'done')
            return;
        miniSession.round += 1;
        if (miniSession.round >= miniSession.len) {
            go('miniSummary');
            return;
        }
        miniSession.q = generateMiniQuestion(miniSession.gameId, state.grade);
        miniSession.phase = 'question';
        miniSession.feedback = '';
        miniSession.result = '';
        miniGame();
    });
}
function submitMini(answer) {
    const session = miniSession;
    if (!session || session.phase === 'done')
        return;
    const correct = answer === session.q.expected;
    if (correct) {
        session.correct += 1;
        session.streak += 1;
        session.bestStreak = Math.max(session.bestStreak, session.streak);
        session.feedback = miniFeedback(session.gameId, true);
        session.result = 'good';
        tone();
    }
    else {
        session.streak = 0;
        session.feedback = `${miniFeedback(session.gameId, false)} A resposta correta é ${session.q.expected}.`;
        session.result = 'review';
        tone(false);
    }
    recordSkill(state, session.skillId, correct, session.streak, Date.now(), correct ? undefined : errorCategoryForGame(session.gameId));
    session.phase = 'done';
    save();
    miniGame();
}
function miniSummary() {
    if (!miniSession) {
        go('map');
        return;
    }
    const session = miniSession;
    const skill = findSkill(session.skillId);
    if (!skill) {
        miniSession = null;
        go('map');
        return;
    }
    if (!session.recorded) {
        recordGameSession(state, session.gameId, session.correct, session.len);
        session.recorded = true;
        save();
    }
    const progress = getSkillProgress(state, skill.id);
    shell(`
    <section class='card celebration mini-celebration'>
      ${gameIcon(session.gameId, '', 'celebration-pictogram')}
      <span class='eyebrow'>GAME CONCLUÍDO</span>
      <h1>${GAMES[session.gameId].title}</h1>
      <p class='lead'>Você treinou <strong>${skill.title}</strong>.</p>
      <div class='stats'>
        ${stat(`${session.correct}/${session.len}`, 'Acertos')}
        ${stat(session.bestStreak, 'Melhor sequência')}
        ${stat(state.xp - session.startxp, 'XP conquistados')}
        ${stat(skillStars(skill.id), 'Estrelas da habilidade')}
      </div>
      <div class='mastery-message'>
        <strong>${progress.stars === 3 ? 'Consolidação forte' : progress.stars === 2 ? 'Boa evolução' : progress.stars === 1 ? 'Habilidade em construção' : 'Primeiras evidências'}</strong>
        <p>As estrelas consideram volume de prática e precisão acumulada. Elas não substituem avaliação escolar ou observação docente.</p>
      </div>
      <div class='actions'>
        ${button('repeatMini', 'Jogar novamente')}
        ${button('backMap', 'Voltar ao mapa', 'blue')}
        ${button('progressMini', 'Ver progresso', 'ghost')}
      </div>
    </section>
  `);
    on('repeatMini', () => startMini(skill.id, session.gameId));
    on('backMap', () => {
        miniSession = null;
        go('map');
    });
    on('progressMini', () => go('report'));
}
function buildBossTasks() {
    const skills = skillsForGrade(state.grade);
    const tasks = [];
    if (!skills.length)
        return tasks;
    for (let index = 0; index < 8; index += 1) {
        const skill = skills[index % skills.length];
        const gameId = skill.games[Math.floor(index / skills.length) % skill.games.length];
        tasks.push({ skillId: skill.id, gameId, q: generateMiniQuestion(gameId, state.grade) });
    }
    return tasks;
}
function startBoss() {
    if (!state.name) {
        intent = 'map';
        setupStep = 1;
        go('setup');
        return;
    }
    if (!allow())
        return;
    if (!bossUnlocked(state, state.grade) && !bossCompleted(state, state.grade)) {
        say('O Chefão Matemático é liberado quando você conquista pelo menos uma estrela em cada habilidade do ano.');
        return;
    }
    const tasks = buildBossTasks();
    if (!tasks.length)
        return;
    bossSession = {
        tasks,
        round: 0,
        phase: 'question',
        feedback: '',
        result: '',
        correct: 0,
        streak: 0,
        bestStreak: 0,
        startxp: state.xp,
        recorded: false,
    };
    go('boss');
}
function bossGame() {
    const session = bossSession;
    if (!session || !session.tasks.length) {
        go('map');
        return;
    }
    const task = session.tasks[session.round];
    const skill = findSkill(task.skillId);
    if (!skill) {
        bossSession = null;
        go('map');
        return;
    }
    const boss = BOSSES[state.grade];
    const q = task.q;
    shell(`
    <section class='card mini-game-card boss-game grade-boss-${GRADE_ORDER.indexOf(state.grade) + 3}'>
      <div class='boss-banner'>
        <span class='boss-avatar' aria-hidden='true'>${boss.icon}</span>
        <div><span class='eyebrow'>CHEFÃO MATEMÁTICO · ${state.grade}</span><h1>${boss.title}</h1><p>${boss.intro}</p></div>
      </div>
      <div class='gamehead'><span class='mini-skill-name'>${skillIcon(skill, '', 'inline-pictogram')} ${skill.title} · ${GAMES[task.gameId].title}</span><div class='gamehead-meta'>${sessionGuideMarkup()}<strong>${session.round + 1} de ${session.tasks.length}</strong></div></div>
      <progress class='mission-progress boss-progress' value='${session.round}' max='${session.tasks.length}' aria-label='Progresso do Chefão Matemático'></progress>
      <div class='question-content'>
        <h2 class='game-prompt'>${q.prompt}</h2>
        ${renderMiniScene(q)}
        <div class='mini-expression'>${q.expression}</div>
        ${session.phase === 'done' ? '' : renderMiniAnswers(q, task.gameId)}
        <div class='feedback ${session.result}' role='status' aria-live='polite'>${esc(session.feedback)}</div>
        ${session.phase === 'done' ? guideCoachMarkup(session.result === 'good' ? 'Você está integrando habilidades. Continue com calma.' : 'Revise a estratégia antes do próximo desafio do chefão.') : ''}
        ${session.phase === 'done' ? `<div class='explanation-box'><strong>Estratégia</strong><p>${q.explanation}</p></div>` : ''}
        <div class='streak-line'><span>🎯 acertos: <b>${session.correct}</b></span><span>🔥 sequência: <b>${session.streak}</b></span><span>⭐ melhor: <b>${session.bestStreak}</b></span></div>
        <div class='actions game-actions'>
          ${session.phase === 'done' ? button('nextBoss', session.round + 1 === session.tasks.length ? 'Ver resultado final' : 'Próximo desafio →') : ''}
          ${button('readBoss', 'Ouvir orientação', 'blue')}
          ${button('leaveBoss', 'Sair do chefão', 'ghost')}
        </div>
        <p class='micro'>Sem cronômetro. O Chefão mistura habilidades do ano e exige 75% de acertos para ser superado.</p>
      </div>
    </section>
  `);
    document.querySelectorAll('[data-mini-answer]').forEach((element) => {
        element.onclick = () => submitBoss(element.dataset.miniAnswer || '');
    });
    on('readBoss', () => void playVoice('boss'));
    on('leaveBoss', () => {
        if (session.round > 0 && !confirm('Sair do Chefão Matemático? As questões já respondidas continuam registradas nas habilidades.'))
            return;
        bossSession = null;
        go('map');
    });
    on('nextBoss', () => {
        if (!bossSession || bossSession.phase !== 'done')
            return;
        bossSession.round += 1;
        if (bossSession.round >= bossSession.tasks.length) {
            go('bossSummary');
            return;
        }
        bossSession.phase = 'question';
        bossSession.feedback = '';
        bossSession.result = '';
        bossGame();
    });
}
function submitBoss(answer) {
    const session = bossSession;
    if (!session || session.phase === 'done')
        return;
    const task = session.tasks[session.round];
    const correct = answer === task.q.expected;
    if (correct) {
        session.correct += 1;
        session.streak += 1;
        session.bestStreak = Math.max(session.bestStreak, session.streak);
        session.feedback = `${miniFeedback(task.gameId, true)} O Chefão perdeu uma barreira.`;
        session.result = 'good';
        tone();
    }
    else {
        session.streak = 0;
        session.feedback = `${miniFeedback(task.gameId, false)} A resposta correta é ${task.q.expected}.`;
        session.result = 'review';
        tone(false);
    }
    recordSkill(state, task.skillId, correct, session.streak, Date.now(), correct ? undefined : errorCategoryForGame(task.gameId));
    session.phase = 'done';
    save();
    bossGame();
}
function bossSummary() {
    const session = bossSession;
    if (!session) {
        go('map');
        return;
    }
    const boss = BOSSES[state.grade];
    const score = Math.round((session.correct / session.tasks.length) * 100);
    const passed = score >= 75;
    let firstClear = false;
    if (!session.recorded) {
        firstClear = recordBossAttempt(state, state.grade, session.correct, session.tasks.length);
        session.recorded = true;
        save();
    }
    const bossProgress = state.bosses[state.grade];
    const medal = collectiblesForGrade(state, state.grade).find((item) => item.unlock === 'boss');
    shell(`
    <section class='card celebration boss-summary ${passed ? 'passed' : 'retry'}'>
      <span class='celebration-icon' aria-hidden='true'>${passed ? '🏆' : boss.icon}</span>
      <span class='eyebrow'>${passed ? 'CHEFÃO SUPERADO' : 'DESAFIO EM CONSTRUÇÃO'}</span>
      <h1>${passed ? boss.victory : `${boss.title} ainda guarda o caminho`}</h1>
      <p class='lead'>${passed ? `Você integrou as habilidades do ${state.grade} e alcançou ${score}% de acertos.` : `Você alcançou ${score}%. Revise as habilidades que deram mais trabalho e tente novamente quando quiser.`}</p>
      <div class='stats'>
        ${stat(`${session.correct}/${session.tasks.length}`, 'Acertos')}
        ${stat(`${score}%`, 'Resultado do desafio')}
        ${stat(session.bestStreak, 'Melhor sequência')}
        ${stat(`${bossProgress?.bestScore || score}%`, 'Melhor resultado')}
      </div>
      ${passed && medal ? `<div class='boss-reward'><span>${medal.icon}</span><div><strong>${firstClear ? 'Nova relíquia encontrada!' : 'Relíquia do capítulo'}</strong><p>${medal.title} — ${medal.description}</p>${firstClear ? '<small>Primeira vitória: bônus único de 25 XP e 5 moedas de jornada.</small>' : ''}</div></div>` : ''}
      <div class='mastery-message'><strong>O Chefão não substitui a consolidação.</strong><p>As estrelas continuam dependendo de prática acumulada e precisão nas habilidades. O desafio final é uma síntese integrada, não uma prova escolar.</p></div>
      <div class='actions'>
        ${button('retryBoss', passed ? 'Jogar chefão novamente' : 'Tentar novamente')}
        ${button('bossMap', 'Voltar ao mapa', 'blue')}
        ${button('bossCollection', 'Ver coleção', 'ghost')}
      </div>
    </section>
  `);
    on('retryBoss', startBoss);
    on('bossMap', () => { bossSession = null; go('map'); });
    on('bossCollection', () => { bossSession = null; go('collection'); });
}
function collection() {
    const relics = allCollectibles(state);
    const badges = achievements(state);
    const unlockedRelics = relics.filter((item) => item.unlocked).length;
    const unlockedBadges = badges.filter((item) => item.unlocked).length;
    shell(`
    <section class='card collection-hero'>
      <div><span class='eyebrow'>COLEÇÃO DA JORNADA</span><h1>🎒 Relíquias e conquistas</h1><p class='lead'>A coleção é desbloqueada automaticamente por evidências de aprendizagem, exploração e síntese. Não há compras nem itens aleatórios.</p></div>
      <div class='collection-totals'><b>${unlockedRelics}/${relics.length}</b><span>relíquias</span><b>${unlockedBadges}/${badges.length}</b><span>conquistas</span></div>
    </section>
    ${GRADE_ORDER.map((grade) => {
        const story = STORIES[grade];
        const gradeRelics = relics.filter((item) => item.grade === grade);
        return `<section class='card collection-chapter ${grade === state.grade ? 'active' : ''}'><div class='section-head'><div><span class='eyebrow'>${grade}</span><h2>${story.icon} ${story.title}</h2></div><span class='chapter-status'>${gradeRelics.filter((item) => item.unlocked).length}/${gradeRelics.length}</span></div><div class='relic-grid'>${gradeRelics.map((item) => `<article class='relic-card ${item.unlocked ? 'unlocked' : 'locked'}'><span>${item.unlocked ? item.icon : '❔'}</span><b>${item.unlocked ? item.title : 'Relíquia ainda secreta'}</b><small>${item.unlocked ? item.description : 'Progrida neste capítulo para revelar.'}</small></article>`).join('')}</div></section>`;
    }).join('')}
    <section class='card achievements-section'>
      <span class='eyebrow'>CONQUISTAS GLOBAIS</span><h2>Marcos da evolução</h2>
      <div class='achievement-grid'>${badges.map((badge) => `<article class='achievement-card ${badge.unlocked ? 'unlocked' : 'locked'}'><span>${badge.unlocked ? badge.icon : '🔒'}</span><div><b>${badge.title}</b><p>${badge.description}</p></div></article>`).join('')}</div>
      <div class='actions'>${button('collectionMap', 'Voltar ao mapa', 'blue')}${button('collectionHome', 'Início', 'ghost')}</div>
    </section>
  `);
    on('collectionMap', () => go('map'));
    on('collectionHome', () => go('home'));
}
function report() {
    const m = metrics(state);
    const gradeSkills = skillsForGrade(state.grade);
    const relics = allCollectibles(state);
    const badges = achievements(state);
    const unlockedRelics = relics.filter((item) => item.unlocked).length;
    const unlockedBadges = badges.filter((item) => item.unlocked).length;
    shell(`
    <section class='card report'>
      <span class='eyebrow'>ACOMPANHAMENTO PEDAGÓGICO</span>
      <h1>Progresso de ${esc(state.name || 'quem aprende')}</h1>
      <p class='lead'>${state.grade} · ${GRADE_META[state.grade].title} · dados deste navegador.</p>
      <div class='stats'>
        ${stat(`${m.skillAccuracy}%`, 'Acertos nos games')}
        ${stat(m.skillStars, 'Estrelas de habilidade')}
        ${stat(`${m.mastery}%`, 'Fluência consolidada')}
        ${stat(state.xp, 'XP total')}
      </div>
      <div class='stats journey-report-stats'>
        ${stat(m.gameCompletions, 'Games concluídos')}
        ${stat(m.bossesCompleted, 'Chefões superados')}
        ${stat(`${unlockedRelics}/${relics.length}`, 'Relíquias')}
        ${stat(`${unlockedBadges}/${badges.length}`, 'Conquistas')}
      </div>

      <section class='report-section'>
        <h2>Jornada, missões e síntese</h2>
        <div class='report-journey-box'>
          <div><span>${STORIES[state.grade].icon}</span><div><strong>${STORIES[state.grade].title}</strong><p>${missionsForGrade(state, state.grade).filter((mission) => mission.done).length}/${missionsForGrade(state, state.grade).length} missões concluídas neste ano.</p></div></div>
          <div><span>${BOSSES[state.grade].icon}</span><div><strong>${BOSSES[state.grade].title}</strong><p>${bossCompleted(state, state.grade) ? `Superado · melhor resultado ${state.bosses[state.grade]?.bestScore || 0}%` : bossUnlocked(state, state.grade) ? 'Liberado para desafio.' : 'Ainda bloqueado: exige uma estrela em cada habilidade.'}</p></div></div>
        </div>
        <p class='micro'>Missões, relíquias e Chefões Matemáticos organizam a experiência de jogo, mas não substituem os indicadores pedagógicos de prática, precisão e consolidação.</p>
      </section>

      <section class='report-section'>
        <h2>Habilidades da trilha</h2>
        <div class='skill-report-grid'>
          ${gradeSkills
        .map((skill) => {
        const progress = getSkillProgress(state, skill.id);
        const accuracy = progress.played ? Math.round((progress.correct / progress.played) * 100) : 0;
        const dominantError = dominantSkillError(progress);
        return `<article><div>${skillIcon(skill, '', 'inline-pictogram')}<strong>${skill.title}</strong></div><p>${skillStars(skill.id)} · ${progress.played} desafios · ${accuracy}% de acertos</p>${dominantError ? `<p class='difficulty-signal'><b>Atenção recorrente:</b> ${ERROR_CATEGORY_LABELS[dominantError]}</p>` : ''}<small>${skill.bncc.map((code) => `${code} (${skill.partialBncc?.includes(code) ? 'parcial' : 'central'})`).join(' · ')}</small></article>`;
    })
        .join('')}
        </div>
      </section>

      <section class='report-section'>
        <h2>Fluência da tabuada</h2>
        ${m.n === 0
        ? `<p class='empty-state'>Ainda não há respostas do treino adaptativo. Os games já podem produzir evidências de raciocínio por habilidade.</p>`
        : ''}
        <div class='table-scroll'>
          <table class='table'>
            <caption>Histórico por tabuada</caption>
            <thead><tr><th scope='col'>Tabuada</th><th scope='col'>Questões</th><th scope='col'>Sem pista</th><th scope='col'>Com apoio</th><th scope='col'>Consolidados</th></tr></thead>
            <tbody>
              ${GRADES[state.grade]
        .map((a) => {
        const facts = Array.from({ length: 11 }, (_, b) => getFact(state, a, b));
        const n = facts.reduce((total, fact) => total + fact.n, 0);
        const c = facts.reduce((total, fact) => total + fact.c, 0);
        return `<tr><th scope='row'>×${a}</th><td>${n}</td><td>${n ? `${Math.round((c / n) * 100)}%` : '—'}</td><td>${facts.reduce((total, fact) => total + fact.rec, 0)}</td><td>${facts.filter(consolidated).length}/11</td></tr>`;
    })
        .join('')}
            </tbody>
          </table>
        </div>
      </section>

      <details>
        <summary>Como os indicadores funcionam</summary>
        <p><strong>Estrelas de habilidade:</strong> combinam quantidade de desafios e precisão acumulada nos games. Três estrelas exigem prática repetida e alta precisão.</p>
        <p><strong>Fato consolidado:</strong> exige pelo menos três evidências recentes, 80% de acertos sem pista, em pelo menos dois dias e dois tipos de questão.</p>
        <p>Ajuda e recuperação são registradas separadamente. O tempo de resposta não reduz a pontuação. Os indicadores são pedagógicos e não equivalem a nota escolar.</p>
      </details>
      <div class='actions no-print'>
        ${button('print', 'Imprimir / Salvar PDF', 'blue')}
        ${button('backup', 'Exportar progresso', 'ghost')}
        ${button('exportCsv', 'Exportar relatório CSV', 'ghost')}
        ${button('backHome', 'Voltar', 'ghost')}
      </div>
    </section>
  `);
    on('print', () => window.print());
    on('backup', backup);
    on('exportCsv', exportCsv);
    on('backHome', () => go(state.name ? 'home' : 'splash'));
}
function exportCsv() {
    const header = ['ano', 'habilidade', 'bncc', 'cobertura', 'desafios', 'acertos', 'precisao_percentual', 'estrelas'];
    const rows = skillsForGrade(state.grade).map((skill) => {
        const progress = getSkillProgress(state, skill.id);
        const accuracy = progress.played ? Math.round((progress.correct / progress.played) * 100) : 0;
        return [state.grade, skill.title, skill.bncc.join(' + '), skill.bncc.map((code) => `${code}:${skill.partialBncc?.includes(code) ? 'parcial' : 'central'}`).join(' + '), progress.played, progress.correct, accuracy, progress.stars];
    });
    const escapeCsv = (value) => `"${String(value).replace(/"/g, '""')}"`;
    const content = [header, ...rows].map((row) => row.map(escapeCsv).join(';')).join('\n');
    const blob = new Blob(['\ufeff' + content], { type: 'text/csv;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const anchor = document.createElement('a');
    anchor.href = url;
    anchor.download = `Intelectus-Tabuada-Relatorio-${state.grade.replace(/[^0-9]/g, '')}.csv`;
    anchor.click();
    setTimeout(() => URL.revokeObjectURL(url), 1500);
    say('Relatório CSV preparado. Ele pode ser aberto em planilhas ou salvo no Google Drive.');
}
function backup() {
    const blob = new Blob([JSON.stringify({ app: 'intelectus-tabuada', version: 7, release: RELEASE, state }, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const anchor = document.createElement('a');
    anchor.href = url;
    anchor.download = 'Intelectus-Tabuada-Progresso.json';
    anchor.click();
    setTimeout(() => URL.revokeObjectURL(url), 1500);
    say('Cópia do progresso preparada. A licença não faz parte do backup.');
}
async function restore(file) {
    if (file.size > 2 * 1024 * 1024) {
        say('Arquivo muito grande. Use uma cópia de progresso do Tabuada de até 2 MB.');
        return;
    }
    try {
        const raw = JSON.parse(await file.text());
        const next = validateBackup(raw);
        if (!next)
            throw new Error('invalid');
        if (!confirm('Substituir o perfil e o progresso atuais por esta cópia? O período de avaliação não será reiniciado.'))
            return;
        if (!write(KEY, JSON.stringify(next))) {
            say('Não foi possível restaurar: o navegador não salvou a cópia. O perfil e o progresso anteriores foram mantidos.');
            return;
        }
        state = next;
        practiceSession = null;
        miniSession = null;
        bossSession = null;
        placementSession = null;
        go('report');
        say('Progresso restaurado.');
    }
    catch {
        say('Arquivo inválido. Selecione um backup JSON exportado pelo Intelectus Tabuada. Nenhum dado foi substituído.');
    }
}
function family() {
    const value = trial();
    const avatar = avatarChoice(state.avatar);
    const guide = guideChoice(state.guide);
    const end = value ? new Date(value.start + WEEK).toLocaleString('pt-BR') : '';
    shell(`
    <section class='card family'>
      <span class='eyebrow'>PARA QUEM ACOMPANHA</span>
      <h1>Área do responsável</h1>
      <div class='family-profile-card'><img src='${avatar.src}' alt='' aria-hidden='true'><img src='${guide.src}' alt='' aria-hidden='true'><div><strong>${esc(state.name || 'Criança')} · ${esc(state.grade)}</strong><span>${esc(avatar.name)} · guia: ${esc(guideName())}</span></div></div>
      <p class='lead'>O Intelectus Tabuada trabalha raciocínio multiplicativo em progressão do 3º ao 6º ano. A tabuada é meio de compreensão, estratégia e fluência — não apenas memorização. Uma sondagem formativa indica o melhor ponto de partida sem gerar nota, XP ou estrelas. Missões, relíquias e Chefões Matemáticos organizam a progressão sem compras, loot boxes ou ranking público.</p>
      <div class='family-grid'>
        <section class='info-panel'>
          <h2>Proposta pedagógica</h2>
          <p><strong>3º ano:</strong> fatos básicos, regularidades, grupos iguais, multiplicações por 2, 3, 4, 5 e 10 e sentidos da divisão.</p>
          <p><strong>4º ano:</strong> propriedades, relações inversas, termos desconhecidos, diferentes significados da multiplicação e divisão.</p>
          <p><strong>5º ano:</strong> operações, incógnitas, princípio multiplicativo, proporcionalidade e porcentagens usuais.</p>
          <p><strong>6º ano:</strong> operações e expressões, potenciação, múltiplos, divisores, primalidade e porcentagens.</p>
          <p class='bncc-copy'><strong>Habilidades de referência:</strong> ${BNCC_CODES.join(', ')}.</p>
          <p class='coverage-key'><span class='central'>Central</span> quando o app produz evidência direta do núcleo operacional trabalhado; <span class='partial'>Parcial</span> quando trabalha apenas parte dos verbos, campos numéricos ou contextos da habilidade.</p>
          <div class='family-bncc-grid'>${skillsForGrade(state.grade).map((skill) => `<article><strong>${esc(skill.title)}</strong><p>${skill.bncc.map((code) => `<span class='${skill.partialBncc?.includes(code) ? 'partial' : 'central'}'>${code} · ${skill.partialBncc?.includes(code) ? 'parcial' : 'central'}</span>`).join('')}</p></article>`).join('')}</div>
          <p class='micro'>O aplicativo trabalha um recorte dessas habilidades voltado a tabuada, cálculo e raciocínio multiplicativo; não substitui o currículo completo de Matemática.</p>
          <a href='https://basenacionalcomum.mec.gov.br/' target='_blank' rel='noopener noreferrer'>Consultar a BNCC oficial</a>
        </section>
        <section class='info-panel'>
          <h2>Licença e acesso</h2>
          ${portalEntitled() ? `<p><strong>Acesso autorizado pelo Portal Intelectus.</strong></p><p>Esta sessão foi liberada pela Área do Cliente para um produto ou pacote ativo.</p><p class='micro'>O progresso pedagógico continua salvo neste navegador e pode ser exportado normalmente.</p>` : `<p><strong>${expired() ? 'Acesso inativo' : value ? 'Período de experimentação em andamento' : 'Acesso ainda não ativado'}</strong></p>${value ? `<p>Fim do período de experimentação: ${end}.</p>` : ''}<p>Planos, renovação, combos e licenças familiares ou escolares são administrados exclusivamente pelo Portal Intelectus.</p><p class='micro'>O período demonstrativo local não substitui a autorização central do Portal Intelectus.</p>`}
          <a class='btn primary contact-link' href='https://www.portalintelectus.com.br/checkout?offer=gam_tabuada_anual&origem=app-familia' target='_blank' rel='noopener noreferrer'>${portalEntitled() ? 'Gerenciar acesso' : expired() ? 'Renovar acesso' : 'Planos e assinatura'}</a>
          <a class='btn ghost contact-link' href='mailto:suporteintelectus@gmail.com?subject=Licen%C3%A7a%20Intelectus%20Tabuada'>Falar com o suporte</a>
        </section>
      </div>
      <section class='offline-missions-panel'>
        <div class='section-head'><div><span class='eyebrow'>MISSÕES FORA DA TELA</span><h2>Matemática acompanhada no cotidiano</h2></div></div>
        <p class='lead'>Estas propostas não dão XP nem estrelas. Servem para registrar como a criança mobiliza estratégias fora do aplicativo.</p>
        <div class='offline-mission-grid'>${familyMissionMarkup()}</div>
      </section>
      <details open>
        <summary>Privacidade, dados e infraestrutura</summary>
        <p>Use apenas um apelido. Perfil, respostas, XP, missões, relíquias e progresso ficam no armazenamento deste navegador. Não há publicidade, compras dentro do app, ranking público ou API paga obrigatória.</p>
        <p>Limpar dados do navegador, trocar de aparelho ou usar navegação privativa pode apagar o progresso. Exporte uma cópia regularmente.</p>
      </details>
      <div class='actions'>
        ${button('parentReport', 'Ver progresso', 'blue')}
        ${button('backup', 'Exportar progresso', 'ghost')}
        ${button('restore', 'Restaurar cópia', 'ghost')}
        ${button('editProfile', 'Editar perfil', 'ghost')}
        ${button('reset', 'Zerar progresso', 'danger')}
      </div>
      <input type='file' id='backupFile' accept='.json,application/json' hidden>
      <p class='micro'>${portalEntitled() ? 'A autorização comercial é controlada pelo Portal Intelectus.' : 'O período de avaliação não reinicia ao editar o perfil, restaurar cópias ou zerar o progresso.'}</p>
    </section>
  `);
    on('parentReport', () => go('report'));
    on('backup', backup);
    on('restore', () => $('backupFile')?.click());
    const backupFile = $('backupFile');
    if (backupFile) {
        backupFile.onchange = (event) => {
            const input = event.target;
            const file = input.files?.[0];
            input.value = '';
            if (file)
                void restore(file);
        };
    }
    document.querySelectorAll('[data-offline-mission][data-offline-status]').forEach((element) => {
        element.onclick = () => {
            const missionId = element.dataset.offlineMission || '';
            const status = element.dataset.offlineStatus;
            if (!missionId || !['independent', 'helped', 'learning'].includes(status))
                return;
            state.offlineMissions[missionId] = status;
            save();
            family();
            say('Registro da missão fora da tela atualizado.');
        };
    });
    on('editProfile', () => {
        setupStep = 1;
        intent = 'map';
        go('setup');
    });
    on('reset', () => {
        if (!confirm('Apagar o perfil e o progresso deste navegador? Exporte uma cópia antes. O período de avaliação não será reiniciado.')) {
            return;
        }
        try {
            localStorage.removeItem(KEY);
            for (const legacy of LEGACY_KEYS)
                localStorage.removeItem(legacy);
        }
        catch {
            say('Não foi possível apagar o armazenamento do navegador.');
            return;
        }
        state = fresh();
        save();
        practiceSession = null;
        miniSession = null;
        bossSession = null;
        placementSession = null;
        go('splash');
        say(portalEntitled() ? 'Perfil e progresso apagados. Sua autorização do Portal permanece válida.' : 'Perfil e progresso apagados. O período de avaliação foi preservado.');
    });
}
render();
if ('serviceWorker' in navigator && location.protocol === 'https:') {
    const registerOffline = () => {
        const workerUrl = portalEntitled()
            ? new URL('/app/gamificacoes/sw.js', window.location.origin).href
            : './sw.js';
        const workerOptions = portalEntitled() ? { scope: '/app/gamificacoes/' } : undefined;
        navigator.serviceWorker
            .register(workerUrl, workerOptions)
            .then((registration) => {
            const notify = () => {
                if (registration.waiting) {
                    say('Uma nova versão está preparada. Conclua a missão, feche todas as abas do Tabuada e reabra o aplicativo. O progresso salvo será preservado.');
                }
            };
            notify();
            registration.addEventListener('updatefound', () => {
                const worker = registration.installing;
                worker?.addEventListener('statechange', () => {
                    if (worker.state === 'installed' && navigator.serviceWorker.controller)
                        notify();
                });
            });
            void registration.update().catch(() => undefined);
        })
            .catch(() => say('O modo offline não pôde ser preparado. O aplicativo continua disponível com internet.'));
    };
    if (document.readyState === 'complete')
        registerOffline();
    else
        window.addEventListener('load', registerOffline, { once: true });
}
