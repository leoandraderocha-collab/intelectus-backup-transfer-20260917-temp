# Intelectus Tabuada — QA V6.6.0 — 15/09/2026

## Produção oficial
- Projeto Vercel: intelectus-tabuada
- Release: V6.6.0-ANNUAL-CONTENT-20260915
- Deployment produção: dpl_HFuWtevNw8YtxwgJe7ZjL7cfM6U4
- Domínio oficial: https://intelectus-tabuada.vercel.app/
- Deployment anterior preservado para rollback: dpl_2MT59xyeQCpvhfx9RkiapY2voZ1V

## Expansão de conteúdo
- Meta pedagógica: 40 semanas, 5 dias/semana, 15 min/dia, ~50 horas.
- Janela antirrepetição: 900 desafios recentes.
- Contextualização combinatória adicionada aos minigames e ao treino adaptativo.
- Revisão espaçada, XP, estrelas, chefões, sondagem, vozes, controles familiares e PWA preservados.

## Gates aprovados
- Sintaxe JavaScript: PASS.
- Integridade de imports/assets/PWA: PASS.
- 5.000 minigames por série: 99,94%–100% de combinações exatas inéditas.
- 3.000 questões adaptativas por série: 99,97%–100% de combinações exatas inéditas.
- 40.000 enunciados: zero padrões detectados de concordância/pontuação auditados.
- Browser real 390×844: sem overflow horizontal.
- 3º e 6º anos: PASS em preview e produção.
- Runtime Vercel: zero erros na última hora após publicação.

## Distribuição pelo Portal
O Portal Intelectus usa um bundle protegido separado em dois arquivos de uma conta de serviço Google Drive. O standalone oficial foi atualizado; a cópia Drive do Portal não foi alterada porque as credenciais sensíveis são redigidas e a conexão Google Drive disponível não tem acesso aos IDs da conta de serviço. Nenhuma tentativa de contornar esse controle foi mantida no código do Portal.
