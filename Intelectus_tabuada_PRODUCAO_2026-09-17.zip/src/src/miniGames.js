import { GAMES, GRADE_META } from './curriculum.js';
import { freshQuestion } from './contentBank.js';
const randomInt = (min, max) => Math.floor(Math.random() * (max - min + 1)) + min;
function shuffle(values) {
    const result = values.slice();
    for (let index = result.length - 1; index > 0; index -= 1) {
        const swap = Math.floor(Math.random() * (index + 1));
        [result[index], result[swap]] = [result[swap], result[index]];
    }
    return result;
}
function numericOptions(expected, spread = 8) {
    const values = new Set([expected]);
    let guard = 0;
    while (values.size < 4 && guard < 40) {
        guard += 1;
        const delta = randomInt(1, Math.max(2, spread));
        const candidate = Math.max(0, expected + (Math.random() > 0.5 ? delta : -delta));
        values.add(candidate);
    }
    return shuffle(Array.from(values).map(String));
}
function tableFactors(grade) {
    const tables = GRADE_META[grade].tables.filter((value) => value >= 2);
    const a = tables[randomInt(0, tables.length - 1)];
    const maxB = grade === '3º Ano' ? 10 : 12;
    return [a, randomInt(2, maxB)];
}
function groupsQuestion(grade) {
    const [a, b] = tableFactors(grade);
    const total = a * b;
    return {
        prompt: `Construa mentalmente ${a} grupos com ${b} elementos. Quantos elementos haverá ao todo?`,
        expression: `${a} × ${b} = ?`,
        options: numericOptions(total, Math.max(a, b)),
        expected: String(total),
        explanation: `${a} grupos de ${b} correspondem a ${a} × ${b}. O total é ${total}.`,
        scene: { kind: 'groups', groups: a, perGroup: b, total },
    };
}
function factorQuestion(grade) {
    const [a, b] = tableFactors(grade);
    const total = a * b;
    const hidden = Math.random() > 0.5 ? 'a' : 'b';
    const expected = hidden === 'a' ? a : b;
    return {
        prompt: 'Abra o cadeado encontrando o fator que está escondido.',
        expression: hidden === 'a' ? `? × ${b} = ${total}` : `${a} × ? = ${total}`,
        options: numericOptions(expected, 4),
        expected: String(expected),
        explanation: `Use a operação inversa: ${total} ÷ ${hidden === 'a' ? b : a} = ${expected}.`,
        scene: { kind: 'factor', a, b, total, hidden },
    };
}
function divisionQuestion(grade) {
    const divisor = randomInt(2, grade === '3º Ano' ? 10 : 12);
    const quotient = randomInt(2, grade === '3º Ano' ? 10 : 12);
    const remainder = grade === '3º Ano' && Math.random() > 0.5 ? randomInt(1, divisor - 1) : 0;
    const total = divisor * quotient + remainder;
    const expected = remainder ? `${quotient} e sobra ${remainder}` : String(quotient);
    const options = remainder
        ? shuffle([
            expected,
            `${Math.max(1, quotient - 1)} e sobra ${remainder}`,
            `${quotient + 1} e sobra ${remainder}`,
            `${quotient} e sobra ${remainder === 1 ? 2 : remainder - 1}`,
        ])
        : numericOptions(quotient, 4);
    return {
        prompt: remainder
            ? `A torre tem ${total} blocos. Cada andar recebe ${divisor}. Quantos andares completos podem ser montados e quantos blocos sobram?`
            : `A torre tem ${total} blocos. Cada andar deve receber ${divisor}. Quantos andares completos podem ser montados?`,
        expression: `${total} ÷ ${divisor}`,
        options,
        expected,
        explanation: remainder
            ? `${divisor} × ${quotient} = ${divisor * quotient}; para chegar a ${total}, ainda sobram ${remainder} bloco${remainder === 1 ? '' : 's'}. Resposta: ${expected}.`
            : `${divisor} × ${quotient} = ${total}, então ${total} ÷ ${divisor} = ${quotient}.`,
        scene: { kind: 'division', total, divisor, quotient, remainder },
    };
}
function marketQuestion(grade) {
    const unit = grade === '5º Ano' || grade === '6º Ano' ? randomInt(3, 18) : randomInt(2, 10);
    const quantity = randomInt(2, grade === '3º Ano' ? 5 : 9);
    const total = unit * quantity;
    return {
        prompt: `No Mercado Intelectus, cada item custa R$ ${unit}. Coloque ${quantity} itens no carrinho. Qual será o total?`,
        expression: `${quantity} × R$ ${unit}`,
        options: numericOptions(total, unit),
        expected: String(total),
        explanation: `Preço total = quantidade × preço unitário: ${quantity} × ${unit} = ${total}.`,
        scene: { kind: 'market', unit, quantity, total },
    };
}
function patternQuestion(grade) {
    const [step] = tableFactors(grade);
    const startMultiplier = randomInt(1, 5);
    const values = [0, 1, 2, 3].map((offset) => step * (startMultiplier + offset));
    const expected = step * (startMultiplier + 4);
    return {
        prompt: 'Siga as pistas do Detetive de Padrões e descubra o próximo número.',
        expression: `${values.join(' → ')} → ?`,
        options: numericOptions(expected, step * 2),
        expected: String(expected),
        explanation: `A sequência aumenta de ${step} em ${step}. O próximo termo é ${expected}.`,
        scene: { kind: 'pattern', values, step, expected },
    };
}
function combinationsQuestion(grade) {
    const max = grade === '4º Ano' ? 4 : grade === '5º Ano' ? 6 : 7;
    const first = randomInt(2, max);
    const second = randomInt(2, max);
    const total = first * second;
    const visual = grade === '4º Ano';
    return {
        prompt: visual
            ? `Há ${first} opções de camiseta e ${second} opções de calça. Quantos pares diferentes podemos montar escolhendo uma de cada?`
            : `Uma escolha tem ${first} possibilidades e outra tem ${second}. Quantas combinações diferentes existem?`,
        expression: `${first} possibilidades × ${second} possibilidades`,
        options: numericOptions(total, 6),
        expected: String(total),
        explanation: `Cada uma das ${first} opções do primeiro grupo pode ser combinada com ${second} do segundo: ${first} × ${second} = ${total}.`,
        scene: { kind: 'combinations', first, second, total, visual },
    };
}
function percentageQuestion(grade) {
    const fifth = [10, 25, 50, 75, 100];
    const sixth = [5, 10, 15, 20, 25, 30, 40, 50, 60, 75, 80, 100];
    const pool = grade === '6º Ano' ? sixth : fifth;
    const percent = pool[randomInt(0, pool.length - 1)];
    const bases = grade === '6º Ano' ? [40, 60, 80, 100, 120, 160, 200, 240, 300, 400] : [20, 40, 60, 80, 100, 120, 200];
    const base = bases[randomInt(0, bases.length - 1)];
    const amount = (base * percent) / 100;
    const mode = grade === '6º Ano' && percent < 100
        ? ['part', 'discount', 'increase'][randomInt(0, 2)]
        : 'part';
    const expected = mode === 'discount' ? base - amount : mode === 'increase' ? base + amount : amount;
    const prompt = mode === 'discount'
        ? `Um produto de R$ ${base} recebeu ${percent}% de desconto. Qual é o novo preço?`
        : mode === 'increase'
            ? `Um valor de R$ ${base} aumentou ${percent}%. Qual é o novo valor?`
            : `Complete a barra: quanto é ${percent}% de ${base}?`;
    const explanation = mode === 'discount'
        ? `${percent}% de ${base} = ${amount}. Então ${base} − ${amount} = ${expected}.`
        : mode === 'increase'
            ? `${percent}% de ${base} = ${amount}. Então ${base} + ${amount} = ${expected}.`
            : `${percent}% de ${base} = ${amount}. A resposta é ${expected}.`;
    return {
        prompt,
        expression: mode === 'part' ? `${percent}% de ${base}` : mode === 'discount' ? `${base} − ${percent}%` : `${base} + ${percent}%`,
        options: numericOptions(expected, Math.max(5, Math.round(base / 10))),
        expected: String(expected),
        explanation,
        scene: { kind: 'percentage', percent, base, expected, mode, amount },
    };
}
function divisibilityRule(rule) {
    const rules = {
        2: 'termina em 0, 2, 4, 6 ou 8',
        3: 'a soma dos algarismos é múltipla de 3',
        4: 'os dois últimos algarismos formam múltiplo de 4',
        5: 'termina em 0 ou 5',
        6: 'é divisível por 2 e por 3',
        8: 'os três últimos algarismos formam múltiplo de 8',
        9: 'a soma dos algarismos é múltipla de 9',
        10: 'termina em 0',
        100: 'termina em 00',
        1000: 'termina em 000',
    };
    return rules[rule] || `é múltiplo de ${rule}`;
}
function multipleQuestion(grade) {
    if (grade === '6º Ano' && Math.random() > 0.35) {
        const criteria = [2, 3, 4, 5, 6, 8, 9, 10, 100, 1000];
        const criterion = criteria[randomInt(0, criteria.length - 1)];
        const multiplier = randomInt(2, criterion >= 100 ? 9 : 25);
        const correct = criterion * multiplier;
        const wrong = new Set();
        let guard = 0;
        while (wrong.size < 3 && guard < 200) {
            guard += 1;
            const span = criterion >= 100 ? criterion * 3 : 50;
            const candidate = Math.max(1, correct + randomInt(-span, span));
            if (candidate !== correct && candidate % criterion !== 0)
                wrong.add(candidate);
        }
        return {
            prompt: `Radar da Divisibilidade: qual número é divisível por ${criterion}?`,
            expression: `Critério: ${divisibilityRule(criterion)}`,
            options: shuffle([String(correct), ...Array.from(wrong).map(String)]),
            expected: String(correct),
            explanation: `${correct} é divisível por ${criterion}: ${correct} ÷ ${criterion} = ${correct / criterion}. Pelo critério, ${divisibilityRule(criterion)}.`,
            scene: { kind: 'multiples', base: criterion, correct, mode: 'criterion', criterion },
        };
    }
    const base = randomInt(2, 10);
    const correct = base * randomInt(3, 10);
    const wrong = new Set();
    while (wrong.size < 3) {
        const candidate = randomInt(Math.max(2, correct - 15), correct + 15);
        if (candidate % base !== 0)
            wrong.add(candidate);
    }
    return {
        prompt: `Acerte o alvo que é múltiplo de ${base}.`,
        expression: `Procure um número da forma ${base} × n`,
        options: shuffle([String(correct), ...Array.from(wrong).map(String)]),
        expected: String(correct),
        explanation: `${correct} é múltiplo de ${base} porque ${correct} = ${base} × ${correct / base}.`,
        scene: { kind: 'multiples', base, correct, mode: 'multiple' },
    };
}
function divisorQuestion() {
    const a = randomInt(2, 10);
    const b = randomInt(2, 10);
    const value = a * b;
    const correct = Math.random() > 0.5 ? a : b;
    const wrong = new Set();
    while (wrong.size < 3) {
        const candidate = randomInt(2, 12);
        if (value % candidate !== 0 && candidate !== correct)
            wrong.add(candidate);
    }
    return {
        prompt: `No laboratório, escolha um número que divida ${value} exatamente, sem resto.`,
        expression: `${value} ÷ ? = número natural`,
        options: shuffle([String(correct), ...Array.from(wrong).map(String)]),
        expected: String(correct),
        explanation: `${correct} é divisor de ${value} porque ${value} ÷ ${correct} = ${value / correct}, sem resto.`,
        scene: { kind: 'divisors', value, correct },
    };
}
function divisorsOf(value) {
    const divisors = [];
    for (let divisor = 1; divisor <= value; divisor += 1) {
        if (value % divisor === 0)
            divisors.push(divisor);
    }
    return divisors;
}
function primeQuestion() {
    const value = randomInt(2, 49);
    const divisors = divisorsOf(value);
    const prime = divisors.length === 2;
    return {
        prompt: `Analise o código ${value}. Ele é primo ou composto?`,
        expression: `Quantos divisores naturais ${value} possui?`,
        options: ['Primo', 'Composto'],
        expected: prime ? 'Primo' : 'Composto',
        explanation: prime
            ? `${value} tem exatamente dois divisores naturais: 1 e ${value}.`
            : `${value} possui os divisores ${divisors.slice(0, 8).join(', ')}${divisors.length > 8 ? '...' : ''}; portanto, é composto.`,
        scene: { kind: 'prime', value, prime, divisors },
    };
}
function powerQuestion() {
    const base = randomInt(2, 6);
    const exponent = randomInt(2, 3);
    const expected = base ** exponent;
    const factors = Array.from({ length: exponent }, () => String(base)).join(' × ');
    return {
        prompt: `A nave precisa calcular ${base} elevado a ${exponent}. Qual é o resultado?`,
        expression: `${base}${exponent === 2 ? '²' : '³'} = ?`,
        options: numericOptions(expected, Math.max(base * exponent, 4)),
        expected: String(expected),
        explanation: `${base}${exponent === 2 ? '²' : '³'} significa ${factors}. O resultado é ${expected}.`,
        scene: { kind: 'power', base, exponent, expected },
    };
}
function expressionQuestion() {
    const a = randomInt(2, 9);
    const b = randomInt(2, 8);
    const c = randomInt(2, 6);
    const mode = randomInt(0, 2);
    if (mode === 0) {
        const expected = a + b * c;
        return {
            prompt: 'Resolva a expressão respeitando a prioridade da multiplicação.',
            expression: `${a} + ${b} × ${c}`,
            options: numericOptions(expected, Math.max(5, b * c)),
            expected: String(expected),
            explanation: `Primeiro ${b} × ${c} = ${b * c}. Depois ${a} + ${b * c} = ${expected}.`,
            scene: { kind: 'expression', expression: `${a} + ${b} × ${c}`, steps: [`${b} × ${c} = ${b * c}`, `${a} + ${b * c} = ${expected}`], expected },
        };
    }
    if (mode === 1) {
        const expected = (a + b) * c;
        return {
            prompt: 'Resolva primeiro o que está entre parênteses e depois multiplique.',
            expression: `(${a} + ${b}) × ${c}`,
            options: numericOptions(expected, Math.max(5, c * 3)),
            expected: String(expected),
            explanation: `Primeiro ${a} + ${b} = ${a + b}. Depois ${a + b} × ${c} = ${expected}.`,
            scene: { kind: 'expression', expression: `(${a} + ${b}) × ${c}`, steps: [`${a} + ${b} = ${a + b}`, `${a + b} × ${c} = ${expected}`], expected },
        };
    }
    const product = a * b;
    const subtract = Math.min(c, product - 1);
    const expected = product - subtract;
    return {
        prompt: 'Resolva a expressão fazendo a multiplicação antes da subtração.',
        expression: `${a} × ${b} − ${subtract}`,
        options: numericOptions(expected, Math.max(5, a)),
        expected: String(expected),
        explanation: `Primeiro ${a} × ${b} = ${product}. Depois ${product} − ${subtract} = ${expected}.`,
        scene: { kind: 'expression', expression: `${a} × ${b} − ${subtract}`, steps: [`${a} × ${b} = ${product}`, `${product} − ${subtract} = ${expected}`], expected },
    };
}
function generateBaseMiniQuestion(gameId, grade) {
    switch (gameId) {
        case 'grupos':
            return groupsQuestion(grade);
        case 'fator':
            return factorQuestion(grade);
        case 'divisao':
            return divisionQuestion(grade);
        case 'mercado':
            return marketQuestion(grade);
        case 'padroes':
            return patternQuestion(grade);
        case 'combinacoes':
            return combinationsQuestion(grade);
        case 'porcentagem':
            return percentageQuestion(grade);
        case 'multiplos':
            return multipleQuestion(grade);
        case 'divisores':
            return divisorQuestion();
        case 'primos':
            return primeQuestion();
        case 'potencias':
            return powerQuestion();
        case 'expressoes':
            return expressionQuestion();
        default: {
            const exhaustive = gameId;
            throw new Error(`Jogo não suportado: ${String(exhaustive)}`);
        }
    }
}
export function generateMiniQuestion(gameId, grade, options = {}) {
    return freshQuestion(() => generateBaseMiniQuestion(gameId, grade), gameId, grade, options);
}

export function gameTitle(gameId) {
    return GAMES[gameId].title;
}
