export const GRADE_ORDER = ['3º Ano', '4º Ano', '5º Ano', '6º Ano'];
export const GRADE_META = {
    '3º Ano': {
        grade: '3º Ano',
        title: 'Explorador dos Grupos',
        subtitle: 'Construir fatos básicos, perceber regularidades e compreender multiplicação e divisão com representações.',
        icon: '🧭',
        tables: [0, 1, 2, 3, 4, 5, 10],
    },
    '4º Ano': {
        grade: '4º Ano',
        title: 'Aventureiro das Estratégias',
        subtitle: 'Ampliar estratégias, propriedades e relações inversas para ganhar fluência em multiplicação e divisão.',
        icon: '🚀',
        tables: [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10],
    },
    '5º Ano': {
        grade: '5º Ano',
        title: 'Estrategista Matemático',
        subtitle: 'Aplicar operações, incógnitas, combinações, proporcionalidade e porcentagens em situações de raciocínio.',
        icon: '🧠',
        tables: [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10],
    },
    '6º Ano': {
        grade: '6º Ano',
        title: 'Mestre dos Números',
        subtitle: 'Consolidar operações e investigar potências, múltiplos, divisores, números primos e porcentagens.',
        icon: '🏆',
        tables: [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10],
    },
};
export const GRADES = Object.fromEntries(GRADE_ORDER.map((grade) => [grade, GRADE_META[grade].tables]));
export const GAMES = {
    grupos: {
        id: 'grupos',
        title: 'Construtor de Grupos',
        icon: '🧱',
        short: 'Veja a multiplicação nascer de grupos iguais.',
    },
    fator: {
        id: 'fator',
        title: 'Fator Oculto',
        icon: '🔍',
        short: 'Descubra o número que completa uma igualdade multiplicativa.',
    },
    divisao: {
        id: 'divisao',
        title: 'Torre da Divisão',
        icon: '🏰',
        short: 'Reparta, meça e use a relação inversa da multiplicação.',
    },
    mercado: {
        id: 'mercado',
        title: 'Mercado Intelectus',
        icon: '🛒',
        short: 'Calcule quantidades, preços e relações proporcionais.',
    },
    padroes: {
        id: 'padroes',
        title: 'Detetive de Padrões',
        icon: '🕵️',
        short: 'Reconheça regularidades e continue sequências numéricas.',
    },
    combinacoes: {
        id: 'combinacoes',
        title: 'Laboratório de Combinações',
        icon: '🧩',
        short: 'Use o princípio multiplicativo para contar possibilidades.',
    },
    porcentagem: {
        id: 'porcentagem',
        title: 'Desafio das Porcentagens',
        icon: '💯',
        short: 'Relacione porcentagens usuais, frações e quantidades.',
    },
    multiplos: {
        id: 'multiplos',
        title: 'Caça aos Múltiplos',
        icon: '🎯',
        short: 'Identifique múltiplos e investigue regularidades.',
    },
    divisores: {
        id: 'divisores',
        title: 'Laboratório dos Divisores',
        icon: '🧪',
        short: 'Descubra fatores e divisores de números naturais.',
    },
    primos: {
        id: 'primos',
        title: 'Código Primo',
        icon: '🔐',
        short: 'Diferencie números primos e compostos por investigação.',
    },
    potencias: {
        id: 'potencias',
        title: 'Potência Espacial',
        icon: '🌌',
        short: 'Interprete potências como multiplicações de fatores iguais.',
    },
    expressoes: {
        id: 'expressoes',
        title: 'Torre das Expressões',
        icon: '🧮',
        short: 'Resolva expressões respeitando agrupamentos e ordem das operações.',
    },
};
export const SKILLS = [
    {
        id: '3-fatos',
        grade: '3º Ano',
        bncc: ['EF03MA03', 'EF03MA10'],
        partialBncc: ['EF03MA10'],
        title: 'Fatos básicos e regularidades',
        description: 'Construir fatos básicos da multiplicação e reconhecer regularidades em sequências para apoiar cálculo mental.',
        icon: '🔢',
        games: ['padroes', 'grupos'],
        level: 1,
    },
    {
        id: '3-grupos',
        grade: '3º Ano',
        bncc: ['EF03MA07'],
        title: 'Grupos iguais e disposição retangular',
        description: 'Resolver situações de multiplicação por 2, 3, 4, 5 e 10 usando grupos iguais, disposição retangular e estratégias próprias.',
        icon: '🧱',
        games: ['grupos', 'fator'],
        level: 1,
    },
    {
        id: '3-divisao',
        grade: '3º Ano',
        bncc: ['EF03MA08'],
        title: 'Repartir e medir',
        description: 'Compreender divisão por repartição equitativa e medida, com resto zero ou diferente de zero em situações adequadas.',
        icon: '🍎',
        games: ['divisao', 'fator'],
        level: 2,
    },
    {
        id: '4-relacoes',
        grade: '4º Ano',
        bncc: ['EF04MA04', 'EF04MA05', 'EF04MA11', 'EF04MA13', 'EF04MA15'],
        partialBncc: ['EF04MA04', 'EF04MA05', 'EF04MA11', 'EF04MA13', 'EF04MA15'],
        title: 'Estratégias, propriedades e relações inversas',
        description: 'Usar propriedades, relações entre multiplicação e divisão, múltiplos e termos desconhecidos para ampliar estratégias de cálculo.',
        icon: '⚙️',
        games: ['fator', 'padroes', 'multiplos'],
        level: 2,
    },
    {
        id: '4-multiplicacao',
        grade: '4º Ano',
        bncc: ['EF04MA06'],
        title: 'Multiplicação com diferentes significados',
        description: 'Resolver problemas com parcelas iguais, organização retangular e proporcionalidade usando estratégias variadas.',
        icon: '🚀',
        games: ['grupos', 'mercado', 'fator'],
        level: 2,
    },
    {
        id: '4-divisao',
        grade: '4º Ano',
        bncc: ['EF04MA07'],
        title: 'Divisão e estratégias de cálculo',
        description: 'Resolver situações de repartição e medida utilizando cálculo mental, estimativas e relações inversas.',
        icon: '🏰',
        games: ['divisao', 'fator'],
        level: 2,
    },
    {
        id: '4-combinacoes',
        grade: '4º Ano',
        bncc: ['EF04MA08'],
        title: 'Combinações iniciais',
        description: 'Contar possibilidades simples combinando elementos de duas coleções, com apoio visual e organização sistemática.',
        icon: '🧩',
        games: ['combinacoes', 'grupos'],
        level: 2,
    },
    {
        id: '5-operacoes',
        grade: '5º Ano',
        bncc: ['EF05MA08'],
        partialBncc: ['EF05MA08'],
        title: 'Multiplicação e divisão em problemas',
        description: 'Escolher estratégias de cálculo para resolver situações com números naturais e relações multiplicativas do cotidiano.',
        icon: '🛒',
        games: ['mercado', 'divisao', 'fator'],
        level: 3,
    },
    {
        id: '5-incognitas',
        grade: '5º Ano',
        bncc: ['EF05MA11'],
        partialBncc: ['EF05MA11'],
        title: 'Termos desconhecidos e equivalência',
        description: 'Descobrir termos desconhecidos em igualdades, articulando multiplicação e divisão como operações relacionadas.',
        icon: '❓',
        games: ['fator', 'padroes'],
        level: 3,
    },
    {
        id: '5-combinacoes',
        grade: '5º Ano',
        bncc: ['EF05MA09'],
        title: 'Princípio multiplicativo',
        description: 'Contar combinações possíveis organizando possibilidades e usando raciocínio multiplicativo.',
        icon: '🧩',
        games: ['combinacoes', 'padroes'],
        level: 3,
    },
    {
        id: '5-proporcao',
        grade: '5º Ano',
        bncc: ['EF05MA06', 'EF05MA12'],
        partialBncc: ['EF05MA12'],
        title: 'Proporcionalidade e porcentagens usuais',
        description: 'Relacionar quantidade, preço e porcentagens usuais com estratégias pessoais, cálculo mental e proporcionalidade direta.',
        icon: '💯',
        games: ['mercado', 'porcentagem'],
        level: 3,
    },
    {
        id: '6-operacoes',
        grade: '6º Ano',
        bncc: ['EF06MA03', 'EF06MA11'],
        partialBncc: ['EF06MA11'],
        title: 'Operações, expressões e potenciação',
        description: 'Resolver cálculos e expressões com compreensão dos processos, incluindo potenciação em situações adequadas.',
        icon: '🌌',
        games: ['potencias', 'expressoes', 'fator'],
        level: 4,
    },
    {
        id: '6-multiplos',
        grade: '6º Ano',
        bncc: ['EF06MA05', 'EF06MA06'],
        partialBncc: ['EF06MA06'],
        title: 'Múltiplos, critérios de divisibilidade e padrões',
        description: 'Investigar múltiplos e aplicar critérios de divisibilidade por 2, 3, 4, 5, 6, 8, 9, 10, 100 e 1000 em problemas e classificações.',
        icon: '🎯',
        games: ['multiplos', 'padroes'],
        level: 4,
    },
    {
        id: '6-divisores',
        grade: '6º Ano',
        bncc: ['EF06MA05', 'EF06MA06'],
        partialBncc: ['EF06MA06'],
        title: 'Divisores e fatores',
        description: 'Reconhecer divisores, fatores e relações entre multiplicação e divisão em números naturais.',
        icon: '🧪',
        games: ['divisores', 'fator'],
        level: 4,
    },
    {
        id: '6-primos',
        grade: '6º Ano',
        bncc: ['EF06MA05'],
        title: 'Números primos e compostos',
        description: 'Classificar números naturais como primos ou compostos a partir da investigação de seus divisores.',
        icon: '🔐',
        games: ['primos', 'divisores'],
        level: 4,
    },
    {
        id: '6-porcentagem',
        grade: '6º Ano',
        bncc: ['EF06MA13'],
        partialBncc: ['EF06MA13'],
        title: 'Porcentagens, descontos e acréscimos',
        description: 'Resolver porcentagens além das frações usuais, incluindo descontos e acréscimos simples com estratégias de proporcionalidade.',
        icon: '📊',
        games: ['porcentagem', 'mercado'],
        level: 4,
    },
];
export const BNCC_CODES = Array.from(new Set(SKILLS.flatMap((skill) => skill.bncc)));
export function normalizeGrade(value) {
    if (value === '6º Ano ou mais')
        return '6º Ano';
    if (value === '2º Ano')
        return '3º Ano';
    if (typeof value === 'string' && GRADE_ORDER.includes(value))
        return value;
    return '3º Ano';
}
export function skillsForGrade(grade) {
    return SKILLS.filter((skill) => skill.grade === grade);
}
export function findSkill(id) {
    return SKILLS.find((skill) => skill.id === id);
}
export function gradeIndex(grade) {
    return GRADE_ORDER.indexOf(grade);
}
export const BNCC_CENTRAL_CODES = Array.from(new Set(SKILLS.flatMap((skill) => skill.bncc.filter((code) => !(skill.partialBncc || []).includes(code)))));
export const BNCC_PARTIAL_CODES = Array.from(new Set(SKILLS.flatMap((skill) => skill.partialBncc || [])));
