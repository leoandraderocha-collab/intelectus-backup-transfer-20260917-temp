import { GRADE_ORDER, skillsForGrade } from './curriculum.js';
export const STORIES = {
    '3º Ano': {
        title: 'O Vale dos Grupos',
        place: 'Vale dos Grupos',
        intro: 'As pontes do vale funcionam quando quantidades são organizadas em grupos iguais e repartidas com equilíbrio.',
        goal: 'Reconstrua as pontes dominando agrupamentos, multiplicação e divisão.',
        icon: '🌉',
    },
    '4º Ano': {
        title: 'A Estação das Estratégias',
        place: 'Estação das Estratégias',
        intro: 'Uma estação espacial perdeu energia. Cada setor volta a funcionar quando uma estratégia de cálculo é compreendida e aplicada.',
        goal: 'Reative os setores usando diferentes significados da multiplicação e da divisão.',
        icon: '🛰️',
    },
    '5º Ano': {
        title: 'A Cidade das Possibilidades',
        place: 'Cidade das Possibilidades',
        intro: 'Mercados, rotas e escolhas da cidade dependem de raciocínio multiplicativo, proporcionalidade e combinações.',
        goal: 'Organize a cidade resolvendo situações de quantidade, proporção e possibilidades.',
        icon: '🏙️',
    },
    '6º Ano': {
        title: 'O Arquivo dos Números',
        place: 'Arquivo dos Números',
        intro: 'Os arquivos secretos foram codificados com operações, potências, múltiplos, divisores, números primos e porcentagens.',
        goal: 'Decifre os códigos articulando operações, potenciação, divisibilidade, primalidade e proporcionalidade.',
        icon: '🗃️',
    },
};
export const BOSSES = {
    '3º Ano': {
        title: 'Guardião dos Grupos',
        icon: '🐉',
        intro: 'O Guardião mistura agrupamentos e repartições. Mostre que você compreende as relações entre eles.',
        victory: 'As pontes do Vale dos Grupos foram restauradas.',
    },
    '4º Ano': {
        title: 'Robô das Estratégias',
        icon: '🤖',
        intro: 'O robô troca as operações e os contextos. Escolha estratégias, não apenas resultados decorados.',
        victory: 'A Estação das Estratégias voltou a operar com energia total.',
    },
    '5º Ano': {
        title: 'Mestre das Possibilidades',
        icon: '🧙',
        intro: 'O Mestre combina preços, possibilidades e proporções. Resolva cada situação com raciocínio.',
        victory: 'A Cidade das Possibilidades está organizada e funcionando.',
    },
    '6º Ano': {
        title: 'Sentinela dos Números',
        icon: '🗿',
        intro: 'A Sentinela protege o arquivo com operações, potências, múltiplos, divisores, fatores, primos e porcentagens.',
        victory: 'O Arquivo dos Números foi decifrado e liberado.',
    },
};
export const COLLECTIBLES = [
    { id: '3-bussola', grade: '3º Ano', icon: '🧭', title: 'Bússola dos Grupos', description: 'Obtida ao concluir a sondagem do 3º ano.', unlock: 'placement' },
    { id: '3-bloco', grade: '3º Ano', icon: '🧱', title: 'Bloco Dourado', description: 'Obtido ao explorar todas as habilidades do vale.', unlock: 'exploration' },
    { id: '3-fruta', grade: '3º Ano', icon: '🍎', title: 'Símbolo do Equilíbrio', description: 'Obtido ao conquistar uma estrela em todas as habilidades.', unlock: 'stars' },
    { id: '3-medalha', grade: '3º Ano', icon: '🏅', title: 'Medalha do Vale', description: 'Obtida ao superar o Guardião dos Grupos.', unlock: 'boss' },
    { id: '4-mapa', grade: '4º Ano', icon: '🗺️', title: 'Mapa de Estratégias', description: 'Obtido ao concluir a sondagem do 4º ano.', unlock: 'placement' },
    { id: '4-engrenagem', grade: '4º Ano', icon: '⚙️', title: 'Engrenagem do Cálculo', description: 'Obtida ao explorar todas as habilidades da estação.', unlock: 'exploration' },
    { id: '4-cristal', grade: '4º Ano', icon: '🔷', title: 'Cristal de Estratégias', description: 'Obtido ao conquistar uma estrela em todas as habilidades.', unlock: 'stars' },
    { id: '4-medalha', grade: '4º Ano', icon: '🏅', title: 'Medalha da Estação', description: 'Obtida ao superar o Robô das Estratégias.', unlock: 'boss' },
    { id: '5-passe', grade: '5º Ano', icon: '🎫', title: 'Passe da Cidade', description: 'Obtido ao concluir a sondagem do 5º ano.', unlock: 'placement' },
    { id: '5-moeda', grade: '5º Ano', icon: '🪙', title: 'Moeda Intelectus', description: 'Obtida ao explorar todas as habilidades da cidade.', unlock: 'exploration' },
    { id: '5-selo', grade: '5º Ano', icon: '💯', title: 'Selo de Proporção', description: 'Obtido ao conquistar uma estrela em todas as habilidades.', unlock: 'stars' },
    { id: '5-medalha', grade: '5º Ano', icon: '🏅', title: 'Medalha da Cidade', description: 'Obtida ao superar o Mestre das Possibilidades.', unlock: 'boss' },
    { id: '6-chave', grade: '6º Ano', icon: '🗝️', title: 'Chave do Arquivo', description: 'Obtida ao concluir a sondagem do 6º ano.', unlock: 'placement' },
    { id: '6-frasco', grade: '6º Ano', icon: '🧪', title: 'Frasco dos Divisores', description: 'Obtido ao explorar todas as habilidades do arquivo.', unlock: 'exploration' },
    { id: '6-primo', grade: '6º Ano', icon: '🔐', title: 'Selo Primo', description: 'Obtido ao conquistar uma estrela em todas as habilidades.', unlock: 'stars' },
    { id: '6-medalha', grade: '6º Ano', icon: '🏅', title: 'Medalha do Arquivo', description: 'Obtida ao superar a Sentinela dos Números.', unlock: 'boss' },
];
export function gradeSkillsReady(state, grade) {
    const skills = skillsForGrade(grade);
    const explored = skills.filter((skill) => (state.skills[skill.id]?.played || 0) >= 3).length;
    const starred = skills.filter((skill) => (state.skills[skill.id]?.stars || 0) >= 1).length;
    const doubleStarred = skills.filter((skill) => (state.skills[skill.id]?.stars || 0) >= 2).length;
    return { explored, starred, doubleStarred, total: skills.length };
}
export function bossUnlocked(state, grade) {
    const ready = gradeSkillsReady(state, grade);
    return ready.total > 0 && ready.starred === ready.total;
}
export function bossCompleted(state, grade) {
    return state.bosses[grade]?.completed === true;
}
export function missionsForGrade(state, grade) {
    const ready = gradeSkillsReady(state, grade);
    const placementDone = Boolean(state.placements[grade] || state.placement?.grade === grade);
    const boss = bossCompleted(state, grade);
    return [
        {
            id: 'placement', icon: '🧭', title: 'Encontrar o ponto de partida',
            description: 'Concluir a sondagem formativa do ano.', done: placementDone,
            current: placementDone ? 1 : 0, target: 1,
        },
        {
            id: 'exploration', icon: '🎮', title: 'Explorar o capítulo',
            description: 'Responder ao menos 3 desafios em cada habilidade.', done: ready.explored === ready.total,
            current: ready.explored, target: ready.total,
        },
        {
            id: 'stars', icon: '⭐', title: 'Acender as estrelas',
            description: 'Conquistar ao menos 1 estrela em cada habilidade.', done: ready.starred === ready.total,
            current: ready.starred, target: ready.total,
        },
        {
            id: 'boss', icon: BOSSES[grade].icon, title: 'Superar o Chefão Matemático',
            description: `Vencer ${BOSSES[grade].title} com pelo menos 75% de acertos.`, done: boss,
            current: boss ? 1 : 0, target: 1,
        },
        {
            id: 'mastery', icon: '🌟', title: 'Aprofundar estratégias',
            description: 'Conquistar ao menos 2 estrelas em cada habilidade do ano.', done: ready.doubleStarred === ready.total,
            current: ready.doubleStarred, target: ready.total,
        },
    ];
}
export function collectibleUnlocked(state, item) {
    const ready = gradeSkillsReady(state, item.grade);
    if (item.unlock === 'placement')
        return Boolean(state.placements[item.grade] || state.placement?.grade === item.grade);
    if (item.unlock === 'exploration')
        return ready.total > 0 && ready.explored === ready.total;
    if (item.unlock === 'stars')
        return ready.total > 0 && ready.starred === ready.total;
    return bossCompleted(state, item.grade);
}
export function collectiblesForGrade(state, grade) {
    return COLLECTIBLES.filter((item) => item.grade === grade).map((item) => ({ ...item, unlocked: collectibleUnlocked(state, item) }));
}
export function allCollectibles(state) {
    return COLLECTIBLES.map((item) => ({ ...item, unlocked: collectibleUnlocked(state, item) }));
}
export function achievements(state) {
    const gameValues = Object.values(state.games);
    const completedGames = gameValues.filter((game) => game.completions > 0).length;
    const totalCompletions = gameValues.reduce((total, game) => total + game.completions, 0);
    const bestStreak = Math.max(0, ...Object.values(state.skills).map((skill) => skill.bestStreak));
    const totalStars = Object.values(state.skills).reduce((total, skill) => total + skill.stars, 0);
    const bosses = GRADE_ORDER.filter((grade) => bossCompleted(state, grade)).length;
    const collected = allCollectibles(state).filter((item) => item.unlocked).length;
    const consolidatedFacts = Object.values(state.facts).filter((fact) => {
        const evidence = fact.e.slice(-6);
        const good = evidence.filter((value) => value.ok);
        return evidence.length >= 3 && good.length / evidence.length >= 0.8 && new Set(good.map((value) => value.day)).size >= 2 && new Set(good.map((value) => value.kind)).size >= 2;
    }).length;
    return [
        { id: 'first-game', icon: '🎮', title: 'Primeira Missão', description: 'Concluir um game pela primeira vez.', unlocked: totalCompletions >= 1 },
        { id: 'explorer', icon: '🧭', title: 'Explorador de Games', description: 'Concluir pelo menos 5 games diferentes.', unlocked: completedGames >= 5 },
        { id: 'streak', icon: '🔥', title: 'Sequência Brilhante', description: 'Alcançar sequência de 5 acertos em uma habilidade.', unlocked: bestStreak >= 5 },
        { id: 'stars', icon: '🌟', title: 'Constelação Matemática', description: 'Somar 8 estrelas de habilidade.', unlocked: totalStars >= 8 },
        { id: 'fluency', icon: '⚡', title: 'Fluência em Construção', description: 'Consolidar 10 fatos de tabuada pelo critério pedagógico.', unlocked: consolidatedFacts >= 10 },
        { id: 'collector', icon: '🎒', title: 'Colecionador', description: 'Desbloquear 6 relíquias da jornada.', unlocked: collected >= 6 },
        { id: 'boss', icon: '🏆', title: 'Vencedor de Chefão', description: 'Superar pelo menos um Chefão Matemático.', unlocked: bosses >= 1 },
        { id: 'all-bosses', icon: '👑', title: 'Mestre da Jornada', description: 'Superar os quatro Chefões Matemáticos.', unlocked: bosses === GRADE_ORDER.length },
    ];
}
