export const CONTENT_PLAN = Object.freeze({
  weeks: 40,
  daysPerWeek: 5,
  minutesPerDay: 15,
  targetHours: 50,
  recentWindow: 900,
  antiRepeatAttempts: 120,
  release: 'V6.7.2-LOGO-BNCC-CONTRAST-20260916',
});

const PLACES = [
  'laboratório de robótica','biblioteca','observatório','horta da escola','estação espacial','museu de ciências',
  'oficina de invenções','parque de aventuras','aquário','planetário','cidade dos jogos','centro esportivo',
  'feira de ciências','ilha dos desafios','estúdio de criação','trilha ecológica','sala de enigmas','porto das descobertas',
  'acampamento matemático','torre de pesquisa','mercado da cidade','arena de estratégias','mapa do tesouro','central de missões'
];
const ITEMS = [
  'blocos','figurinhas','cartões','estrelas','peças','livros','sementes','adesivos','moedas','cristais','fichas','bolinhas',
  'robôs','lápis','ingressos','pacotes','frutas','cápsulas','medalhas','botões','cubos','selos','marcadores','tokens'
];
const MISSIONS = [
  'missão relâmpago','desafio secreto','etapa da expedição','teste do painel','rota de descoberta','fase bônus','desafio do dia','código da equipe',
  'pista especial','prova do explorador','tarefa do laboratório','missão do mapa','desafio da torre','etapa do campeonato','protocolo de bordo','enigma do arquivo'
];
const randomInt=(min,max)=>Math.floor(Math.random()*(max-min+1))+min;
const sceneKey=(scene={})=>Object.keys(scene).sort().map(key=>{
  const value=scene[key];
  return `${key}=${Array.isArray(value)?value.join('.'):String(value)}`;
}).join(';');

function contextualPrompt(gameId,q,context){
  const s=q.scene||{};
  const intro=[`Cenário — ${context.place}:`,`Missão — ${context.mission}:`,`Contexto — ${context.place}:`,`Desafio — ${context.mission}:`][context.frame%4];
  switch(gameId){
    case 'grupos': return `${intro} organize ${s.groups} grupos com ${s.perGroup} ${context.item} em cada. Qual é a quantidade total?`;
    case 'fator': { const visible=s.hidden==='a'?s.b:s.a; return `${intro} o produto é ${s.total} e um dos fatores é ${visible}. Qual fator está escondido?`; }
    case 'divisao': return `${intro} ${s.total} ${context.item} serão organizados em grupos de ${s.divisor}. Quantos grupos completos podem ser formados${s.remainder?' e quantos sobram':''}?`;
    case 'mercado': return `${intro} cada unidade custa R$ ${s.unit}. Se forem escolhidas ${s.quantity} unidades, qual será o total?`;
    case 'padroes': return `${intro} observe a sequência ${(s.values||[]).join(', ')}. Qual número vem depois?`;
    case 'combinacoes': return `${intro} há ${s.first} opções no primeiro grupo e ${s.second} no segundo. Quantas combinações diferentes podem ser formadas?`;
    case 'porcentagem': { const action=s.mode==='discount'?'o desconto pedido':s.mode==='increase'?'o acréscimo pedido':'a parte percentual pedida'; return `${intro} calcule ${s.percent}% de ${s.base} considerando ${action}.`; }
    case 'multiplos': { const target=s.criterion||s.base; return `${intro} encontre um número que seja ${s.mode==='criterion'?`divisível por ${target}`:`múltiplo de ${target}`}.`; }
    case 'divisores': return `${intro} escolha um número que divida ${s.value} exatamente, sem deixar resto.`;
    case 'primos': return `${intro} investigue os divisores de ${s.value}. Ele é primo ou composto?`;
    case 'potencias': return `${intro} calcule ${s.base} elevado a ${s.exponent}. Qual é o resultado?`;
    case 'expressoes': return `${intro} resolva ${s.expression} respeitando a ordem das operações.`;
    default: return q.prompt;
  }
}
function decorate(gameId,grade,q){
  const placeIndex=randomInt(0,PLACES.length-1);
  const itemIndex=randomInt(0,ITEMS.length-1);
  const missionIndex=randomInt(0,MISSIONS.length-1);
  const frame=randomInt(0,3);
  const context={place:PLACES[placeIndex],item:ITEMS[itemIndex],mission:MISSIONS[missionIndex],frame};
  const prompt=contextualPrompt(gameId,q,context);
  const signature=[gameId,grade,`p${placeIndex}`,`i${itemIndex}`,`m${missionIndex}`,`f${frame}`,sceneKey(q.scene)].join('|');
  return {...q,prompt,signature,context};
}

export function freshQuestion(factory,gameId,grade,options={}){
  const recent=new Set(Array.isArray(options.recent)?options.recent:[]);
  let candidate=null;
  for(let attempt=0;attempt<CONTENT_PLAN.antiRepeatAttempts;attempt+=1){
    candidate=decorate(gameId,grade,factory());
    if(!recent.has(candidate.signature)) return candidate;
  }
  return candidate||decorate(gameId,grade,factory());
}

function decoratePractice(grade,q){
  const placeIndex=randomInt(0,PLACES.length-1),itemIndex=randomInt(0,ITEMS.length-1),missionIndex=randomInt(0,MISSIONS.length-1),frame=randomInt(0,3);
  const place=PLACES[placeIndex],item=ITEMS[itemIndex],mission=MISSIONS[missionIndex];
  const intro=[`Cenário — ${place}:`,`Missão — ${mission}:`,`Contexto — ${place}:`,`Desafio — ${mission}:`][frame];
  let displayPrompt='';
  if(q.kind==='story') displayPrompt=`${intro} há ${q.a} ${q.a===1?'grupo':'grupos'} com ${q.b} ${q.b===1?'elemento':'elementos'} em cada. Qual é a quantidade total?`;
  else if(q.kind==='proportion') displayPrompt=`${intro} cada unidade vale ${q.b} pontos. Quantos pontos correspondem a ${q.a} ${q.a===1?'unidade':'unidades'}?`;
  else if(q.kind==='missing') displayPrompt=`${intro} descubra o fator que falta para completar a igualdade.`;
  else if(q.kind==='swap') displayPrompt=`${intro} use a comutatividade e complete a igualdade trocando a ordem dos fatores.`;
  else if(q.kind==='groups') displayPrompt=`${intro} observe ${q.a} ${q.a===1?'grupo':'grupos'} com ${q.b} ${q.b===1?'elemento':'elementos'} em cada e calcule o total.`;
  else if(q.kind==='repeated') displayPrompt=`${intro} transforme a soma de parcelas iguais em multiplicação e encontre o resultado.`;
  else displayPrompt=`${intro} resolva ${q.a} × ${q.b} usando a estratégia que fizer mais sentido.`;
  const signature=['practice',grade,q.kind,`${q.a}x${q.b}`,`p${placeIndex}`,`i${itemIndex}`,`m${missionIndex}`,`f${frame}`].join('|');
  return {...q,displayPrompt,signature,context:{place,item,mission,frame}};
}

export function freshPracticeQuestion(factory,grade,options={}){
  const recent=new Set(Array.isArray(options.recent)?options.recent:[]);
  let candidate=null;
  for(let attempt=0;attempt<CONTENT_PLAN.antiRepeatAttempts;attempt+=1){
    candidate=decoratePractice(grade,factory());
    if(!recent.has(candidate.signature)) return candidate;
  }
  return candidate||decoratePractice(grade,factory());
}
