import { GRADES, normalizeGrade } from './curriculum.js';
export const RELEASE = '6.7.2';
export const KEY = 'intelectus_tabuada_quality_v3';
export const LEGACY_KEYS = ['intelectus_tabuada_quality_v2', 'intelectus_tabuada_final_v1', 'intelectus_tabuada_v31'];
const KINDS = ['mc', 'input', 'missing', 'groups', 'repeated', 'swap', 'story', 'proportion'];
const AVATAR_IDS = ['aventureira', 'aventureiro', 'coruja', 'panda', 'leao', 'raposa', 'coelha', 'astronauta'];
const GUIDE_IDS = ['lia', 'aline', 'daniel', 'caio'];
const LEGACY_AVATAR_INDEX = ['raposa', 'astronauta', 'aventureiro', 'leao', 'panda', 'coelha', 'leao', 'coruja'];
const LEGACY_AVATARS = {
    '🦊': 'raposa', '🚀': 'astronauta', '🤖': 'aventureiro', '🦖': 'leao', '🐼': 'panda', '🦄': 'coelha', '🐯': 'leao', '🦉': 'coruja',
    fox: 'raposa', astro: 'astronauta', robot: 'aventureiro', dino: 'leao', panda: 'panda', unicorn: 'coelha', tiger: 'leao', owl: 'coruja',
    Raposa: 'raposa', Foguete: 'astronauta', Robô: 'aventureiro', Dinossauro: 'leao', Panda: 'panda', Unicórnio: 'coelha', Tigre: 'leao', Coruja: 'coruja',
};
const LEGACY_GUIDES = {
    lia: 'lia', aline: 'aline', daniel: 'daniel', caio: 'caio',
    'Profa. Lia': 'lia', 'Profª Lia': 'lia', 'Prof. Max': 'daniel', 'Prof. Theo': 'caio', 'Profa. Bia': 'aline',
    Professora: 'lia', Professor: 'daniel', 'Educador(a)': 'aline', 'Mestre Fox': 'caio',
};
function normalizeAvatarId(value) {
    if (typeof value === 'string') {
        if (AVATAR_IDS.includes(value))
            return value;
        if (LEGACY_AVATARS[value])
            return LEGACY_AVATARS[value];
    }
    if (typeof value === 'number' && Number.isInteger(value) && value >= 0 && value < LEGACY_AVATAR_INDEX.length)
        return LEGACY_AVATAR_INDEX[value];
    return 'raposa';
}
function normalizeGuideId(value) {
    if (typeof value === 'string') {
        if (GUIDE_IDS.includes(value))
            return value;
        if (LEGACY_GUIDES[value])
            return LEGACY_GUIDES[value];
    }
    return 'lia';
}
const isObject = (value) => Boolean(value) && typeof value === 'object' && !Array.isArray(value);
const numberValue = (value, max = 1000000) => typeof value === 'number' && Number.isFinite(value)
    ? Math.max(0, Math.min(max, Math.floor(value)))
    : 0;
const textValue = (value, max = 60) => typeof value === 'string' ? value.trim().slice(0, max) : '';
export function fresh() {
    return {
        name: '',
        grade: '3º Ano',
        avatar: 'raposa',
        guide: 'lia',
        diag: false,
        xp: 0,
        coins: 0,
        facts: {},
        hist: [],
        skills: {},
        games: {},
        bosses: {},
        placements: {},
        placement: null,
        migrated: false,
        volume: 0.7,
        muted: false,
        voice: 'natural:auto',
        quiet: false,
        musicOn: true,
        musicLevel: 35,
        voiceLevel: 80,
        offlineMissions: {},
    };
}
function normalizeEvidence(value) {
    if (!Array.isArray(value))
        return [];
    return value
        .filter((item) => isObject(item) &&
        typeof item.ok === 'boolean' &&
        typeof item.day === 'string' &&
        /^\d{4}-\d{2}-\d{2}$/.test(item.day) &&
        KINDS.includes(item.kind))
        .slice(-12)
        .map((item) => ({
        ok: item.ok,
        day: item.day,
        kind: item.kind,
    }));
}
function normalizeFacts(value) {
    const result = {};
    if (!isObject(value))
        return result;
    for (const [key, raw] of Object.entries(value).slice(0, 169)) {
        if (!/^(1[0-2]|[0-9])x(1[0-2]|[0-9])$/.test(key) || !isObject(raw))
            continue;
        const legacy = raw.n === undefined && raw.att !== undefined;
        const n = numberValue(legacy ? raw.att : raw.n);
        const c = Math.min(n, numberValue(legacy ? raw.ok : raw.c));
        const rec = Math.min(Math.max(0, n - c), numberValue(raw.rec));
        result[key] = {
            n,
            c,
            rec,
            last: numberValue(raw.last, 9e15),
            due: numberValue(raw.due, 9e15),
            streak: numberValue(raw.streak, 50),
            e: normalizeEvidence(raw.e),
        };
    }
    return result;
}
function normalizeHistory(value) {
    if (!Array.isArray(value))
        return [];
    return value
        .filter((item) => isObject(item) &&
        Number.isInteger(item.a) &&
        Number.isInteger(item.b) &&
        Number(item.a) >= 0 &&
        Number(item.a) <= 12 &&
        Number(item.b) >= 0 &&
        Number(item.b) <= 12)
        .slice(-1500)
        .map((item) => ({
        a: Number(item.a),
        b: Number(item.b),
        ok: item.ok === true,
        helped: item.helped === true || item.kind === 'recovery',
        kind: KINDS.includes(item.kind) ? item.kind : 'input',
        at: numberValue(item.at, 9e15),
    }));
}
const ERROR_CATEGORIES = ['fact', 'operation', 'inverse', 'division', 'pattern', 'proportion', 'percentage', 'divisibility', 'expression', 'power', 'combination', 'prime'];
function normalizeSkillErrors(value) {
    const result = {};
    if (!isObject(value))
        return result;
    for (const category of ERROR_CATEGORIES) {
        const count = numberValue(value[category], 50000);
        if (count)
            result[category] = count;
    }
    return result;
}
function normalizeSkills(value) {
    const result = {};
    if (!isObject(value))
        return result;
    for (const [key, raw] of Object.entries(value).slice(0, 80)) {
        if (!/^[a-z0-9-]{2,60}$/i.test(key) || !isObject(raw))
            continue;
        const played = numberValue(raw.played, 20000);
        const correct = Math.min(played, numberValue(raw.correct, 20000));
        result[key] = {
            played,
            correct,
            bestStreak: numberValue(raw.bestStreak, 1000),
            stars: Math.min(3, numberValue(raw.stars, 3)),
            last: numberValue(raw.last, 9e15),
            errors: normalizeSkillErrors(raw.errors),
        };
    }
    return result;
}
function normalizeGames(value) {
    const result = {};
    if (!isObject(value))
        return result;
    for (const [key, raw] of Object.entries(value).slice(0, 40)) {
        if (!/^[a-z0-9-]{2,40}$/i.test(key) || !isObject(raw))
            continue;
        const played = numberValue(raw.played, 50000);
        const correct = Math.min(played, numberValue(raw.correct, 50000));
        result[key] = {
            played,
            correct,
            completions: numberValue(raw.completions, 10000),
            bestScore: numberValue(raw.bestScore, 100),
            last: numberValue(raw.last, 9e15),
        };
    }
    return result;
}
function normalizeBosses(value) {
    const result = {};
    if (!isObject(value))
        return result;
    for (const [key, raw] of Object.entries(value).slice(0, 8)) {
        if (!isObject(raw))
            continue;
        result[key] = {
            attempts: numberValue(raw.attempts, 1000),
            bestScore: numberValue(raw.bestScore, 100),
            completed: raw.completed === true,
            completedAt: numberValue(raw.completedAt, 9e15),
        };
    }
    return result;
}
function normalizePlacement(value) {
    if (!isObject(value) || typeof value.grade !== 'string' || typeof value.skillId !== 'string' || !isObject(value.scores))
        return null;
    const grade = normalizeGrade(value.grade);
    const scores = {};
    for (const [skillId, raw] of Object.entries(value.scores).slice(0, 20)) {
        if (!/^[a-z0-9-]{2,60}$/i.test(skillId) || !isObject(raw))
            continue;
        const total = numberValue(raw.total, 20);
        scores[skillId] = { correct: Math.min(total, numberValue(raw.correct, 20)), total };
    }
    return {
        grade,
        skillId: textValue(value.skillId, 60),
        scores,
        at: numberValue(value.at, 9e15),
    };
}
function normalizePlacements(value) {
    const result = {};
    if (!isObject(value))
        return result;
    for (const [key, raw] of Object.entries(value).slice(0, 8)) {
        const placement = normalizePlacement(raw);
        if (placement)
            result[key] = placement;
    }
    return result;
}
function normalizeOfflineMissions(value) {
    const result = {};
    if (!isObject(value))
        return result;
    for (const [key, raw] of Object.entries(value).slice(0, 40)) {
        if (!/^[a-z0-9-]{2,80}$/i.test(key))
            continue;
        if (raw === 'independent' || raw === 'helped' || raw === 'learning')
            result[key] = raw;
    }
    return result;
}
export function normalize(raw) {
    const state = fresh();
    if (!isObject(raw))
        return state;
    state.name = textValue(raw.name, 30);
    const originalGrade = raw.grade;
    state.grade = normalizeGrade(raw.grade);
    state.migrated = raw.migrated === true || originalGrade === '2º Ano' || originalGrade === '6º Ano ou mais';
    state.avatar = normalizeAvatarId(raw.avatar);
    state.guide = normalizeGuideId(raw.guide ?? raw.teacher);
    state.diag = raw.diag === true;
    state.xp = numberValue(raw.xp);
    state.coins = numberValue(raw.coins);
    state.volume =
        typeof raw.volume === 'number' && Number.isFinite(raw.volume)
            ? Math.max(0, Math.min(1, raw.volume))
            : 0.7;
    state.muted = raw.muted === true;
    state.voice = textValue(raw.voice, 180) || 'natural:auto';
    state.quiet = raw.quiet === true;
    state.musicOn = raw.musicOn !== undefined ? raw.musicOn === true : raw.muted !== true;
    state.musicLevel = typeof raw.musicLevel === 'number' && Number.isFinite(raw.musicLevel) ? Math.max(0, Math.min(100, Math.round(raw.musicLevel))) : 35;
    state.voiceLevel = typeof raw.voiceLevel === 'number' && Number.isFinite(raw.voiceLevel) ? Math.max(0, Math.min(100, Math.round(raw.voiceLevel))) : Math.round(state.volume * 100);
    state.facts = normalizeFacts(raw.facts);
    state.hist = normalizeHistory(raw.hist ?? raw.history);
    state.skills = normalizeSkills(raw.skills);
    state.games = normalizeGames(raw.games);
    state.bosses = normalizeBosses(raw.bosses);
    state.placements = normalizePlacements(raw.placements);
    state.placement = normalizePlacement(raw.placement);
    state.offlineMissions = normalizeOfflineMissions(raw.offlineMissions);
    if (state.placement)
        state.placements[state.placement.grade] = state.placement;
    return state;
}
export const blankFact = () => ({
    n: 0,
    c: 0,
    rec: 0,
    last: 0,
    due: 0,
    streak: 0,
    e: [],
});
export const blankSkill = () => ({
    played: 0,
    correct: 0,
    bestStreak: 0,
    stars: 0,
    last: 0,
    errors: {},
});
export const getFact = (state, a, b) => state.facts[`${a}x${b}`] || blankFact();
export const getSkillProgress = (state, skillId) => state.skills[skillId] || blankSkill();
export function pool(state, only) {
    const gradeTables = GRADES[state.grade];
    const tables = only !== undefined && gradeTables.includes(only) ? [only] : gradeTables;
    return tables.flatMap((a) => Array.from({ length: 11 }, (_, b) => ({ a, b })));
}
export function shuffle(values, rng = Math.random) {
    const result = values.slice();
    for (let index = result.length - 1; index > 0; index -= 1) {
        const swap = Math.min(index, Math.floor(rng() * (index + 1)));
        [result[index], result[swap]] = [result[swap], result[index]];
    }
    return result;
}
export function choices(expected, a, b, rng = Math.random) {
    const candidates = [expected + a, expected + b, expected - a, expected - 1, expected + 1, expected + 2, 0, 1, 2, 3, 4];
    const other = Array.from(new Set(candidates)).filter((value) => value >= 0 && value <= 200 && value !== expected);
    return shuffle([expected, ...shuffle(other, rng).slice(0, 3)], rng);
}
export function priority(fact, at = Date.now()) {
    return (1 +
        (fact.n === 0 ? 5 : 0) +
        (fact.e.length && !fact.e[fact.e.length - 1].ok ? 9 : 0) +
        (fact.due > 0 && fact.due <= at ? 5 : 0) +
        (fact.n ? 3 * (1 - fact.c / fact.n) : 0));
}
export function question(state, round, diag = false, only, used = [], rng = Math.random) {
    let list = pool(state, only);
    if (diag) {
        const tables = GRADES[state.grade];
        list = list.filter((pair) => pair.a === tables[round % tables.length]);
    }
    const unused = list.filter((pair) => !used.includes(`${pair.a}x${pair.b}`));
    if (unused.length)
        list = unused;
    const weights = list.map((pair) => (diag ? 1 : priority(getFact(state, pair.a, pair.b))));
    let roll = rng() * weights.reduce((total, value) => total + value, 0);
    let index = 0;
    while (index < weights.length - 1 && roll >= weights[index]) {
        roll -= weights[index];
        index += 1;
    }
    const { a, b } = list[index];
    const diagKinds = ['mc', 'input', 'story'];
    let kind = (diag ? diagKinds : KINDS)[round % (diag ? diagKinds.length : KINDS.length)];
    if ((kind === 'missing' && a === 0) || (kind === 'swap' && (a === 0 || b === 0)))
        kind = 'input';
    if (kind === 'proportion' && state.grade === '3º Ano')
        kind = 'story';
    const expected = kind === 'missing' ? b : kind === 'swap' ? a : a * b;
    return {
        a,
        b,
        kind,
        expected,
        options: choices(expected, a, b, rng),
        id: `${a}x${b}`,
    };
}
export function strategy(a, b) {
    if (a === 0 || b === 0)
        return 'Um dos fatores é zero: não há elementos no total.';
    if (a === 1)
        return `Um grupo com ${b} elementos mantém a quantidade.`;
    const strategies = {
        2: `Calcule o dobro de ${b}: ${b} + ${b}.`,
        3: `Some o dobro de ${b} com mais ${b}.`,
        4: `Calcule o dobro do dobro de ${b}.`,
        5: `Calcule 10 × ${b} e encontre a metade.`,
        6: `Separe em 5 × ${b} + 1 × ${b}.`,
        7: `Separe em 5 × ${b} + 2 × ${b}.`,
        8: `Calcule o dobro de 4 × ${b}.`,
        9: `Calcule 10 × ${b} e tire ${b}.`,
        10: `São dez grupos de ${b}. Observe as dezenas.`,
    };
    return strategies[a] || `Some ${a} parcelas de ${b}.`;
}
export const sum = (a, b) => a === 0 ? '0' : Array.from({ length: a }, () => String(b)).join(' + ');
export function equation(q) {
    if (q.kind === 'missing')
        return `${q.a} × ? = ${q.a * q.b}`;
    if (q.kind === 'swap')
        return `${q.a} × ${q.b} = ${q.b} × ?`;
    return `${q.a} × ${q.b} = ?`;
}
export function prompt(q) {
    if (q.kind === 'story') {
        return `São ${q.a} caixas com ${q.b} figurinhas em cada. Quantas figurinhas há ao todo?`;
    }
    if (q.kind === 'proportion') {
        return `Cada ingresso custa ${q.b} reais. Qual é o valor de ${q.a} ingressos?`;
    }
    if (q.kind === 'missing')
        return 'Qual é o fator que falta?';
    if (q.kind === 'swap')
        return 'Troque a ordem dos fatores. Qual número completa a igualdade?';
    if (q.kind === 'groups')
        return `Conte ${q.a} grupos com ${q.b} elementos em cada.`;
    if (q.kind === 'repeated')
        return 'Use a soma de parcelas iguais.';
    return 'Quanto é?';
}
function day(at) {
    const date = new Date(at);
    return `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, '0')}-${String(date.getDate()).padStart(2, '0')}`;
}
export function record(state, q, ok, helped, at = Date.now()) {
    const fact = getFact(state, q.a, q.b);
    fact.n += 1;
    if (ok && !helped)
        fact.c += 1;
    fact.last = at;
    if (q.kind !== 'swap') {
        const independent = ok && !helped;
        fact.e.push({ ok: independent, day: day(at), kind: q.kind });
        fact.e = fact.e.slice(-12);
        fact.streak = independent ? fact.streak + 1 : 0;
        fact.due = at + (independent ? [1, 3, 7, 14][Math.min(fact.streak - 1, 3)] * 86400000 : 600000);
    }
    state.facts[q.id] = fact;
    state.hist.push({ a: q.a, b: q.b, ok, helped, kind: q.kind, at });
    state.hist = state.hist.slice(-1500);
    if (ok && !helped) {
        state.xp += 12;
        state.coins += 2;
    }
    else if (ok) {
        fact.rec += 1;
        state.xp += 4;
    }
}
export function recover(state, q) {
    const fact = getFact(state, q.a, q.b);
    fact.rec += 1;
    state.facts[q.id] = fact;
    state.xp += 4;
}
export function recordSkill(state, skillId, correct, streak, at = Date.now(), errorCategory) {
    const progress = getSkillProgress(state, skillId);
    progress.played += 1;
    if (correct) {
        progress.correct += 1;
        state.xp += 10;
        state.coins += 1;
    }
    else {
        state.xp += 2;
        if (errorCategory)
            progress.errors[errorCategory] = (progress.errors[errorCategory] || 0) + 1;
    }
    progress.bestStreak = Math.max(progress.bestStreak, streak);
    progress.last = at;
    const accuracy = progress.played ? progress.correct / progress.played : 0;
    progress.stars =
        progress.played >= 15 && accuracy >= 0.85
            ? 3
            : progress.played >= 8 && accuracy >= 0.75
                ? 2
                : progress.played >= 3 && accuracy >= 0.6
                    ? 1
                    : 0;
    state.skills[skillId] = progress;
}
export function dominantSkillError(progress) {
    let best = null;
    let bestCount = 0;
    for (const category of ERROR_CATEGORIES) {
        const count = progress.errors[category] || 0;
        if (count > bestCount) {
            best = category;
            bestCount = count;
        }
    }
    return best;
}
export function recordGameSession(state, gameId, correct, total, at = Date.now()) {
    const current = state.games[gameId] || { played: 0, correct: 0, completions: 0, bestScore: 0, last: 0 };
    current.played += Math.max(0, total);
    current.correct += Math.max(0, Math.min(total, correct));
    current.completions += 1;
    current.bestScore = Math.max(current.bestScore, total ? Math.round((correct / total) * 100) : 0);
    current.last = at;
    state.games[gameId] = current;
}
export function recordBossAttempt(state, grade, correct, total, at = Date.now()) {
    const key = grade;
    const current = state.bosses[key] || { attempts: 0, bestScore: 0, completed: false, completedAt: 0 };
    const score = total ? Math.round((correct / total) * 100) : 0;
    const firstCompletion = !current.completed && score >= 75;
    current.attempts += 1;
    current.bestScore = Math.max(current.bestScore, score);
    if (score >= 75) {
        current.completed = true;
        if (!current.completedAt)
            current.completedAt = at;
    }
    state.bosses[key] = current;
    if (firstCompletion) {
        state.xp += 25;
        state.coins += 5;
    }
    return firstCompletion;
}
export function consolidated(fact) {
    const evidence = fact.e.slice(-6);
    const good = evidence.filter((value) => value.ok);
    return (evidence.length >= 3 &&
        good.length / evidence.length >= 0.8 &&
        new Set(good.map((value) => value.day)).size >= 2 &&
        new Set(good.map((value) => value.kind)).size >= 2);
}
export function metrics(state) {
    const facts = pool(state).map((pair) => getFact(state, pair.a, pair.b));
    const n = facts.reduce((total, fact) => total + fact.n, 0);
    const c = facts.reduce((total, fact) => total + fact.c, 0);
    const known = facts.filter(consolidated).length;
    const skills = Object.values(state.skills);
    const games = Object.values(state.games);
    const bosses = Object.values(state.bosses);
    const skillPlayed = skills.reduce((total, skill) => total + skill.played, 0);
    const skillCorrect = skills.reduce((total, skill) => total + skill.correct, 0);
    return {
        n,
        c,
        accuracy: n ? Math.round((c / n) * 100) : 0,
        covered: facts.filter((fact) => fact.n > 0).length,
        total: facts.length,
        known,
        mastery: facts.length ? Math.round((known / facts.length) * 100) : 0,
        recovery: facts.reduce((total, fact) => total + fact.rec, 0),
        skillPlayed,
        skillCorrect,
        skillAccuracy: skillPlayed ? Math.round((skillCorrect / skillPlayed) * 100) : 0,
        skillStars: skills.reduce((total, skill) => total + skill.stars, 0),
        gameCompletions: games.reduce((total, game) => total + game.completions, 0),
        bossesCompleted: bosses.filter((boss) => boss.completed).length,
    };
}
export const escape = (value) => String(value).replace(/[&<>"']/g, (character) => {
    const replacements = {
        '&': '&amp;',
        '<': '&lt;',
        '>': '&gt;',
        '"': '&quot;',
        "'": '&#39;',
    };
    return replacements[character] || character;
});
function validInteger(value, max = 1000000) {
    return typeof value === 'number' && Number.isSafeInteger(value) && value >= 0 && value <= max;
}
export function validateBackup(raw) {
    if (!isObject(raw) || raw.app !== 'intelectus-tabuada' || ![2, 3, 4, 5, 6, 7].includes(Number(raw.version)) || !isObject(raw.state)) {
        return null;
    }
    const state = raw.state;
    if (typeof state.name !== 'string' || !state.name.trim() || state.name.length > 30)
        return null;
    if (typeof state.grade !== 'string')
        return null;
    if (typeof state.diag !== 'boolean' || typeof state.migrated !== 'boolean')
        return null;
    if (typeof state.muted !== 'boolean' || typeof state.quiet !== 'boolean')
        return null;
    if (Number(raw.version) >= 7) {
        if (typeof state.musicOn !== 'boolean')
            return null;
        if (!validInteger(state.musicLevel, 100) || !validInteger(state.voiceLevel, 100))
            return null;
        if (typeof state.avatar !== 'string' || !AVATAR_IDS.includes(state.avatar))
            return null;
        if (typeof state.guide !== 'string' || !GUIDE_IDS.includes(state.guide))
            return null;
    }
    if (!validInteger(state.xp) || !validInteger(state.coins))
        return null;
    if (typeof state.volume !== 'number' ||
        !Number.isFinite(state.volume) ||
        state.volume < 0 ||
        state.volume > 1 ||
        typeof state.voice !== 'string' ||
        state.voice.length > 180) {
        return null;
    }
    if (!isObject(state.facts) || Object.keys(state.facts).length > 169)
        return null;
    if (!Array.isArray(state.hist) || state.hist.length > 1500)
        return null;
    if (state.skills !== undefined && (!isObject(state.skills) || Object.keys(state.skills).length > 80))
        return null;
    if (state.games !== undefined && (!isObject(state.games) || Object.keys(state.games).length > 40))
        return null;
    if (state.bosses !== undefined && (!isObject(state.bosses) || Object.keys(state.bosses).length > 8))
        return null;
    if (state.placements !== undefined && (!isObject(state.placements) || Object.keys(state.placements).length > 8))
        return null;
    if (state.placement !== undefined && state.placement !== null && !isObject(state.placement))
        return null;
    if (state.offlineMissions !== undefined && (!isObject(state.offlineMissions) || Object.keys(state.offlineMissions).length > 40))
        return null;
    const normalized = normalize(state);
    if (Number(raw.version) >= 7 && (state.avatar !== normalized.avatar || state.guide !== normalized.guide))
        return null;
    return normalized;
}
