/* Intelectus Matemática V18.5 — jornada longitudinal de 12 meses */
(()=>{
  const EXTRA_SKILLS={
    numbers:[
      {id:'vizinhos-numero',label:'Antes e depois',tip:'Na sequência numérica, o antecessor vem imediatamente antes e o sucessor imediatamente depois.',minGrade:0},
      {id:'reta-numerica',label:'Reta numérica',tip:'Observe a ordem e a distância entre os números para descobrir o ponto que falta.',minGrade:1},
      {id:'dezenas-unidades',label:'Dezenas e unidades',tip:'Uma dezena vale dez unidades. Separe o número em dezenas completas e unidades restantes.',minGrade:1}
    ],
    quantities:[
      {id:'agrupar-dezenas',label:'Agrupar de dez em dez',tip:'Forme grupos de dez e depois conte as unidades que sobraram.',minGrade:1}
    ],
    sequence:[
      {id:'contagem-saltos',label:'Contagem em saltos',tip:'Descubra de quanto em quanto a sequência avança e repita o mesmo salto.',minGrade:1},
      {id:'termo-ausente',label:'Número que falta',tip:'Observe os números dos dois lados para descobrir qual valor completa a sequência.',minGrade:0}
    ],
    operations:[
      {id:'problema-adicao',label:'Problemas de adição',tip:'Descubra o que já havia e o que chegou depois. Junte as quantidades.',minGrade:1},
      {id:'problema-subtracao',label:'Problemas de subtração',tip:'Descubra quanto havia e quanto saiu. Conte o que permaneceu.',minGrade:1},
      {id:'termo-desconhecido',label:'Parcela desconhecida',tip:'Pense no número que falta para completar o total.',minGrade:2}
    ],
    patterns:[
      {id:'padrao-crescente',label:'Padrões crescentes',tip:'Observe como cada etapa aumenta e continue usando a mesma regra.',minGrade:1}
    ],
    geometry:[
      {id:'solidos-geometricos',label:'Sólidos e objetos',tip:'Compare objetos do cotidiano com cubo, esfera e cilindro.',minGrade:0},
      {id:'classificar-formas',label:'Características das formas',tip:'Observe lados, cantos e contornos para comparar as figuras.',minGrade:1}
    ],
    measures:[
      {id:'horas',label:'Horas inteiras',tip:'No relógio, uma hora depois significa avançar uma unidade no horário.',minGrade:1},
      {id:'calendario',label:'Calendário e sequência de dias',tip:'Os dias avançam de um em um. Use ontem, hoje e amanhã como referência.',minGrade:1},
      {id:'dinheiro',label:'Sistema monetário',tip:'Some os valores das moedas ou cédulas para descobrir o total.',minGrade:1}
    ]
  };
  Object.entries(EXTRA_SKILLS).forEach(([world,items])=>SKILLS[world].push(...items));
  Object.assign(examples,{
    'vizinhos-numero':{html:'<div class="workedVisual"><span>6 → <b>7</b> → 8</span></div><p>Sete fica entre seis e oito.</p>',speech:'Na sequência, seis vem antes de sete e oito vem depois.'},
    'reta-numerica':{html:'<div class="workedVisual"><span>10 → 11 → <b>12</b> → 13</span></div><p>A ordem da reta mostra o número que falta.</p>',speech:'Observe a sequência na reta numérica e avance uma posição por vez.'},
    'dezenas-unidades':{html:'<div class="workedVisual"><span>🔟 🔟</span><b>+</b><span>● ● ●</span><b>= 23</b></div><p>Duas dezenas e três unidades formam vinte e três.</p>',speech:'Duas dezenas valem vinte. Com mais três unidades, formamos vinte e três.'},
    'agrupar-dezenas':{html:'<div class="workedVisual"><span>10 + 10 + 4</span><b>= 24</b></div><p>Agrupe dez em dez e conte o que sobra.</p>',speech:'Dois grupos de dez e quatro unidades formam vinte e quatro.'},
    'contagem-saltos':{html:'<div class="workedVisual"><span>0 → 2 → 4 → 6 → 8</span></div><p>O salto é de dois em dois.</p>',speech:'A sequência aumenta dois a cada passo.'},
    'termo-ausente':{html:'<div class="workedVisual"><span>7 → 8 → <b>9</b> → 10</span></div><p>Use os vizinhos para encontrar o número ausente.</p>',speech:'Entre oito e dez aparece o número nove.'},
    'problema-adicao':{html:'<div class="workedVisual"><span>🍎🍎🍎 + 🍎🍎</span><b>= 5</b></div><p>Junte o que havia com o que chegou.</p>',speech:'Três maçãs com mais duas formam cinco.'},
    'problema-subtracao':{html:'<div class="workedVisual"><span>⭐⭐⭐⭐⭐ − ⭐⭐</span><b>= 3</b></div><p>Retire o que saiu e conte o restante.</p>',speech:'De cinco estrelas, duas saíram. Restaram três.'},
    'termo-desconhecido':{html:'<div class="workedVisual"><span>? + 3 = 8</span><b>5</b></div><p>Cinco completa o total oito.</p>',speech:'Pense em quanto falta para três chegar a oito.'},
    'padrao-crescente':{html:'<div class="workedVisual"><span>● | ●● | ●●● | ●●●●</span></div><p>Cada etapa recebe mais um elemento.</p>',speech:'O padrão cresce acrescentando um elemento em cada etapa.'},
    'solidos-geometricos':{html:'<div class="workedVisual"><span>⚽ → esfera</span><span>🎲 → cubo</span></div><p>Objetos do cotidiano lembram sólidos geométricos.</p>',speech:'Uma bola lembra uma esfera. Um dado lembra um cubo.'},
    'classificar-formas':{html:'<div class="workedVisual"><span>● sem lados retos</span><span>▲ três lados</span></div><p>Compare as características.</p>',speech:'O círculo não tem lados retos. O triângulo tem três lados.'},
    'horas':{html:'<div class="workedVisual"><span>8:00 → <b>9:00</b></span></div><p>Uma hora depois de oito horas são nove horas.</p>',speech:'Avance uma hora no relógio.'},
    'calendario':{html:'<div class="workedVisual"><span>Dia 14 → <b>15</b> → 16</span></div><p>Os dias avançam de um em um.</p>',speech:'Depois do dia quatorze vem o dia quinze.'},
    'dinheiro':{html:'<div class="workedVisual"><span>R$ 2 + R$ 1</span><b>= R$ 3</b></div><p>Some os valores para descobrir o total.</p>',speech:'Dois reais mais um real são três reais.'}
  });
  const gradeIndex=()=>s?.grade==='Pré-escola'?0:s?.grade==='1º Ano'?1:2;
  const gradeMax=level=>[[5,10,10],[10,20,50],[20,50,100]][gradeIndex()][Math.min(2,Math.max(0,level))];
  const activeSkills=world=>SKILLS[world].filter(skill=>(skill.minGrade??0)<=gradeIndex());
  const pick=(arr,random=Math.random)=>arr[Math.floor(random()*arr.length)];
  const distract=(answer,min,max,random=Math.random)=>{
    const set=new Set([answer]);
    while(set.size<3){set.add(Math.max(min,Math.min(max,answer+(Math.floor(random()*7)-3))))}
    return [...set].map(String);
  };
  const baseMakeTask=makeTask;
  makeTask=function(id,i,level,random=Math.random){
    const band=Math.min(2,Math.max(0,level)), max=gradeMax(band), skillPool=activeSkills(id), skill=skillPool[(i+Math.floor(random()*skillPool.length))%skillPool.length]?.id;
    const rand=(min,maxi)=>min+Math.floor(random()*(maxi-min+1));
    const item=(prompt,stimulus,options,answer,hint,explain,skillId)=>({world:id,prompt,stimulus,options:shuffle(options),answer,hint,explain,skill:skillId,level:band});
    if(skill==='vizinhos-numero'){
      const n=rand(1,Math.max(2,max-1)),after=random()>.5,ans=after?n+1:n-1;
      return item(after?`Qual número vem logo depois de ${n}?`:`Qual número vem logo antes de ${n}?`,`${n-1} · ${n} · ${n+1}`,distract(ans,0,max,random),String(ans),EXTRA_SKILLS.numbers[0].tip,`${ans} ${after?'vem depois':'vem antes'} de ${n}.`,skill);
    }
    if(skill==='reta-numerica'){
      const start=rand(0,Math.max(0,max-4)),gap=rand(1,2),seq=[start,start+1,start+2,start+3],ans=seq[gap];
      const shown=seq.map((v,j)=>j===gap?'?':v).join(' → ');
      return item('Qual número completa a reta numérica?',shown,distract(ans,0,max,random),String(ans),EXTRA_SKILLS.numbers[1].tip,`O número que falta é ${ans}.`,skill);
    }
    if(skill==='dezenas-unidades'){
      const ceiling=Math.max(19,max),n=rand(10,ceiling),d=Math.floor(n/10),u=n%10;
      return item(`${d} ${d===1?'dezena':'dezenas'} e ${u} ${u===1?'unidade':'unidades'} formam qual número?`,`${d}×10 + ${u}`,distract(n,0,ceiling,random),String(n),EXTRA_SKILLS.numbers[2].tip,`${d} dezena(s) e ${u} unidade(s) formam ${n}.`,skill);
    }
    if(skill==='agrupar-dezenas'){
      const ceiling=Math.max(19,max),n=rand(10,ceiling),d=Math.floor(n/10),u=n%10;
      return item('Qual número representa estes grupos de dezenas e unidades?',`${'🔟 '.repeat(d)}${'● '.repeat(u)}`.trim(),distract(n,0,ceiling,random),String(n),EXTRA_SKILLS.quantities[0].tip,`Há ${d} grupo(s) de dez e ${u} unidade(s): ${n}.`,skill);
    }
    if(skill==='contagem-saltos'){
      const steps=gradeIndex()===1?[2,5]:[2,5,10],step=pick(steps,random),start=step===10?0:rand(0,Math.max(0,max-step*4)),seq=[start,start+step,start+2*step,start+3*step],ans=start+4*step;
      return item(`Continue a contagem de ${step} em ${step}.`,`${seq.join(' → ')} → ?`,distract(ans,0,Math.max(max,ans+step),random),String(ans),EXTRA_SKILLS.sequence[0].tip,`Somando ${step} novamente, chegamos a ${ans}.`,skill);
    }
    if(skill==='termo-ausente'){
      const start=rand(0,Math.max(0,max-4)),gap=rand(1,2),seq=[start,start+1,start+2,start+3],ans=seq[gap];
      return item('Qual número está faltando?',seq.map((v,j)=>j===gap?'?':v).join(' → '),distract(ans,0,max,random),String(ans),EXTRA_SKILLS.sequence[1].tip,`Entre os vizinhos aparece ${ans}.`,skill);
    }
    if(skill==='problema-adicao'){
      const a=rand(1,Math.max(2,Math.floor(max/2))),b=rand(1,Math.max(1,Math.min(max-a,Math.floor(max/2)))),ans=a+b;
      return item(`Havia ${a} carrinhos. Chegaram mais ${b}. Quantos carrinhos há agora?`,`${a} + ${b}`,distract(ans,0,max,random),String(ans),EXTRA_SKILLS.operations[0].tip,`${a} mais ${b} é ${ans}.`,skill);
    }
    if(skill==='problema-subtracao'){
      const a=rand(2,max),b=rand(1,a),ans=a-b;
      return item(`Havia ${a} figurinhas. ${b} foram usadas. Quantas restaram?`,`${a} − ${b}`,distract(ans,0,max,random),String(ans),EXTRA_SKILLS.operations[1].tip,`${a} menos ${b} é ${ans}.`,skill);
    }
    if(skill==='termo-desconhecido'){
      const total=rand(4,max),known=rand(1,total-1),ans=total-known;
      return item(`Qual número completa: ? + ${known} = ${total}?`,`? + ${known} = ${total}`,distract(ans,0,max,random),String(ans),EXTRA_SKILLS.operations[2].tip,`${ans} mais ${known} é ${total}.`,skill);
    }
    if(skill==='padrao-crescente'){
      const start=rand(1,4),inc=gradeIndex()===0?1:rand(1,2),ans=start+3*inc;
      return item(`O padrão cresce de ${inc} em ${inc}. Quantos elementos vêm depois?`,`${'●'.repeat(start)} | ${'●'.repeat(start+inc)} | ${'●'.repeat(start+2*inc)} | ?`,distract(ans,1,14,random).map(v=>`${v} elementos`),`${ans} elementos`,EXTRA_SKILLS.patterns[0].tip,`O padrão acrescenta ${inc}; a próxima etapa tem ${ans}.`,skill);
    }
    if(skill==='solidos-geometricos'){
      const cases=[['bola','esfera'],['laranja','esfera'],['globo','esfera'],['dado','cubo'],['caixa cúbica','cubo'],['cubo mágico','cubo'],['lata','cilindro'],['rolo','cilindro'],['tubo','cilindro']],chosen=pick(cases,random);
      return item(`Qual sólido lembra uma ${chosen[0]}?`,chosen[0],['esfera','cubo','cilindro'],chosen[1],EXTRA_SKILLS.geometry[0].tip,`Uma ${chosen[0]} lembra uma ${chosen[1]}.`,skill);
    }
    if(skill==='classificar-formas'){
      const cases=[['Qual figura não tem lados retos?','círculo'],['Qual figura tem três lados?','triângulo'],['Qual figura tem quatro lados iguais?','quadrado'],['Qual figura é redonda?','círculo'],['Qual figura tem mais lados entre círculo e triângulo?','triângulo'],['Qual figura tem quatro lados e quatro cantos?','quadrado']],chosen=pick(cases,random);
      return item(chosen[0],'Observe as características.',['círculo','triângulo','quadrado'],chosen[1],EXTRA_SKILLS.geometry[1].tip,`A resposta é ${chosen[1]}.`,skill);
    }
    if(skill==='horas'){
      const h=rand(6,18),ans=h+1;
      return item(`Uma hora depois de ${h}:00 será que horário?`,`${h}:00 → ?`,[`${ans}:00`,`${h}:30`,`${Math.max(0,h-1)}:00`],`${ans}:00`,EXTRA_SKILLS.measures[0].tip,`Uma hora depois de ${h}:00 é ${ans}:00.`,skill);
    }
    if(skill==='calendario'){
      const d=rand(2,27),after=random()>.5,ans=after?d+1:d-1;
      return item(after?`Hoje é dia ${d}. Qual será o dia de amanhã?`:`Hoje é dia ${d}. Qual foi o dia de ontem?`,`Dia ${d}`,distract(ans,1,31,random),String(ans),EXTRA_SKILLS.measures[1].tip,`${after?'Amanhã':'Ontem'} é dia ${ans}.`,skill);
    }
    if(skill==='dinheiro'){
      const a=rand(1,5),b=rand(1,5),ans=a+b;
      return item(`R$ ${a} + R$ ${b} formam quanto?`,`R$ ${a} + R$ ${b}`,distract(ans,1,12,random).map(v=>`R$ ${v}`),`R$ ${ans}`,EXTRA_SKILLS.measures[2].tip,`R$ ${a} mais R$ ${b} são R$ ${ans}.`,skill);
    }
    return baseMakeTask(id,i,band,random);
  };
  const baseNextLevel=nextLevel;
  nextLevel=function(current,history,requiredSkills=[]){
    const recent=history.slice(-12); if(recent.length<10)return current;
    const eligible=requiredSkills.filter(id=>{const skill=Object.values(SKILLS).flat().find(x=>x.id===id);return (skill?.minGrade??0)<=gradeIndex()});
    const independent=recent.filter(o=>o.independent);
    const covered=new Set(independent.map(o=>o.skill));
    const coverageTarget=Math.min(4,Math.max(2,Math.ceil(eligible.length*.55)));
    if(independent.length>=9&&covered.size>=coverageTarget)return Math.min(2,current+1);
    if(recent.slice(-5).filter(o=>o.independent).length<=1)return Math.max(0,current-1);
    return current;
  };
  const PHASES=[
    {name:'Descobrir quantidades',focus:['numbers','quantities']},
    {name:'Contar e comparar',focus:['numbers','sequence']},
    {name:'Juntar e retirar',focus:['operations','quantities']},
    {name:'Padrões e formas',focus:['patterns','geometry']},
    {name:'Medir e organizar',focus:['measures','sequence']},
    {name:'Dezenas e estratégias',focus:['numbers','operations']},
    {name:'Problemas e dados',focus:['operations','measures']},
    {name:'Consolidar habilidades',focus:['numbers','quantities','sequence','operations','patterns','geometry','measures']},
    {name:'Revisão adaptativa I',focus:['numbers','operations','measures']},
    {name:'Revisão adaptativa II',focus:['quantities','sequence','geometry']},
    {name:'Desafios mistos',focus:['patterns','operations','measures','numbers']},
    {name:'Consolidação anual',focus:['numbers','quantities','sequence','operations','patterns','geometry','measures']}
  ];
  function annualMonth(){const start=new Date(s?.programStart||s?.trial||Date.now()).getTime();return Math.min(12,Math.max(1,Math.floor((Date.now()-start)/(30.4375*86400000))+1))}
  function annualPhase(){return PHASES[annualMonth()-1]}
  const oldRecommended=recommended;
  recommended=function(){const focus=annualPhase().focus;return [...WORLDS].sort((a,b)=>(priority(a[0])-(focus.includes(a[0])?14:0))-(priority(b[0])-(focus.includes(b[0])?14:0)))[0][0]||oldRecommended()};
  function programCard(){const month=annualMonth(),phase=annualPhase();return `<section id="annualJourney" class="annualJourney"><div><span>JORNADA ANUAL · MÊS ${month} DE 12</span><h2>${phase.name}</h2><p>${month<=8?'Progressão estruturada do núcleo pedagógico.':'Consolidação adaptativa, retomadas e desafios mistos.'}</p></div><strong>${month<=8?'8+ meses de progressão':'12 meses de acesso'}</strong></section>`}
  function mountProgram(){const shell=document.querySelector('.appShell');if(!shell||shell.classList.contains('route-splash')||shell.classList.contains('route-onboard')||document.querySelector('#annualJourney'))return;const target=shell.querySelector('.v14Home .v14Hero,.contentWide .v14SectionHead');if(target)target.insertAdjacentHTML('afterend',programCard())}
  const obs=new MutationObserver(()=>queueMicrotask(mountProgram));obs.observe(document.querySelector('#app')||document.body,{childList:true,subtree:true});queueMicrotask(mountProgram);
  window.IntelectusAnnualJourney={month:annualMonth,phase:annualPhase,phases:PHASES,activeSkills};
})();
