function createSounds(settings) {
    let context;
    const active = new Set();
    let generation = 0;
    function stop() { generation++; for (const node of active) {
        try {
            node.stop();
        }
        catch { }
    } active.clear(); }
    async function play(kind = 'tap') { const token = generation, state = settings(); if (state.muted || state.volume <= 0)
        return false; const Constructor = window.AudioContext || window.webkitAudioContext; if (!Constructor)
        return false; try {
        context ??= new Constructor();
        if (context.state === 'suspended')
            await context.resume();
        if (token !== generation || context.state !== 'running')
            return false;
        const notes = kind === 'success' ? [523.25, 659.25, 783.99] : kind === 'hint' ? [392, 440] : [523.25], start = context.currentTime;
        for (let i = 0; i < notes.length; i++) {
            const node = context.createOscillator(), gain = context.createGain(), time = start + i * .09;
            node.type = 'sine';
            node.frequency.value = notes[i];
            gain.gain.setValueAtTime(0, time);
            gain.gain.linearRampToValueAtTime(Math.min(1, settings().volume) * .08, time + .012);
            gain.gain.exponentialRampToValueAtTime(.0001, time + .085);
            node.connect(gain);
            gain.connect(context.destination);
            active.add(node);
            node.onended = () => { active.delete(node); node.disconnect(); gain.disconnect(); };
            node.start(time);
            node.stop(time + .09);
        }
        return true;
    }
    catch {
        return false;
    } }
    return { play, stop };
}