/* Intelectus Matemática V18.6.1 — resize compositor guard */
(()=>{
  const root=document.documentElement;
  let timer=0;
  const begin=()=>{
    root.classList.add('ifx-layout-resizing');
    clearTimeout(timer);
    timer=setTimeout(()=>{
      root.classList.remove('ifx-layout-resizing');
      void document.body?.offsetHeight;
    },140);
  };
  addEventListener('resize',begin,{passive:true});
  addEventListener('orientationchange',begin,{passive:true});
  window.visualViewport?.addEventListener('resize',begin,{passive:true});
  document.addEventListener('fullscreenchange',begin,{passive:true});
  window.IntelectusResponsiveV1861={begin,release:'V18.6.3-LOGO-CENTER-MOBILE-SCROLL-20260916'};
})();
