const escape = (text) => text.replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const COLORS = ['#1769a5', '#a84028', '#5a479b'];
const shape = (symbol, color = '#1769a5') => symbol === '●' ? `<circle cx="50" cy="50" r="32" fill="${color}"/>` : symbol === '▲' ? `<polygon points="50,10 88,82 12,82" fill="${color}"/>` : symbol === '■' ? `<rect x="20" y="20" width="60" height="60" fill="${color}"/>` : `<rect x="10" y="31" width="80" height="38" fill="${color}"/>`;
const svg = (body, label, box = '0 0 100 100', className = 'mathFigure') => `<svg class="${className}" viewBox="${box}" role="img" aria-label="${escape(label)}" xmlns="http://www.w3.org/2000/svg">${body}</svg>`;
function collection(text, variant = 0) { const n = (text.match(/●/g) || []).length; if (!n)
    return '<span class="emptyCollection" role="img" aria-label="Grupo vazio"><span>Vazio</span></span>'; const columns = n <= 4 ? 2 : 5; return svg(Array.from({ length: n }, (_, i) => { const column = i % columns, row = Math.floor(i / columns), offset = variant % 2 ? (row % 2 ? 4 : -4) : 0; return `<circle cx="${columns === 2 ? 35 + column * 32 : 15 + column * 18 + offset}" cy="${n <= 4 ? 35 + row * 32 : 18 + row * 19}" r="6" fill="#153b55"/>`; }).join(''), `Grupo com ${n} pontos`); }
function choiceVisual(t, option, index) { const visual = t.visual; if (visual?.kind === 'dots')
    return collection(option, index + 1); if (visual?.kind === 'shapes' || visual?.kind === 'spatial')
    return svg(`<g transform="rotate(${visual.kind === 'shapes' ? (visual.rotations?.[index] || 0) : 0} 50 50)">${shape(option, COLORS[index])}</g>`, option); if (visual && ['height', 'length', 'capacity'].includes(visual.kind)) {
    const n = visual.values?.[['A', 'B', 'C'].indexOf(option)] || 0;
    if (visual.kind === 'height')
        return svg(`<line x1="8" y1="88" x2="92" y2="88" stroke="#526a7b" stroke-width="2"/><rect x="32" y="${88 - n * 11}" width="36" height="${n * 11}" fill="${COLORS[index]}"/>`, option) + `<span class="choiceLabel">${option}</span>`;
    if (visual.kind === 'length')
        return svg(`<line x1="8" y1="20" x2="8" y2="80" stroke="#526a7b" stroke-width="2"/><rect x="8" y="36" width="${n * 13}" height="26" fill="${COLORS[index]}"/>`, option) + `<span class="choiceLabel">${option}</span>`;
    return svg(Array.from({ length: n }, (_, j) => `<rect x="${15 + (j % 3) * 25}" y="${20 + Math.floor(j / 3) * 30}" width="20" height="22" rx="3" fill="${COLORS[index]}"/>`).join(''), option) + `<span class="choiceLabel">${option}</span>`;
} return escape(option); }
function taskVisual(t) { const visual = t.visual; if (visual?.kind === 'spatial') {
    const positions = [[115, 0], [0, 86], [115, 172]];
    return svg(`<rect x="130" y="104" width="70" height="42" rx="4" fill="#dce8f0"/><text x="165" y="131" text-anchor="middle" font-size="12">CAIXA</text>${visual.symbols.map((symbol, i) => `<g transform="translate(${positions[i][0]} ${positions[i][1]}) scale(.65)">${shape(symbol, COLORS[i])}</g>`).join('')}`, 'Posição relativa', '0 0 280 245', 'spatialFigure');
} if (visual?.kind === 'chart') {
    const values = visual.values, symbols = visual.symbols, contents = values.map((n, i) => Array.from({ length: n }, (_, j) => `<circle cx="${55 + i * 100}" cy="${145 - j * 24}" r="8" fill="${COLORS[i]}"/>`).join('') + `<text x="${55 + i * 100}" y="195" text-anchor="middle" font-size="27">${symbols[i]}</text>`).join('');
    return svg(`<line x1="16" y1="163" x2="295" y2="163" stroke="#526a7b"/>${contents}`, 'Gráfico de votos', '0 0 310 210', 'dataFigure') + '<small class="visualKey">● = um voto</small>';
} if (visual && ['height', 'length', 'capacity'].includes(visual.kind))
    return `<span class="visualGuide">${escape(t.stimulus)}</span>`; if (visual?.kind === 'shapes')
    return '<span class="visualGuide">A figura pode mudar de posição.</span>'; if (t.world === 'patterns')
    return `<span class="patternStrip">${t.stimulus.split(' ').filter(Boolean).map(symbol => ['●', '▲', '■'].includes(symbol) ? svg(shape(symbol), symbol) : `<span>${escape(symbol)}</span>`).join('')}</span>`; if (['numbers', 'quantities', 'operations'].includes(t.world))
    return t.stimulus.replace(/∅/g, '<span class="emptyCollection"><span>Vazio</span></span>').replace(/●/g, `<button class="counter" aria-pressed="false">●</button>`); return t.stimulus; }