const AVATAR_IDS=['👧','👦','🦉','🐼','🦁','🦊','🐰','🚀'];
const AVATAR_NAMES={'👧':'Aventureira','👦':'Aventureiro','🦉':'Coruja Leitora','🐼':'Panda Amigo','🦁':'Leão Corajoso','🦊':'Raposa Esperta','🐰':'Coelha Feliz','🚀':'Mini Astronauta'};
const AVATAR_SRC={'👧':'./assets/family/avatar-aventureira.webp','👦':'./assets/family/avatar-aventureiro.webp','🦉':'./assets/family/avatar-coruja.webp','🐼':'./assets/family/avatar-panda.webp','🦁':'./assets/family/avatar-leao.webp','🦊':'./assets/family/avatar-raposa.webp','🐰':'./assets/family/avatar-coelha.webp','🚀':'./assets/family/avatar-astronauta.webp'};
const TEACHERS=[
 {id:'lia',name:'Lia',title:'Profª',tag:'acolhedora e carinhosa',src:'./assets/family/guide-lia.webp'},
 {id:'aline',name:'Aline',title:'Profª',tag:'criativa e incentivadora',src:'./assets/family/guide-aline.webp'},
 {id:'daniel',name:'Daniel',title:'Prof.',tag:'curioso e encorajador',src:'./assets/family/guide-daniel.webp'},
 {id:'caio',name:'Caio',title:'Prof.',tag:'divertido e parceiro',src:'./assets/family/guide-caio.webp'}
];
const HERO_ART=`<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1200 620"><defs><linearGradient id="hs" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#8bd9ff"/><stop offset="1" stop-color="#f4fbff"/></linearGradient></defs><rect width="1200" height="620" rx="42" fill="url(#hs)"/><circle cx="1040" cy="85" r="45" fill="#fff0a8"/><path d="M0 380 Q180 290 355 370 T700 355 T1000 350 T1200 335 V620 H0Z" fill="#6cc66f"/><rect x="300" y="58" width="600" height="190" rx="44" fill="#0f63c9"/><text x="600" y="126" text-anchor="middle" font-family="Arial" font-size="54" font-weight="900" fill="#ffd34e">MATEMÁTICA</text><text x="600" y="188" text-anchor="middle" font-family="Arial" font-size="40" font-weight="900" fill="#fff">TAMBÉM É AVENTURA!</text><text x="600" y="224" text-anchor="middle" font-family="Arial" font-size="24" font-weight="700" fill="#dff3ff">explore • pense • resolva • conquiste</text></svg>`;
function avatarArt(id){const key=AVATAR_IDS.includes(id)?id:'🦊';return `<span class="castArt avatarCast"><img src="${AVATAR_SRC[key]}" alt="${AVATAR_NAMES[key]}"></span>`}
function teacherArt(index){const item=TEACHERS[Math.max(0,Math.min(index,TEACHERS.length-1))];return `<span class="castArt teacherCast"><img src="${item.src}" alt="${item.title} ${item.name}"></span>`}
function teacherName(index=s.teacherAvatar){const item=TEACHERS[Math.max(0,Math.min(index,TEACHERS.length-1))];return `${item.title} ${item.name}`}
function teacherCoach(message){return `<div class="teacherCoach">${teacherArt(s.teacherAvatar)}<div><b>${teacherName()}</b><p>${esc(message)}</p></div></div>`}
function heroArt(){return `<div class="heroArt" aria-hidden="true">${HERO_ART}</div>`}
