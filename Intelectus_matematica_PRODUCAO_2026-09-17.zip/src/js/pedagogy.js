const LIMITS = [5, 10, 20];
const SKILLS = {
    numbers: [{ id: 'quantidade-numeral', label: 'Quantidade e numeral', tip: 'Conte cada ponto uma vez. O último número diz quantos há. Um grupo vazio combina com zero.' }, { id: 'comparar-numerais', label: 'Comparar números', tip: 'Na contagem para frente, o número que vem depois representa uma quantidade maior.' }],
    quantities: [{ id: 'equivalencia', label: 'Coleções iguais e vazias', tip: 'Ligue um ponto do modelo a um ponto de cada grupo. Quantidades iguais formam pares sem sobra.' }, { id: 'comparar-mais', label: 'Mais objetos', tip: 'Compare os grupos fazendo pares. O grupo em que sobra um ponto tem mais.' }, { id: 'comparar-menos', label: 'Menos objetos', tip: 'Compare os grupos fazendo pares. O grupo que termina primeiro tem menos.' }],
    sequence: [{ id: 'sequencia-numerica', label: 'Sequências numéricas', tip: 'Observe se os números aumentam ou diminuem e quanto muda a cada passo.' }],
    operations: [{ id: 'juntar', label: 'Juntar', tip: 'Junte os dois grupos e conte todos os pontos.' }, { id: 'retirar', label: 'Retirar', tip: 'Marque os pontos que saíram. Conte somente os que ficaram.' }],
    patterns: [{ id: 'padrao-repetitivo', label: 'Padrões e lacunas', tip: 'Descubra o pequeno grupo de figuras que se repete. Continue usando a mesma ordem.' }],
    geometry: [{ id: 'figuras-planas', label: 'Figuras planas', tip: 'Observe o contorno e os lados. Uma figura pode mudar de posição sem mudar de nome.' }, { id: 'posicao-relativa', label: 'Posição com referência', tip: 'Use a caixa central como referência. Acima fica mais perto do topo; abaixo fica mais perto da base.' }],
    measures: [{ id: 'comparar-alturas', label: 'Altura', tip: 'Compare as barras a partir da mesma linha de base.' }, { id: 'comparar-comprimentos', label: 'Comprimento', tip: 'As fitas começam na mesma linha. Observe qual vai mais longe.' }, { id: 'comparar-capacidades', label: 'Capacidade com unidade igual', tip: 'Cada quadradinho representa um copinho igual. Mais copinhos indicam maior capacidade.' }, { id: 'ler-dados', label: 'Leitura de dados', tip: 'Cada bolinha representa um voto. O animal embaixo identifica a coluna e não entra na contagem.' }]
};
function shuffle(a) { const out = [...a]; for (let i = out.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [out[i], out[j]] = [out[j], out[i]];
} return out; }
const dots = (n) => n === 0 ? '∅' : Array(n).fill('●').join(' ');
function makeTask(id, i, level, random = Math.random) {
    const sh = (a) => { const out = [...a]; for (let j = out.length - 1; j > 0; j--) {
        const k = Math.floor(random() * (j + 1));
        [out[j], out[k]] = [out[k], out[j]];
    } return out; };
    const rand = (min, max) => min + Math.floor(random() * (max - min + 1));
    const band = Math.min(2, Math.max(0, level)), max = LIMITS[band];
    const numOpts = (n) => sh([n, ...sh(Array.from({ length: max + 1 }, (_, j) => j).filter(j => j !== n)).slice(0, 2)]).map(String);
    const item = (prompt, stimulus, options, answer, hint, explain, skill, visual) => ({ world: id, prompt, stimulus, options: sh(options), answer, hint, explain, skill, level: band, visual });
    if (id === 'numbers') {
        if (i === 1 || i === 3) {
            const vals = sh(Array.from({ length: max + 1 }, (_, n) => n)).slice(0, 3), high = i === 1, ans = high ? Math.max(...vals) : Math.min(...vals);
            return item(high ? 'Qual número é maior?' : 'Qual número é menor?', 'Compare os números.', vals.map(String), String(ans), SKILLS.numbers[1].tip, `Entre essas opções, ${ans} é o número ${high ? 'maior' : 'menor'}.`, 'comparar-numerais');
        }
        const n = i === 0 ? 0 : rand(1, max);
        return item('Conte os pontos. Qual número mostra essa quantidade?', dots(n), numOpts(n), String(n), SKILLS.numbers[0].tip, n === 0 ? 'Não há pontos. A quantidade é zero.' : `Há ${n} pontos.`, 'quantidade-numeral');
    }
    if (id === 'quantities') {
        if (i === 1 || i === 2) {
            const high = i === 1, top = rand(2, max), vals = [top, ...sh(Array.from({ length: top }, (_, n) => n)).slice(0, 2)], ans = high ? Math.max(...vals) : Math.min(...vals), skill = high ? 'comparar-mais' : 'comparar-menos';
            return item(high ? 'Qual grupo tem mais pontos?' : 'Qual grupo tem menos pontos?', 'Compare os grupos.', vals.map(dots), dots(ans), SKILLS.quantities[high ? 1 : 2].tip, high ? 'Este grupo tem mais pontos que os outros.' : 'Este grupo tem menos pontos que os outros.', skill, { kind: 'dots' });
        }
        const n = i === 3 ? 0 : rand(1, Math.min(max, i === 0 ? 4 : max));
        return item('Qual grupo tem a mesma quantidade de pontos que o modelo?', dots(n), numOpts(n).map(v => dots(Number(v))), dots(n), SKILLS.quantities[0].tip, n === 0 ? 'Os dois grupos estão vazios.' : 'Os dois grupos têm a mesma quantidade.', 'equivalencia', { kind: 'dots' });
    }
    if (id === 'sequence') {
        const step = band === 2 && i % 2 === 1 ? 2 : 1, n = rand(0, Math.max(0, max - step * 3)), desc = i % 2 === 1, ans = desc ? n : n + 3 * step, series = desc ? [n + 3 * step, n + 2 * step, n + step] : [n, n + step, n + 2 * step];
        return item('Qual número completa a sequência?', series.join(' → ') + ' → ?', numOpts(ans), String(ans), `Conte ${desc ? 'para trás' : 'para frente'}, de ${step} em ${step}.`, `O número que falta é ${ans}.`, 'sequencia-numerica');
    }
    if (id === 'operations') {
        if (i % 2 === 1) {
            const a = rand(1, max), b = rand(1, a), n = a - b;
            return item(`Havia ${a} pontos. Retiramos ${b}. Quantos ficaram?`, `${dots(a)}<br><span class="transformation">Retirar ${b}</span>`, numOpts(n), String(n), SKILLS.operations[1].tip, `${a} menos ${b} é ${n}.`, 'retirar');
        }
        const a = rand(0, Math.max(0, max - 1)), b = rand(1, Math.max(1, max - a)), n = a + b;
        return item(`Temos ${a} pontos e juntamos mais ${b}. Quantos há agora?`, `${dots(a)}<br>+<br>${dots(b)}`, numOpts(n), String(n), SKILLS.operations[0].tip, `${a} mais ${b} é ${n}.`, 'juntar');
    }
    if (id === 'patterns') {
        const shapes = sh(['●', '▲', '■']), unit = band === 0 ? [shapes[0], shapes[1]] : band === 1 ? [shapes[0], shapes[0], shapes[1]] : shapes, series = [...unit, ...unit, ...unit], gap = i % 2 ? unit.length + 1 : unit.length * 2, ans = series[gap], visible = [...series];
        visible[gap] = '?';
        return item('Qual figura entra no lugar da interrogação?', visible.slice(0, unit.length * 2 + 2).join(' '), shapes, ans, SKILLS.patterns[0].tip, 'O pequeno grupo de figuras continua na mesma ordem.', 'padrao-repetitivo');
    }
    if (id === 'geometry') {
        if (i % 2 === 1) {
            const symbols = sh(['●', '▲', '■']), above = i === 1;
            return item(above ? 'Qual figura está acima da caixa central?' : 'Qual figura está abaixo da caixa central?', 'Use a caixa como referência.', symbols, above ? symbols[0] : symbols[2], SKILLS.geometry[1].tip, above ? 'Esta figura está acima da caixa.' : 'Esta figura está abaixo da caixa.', 'posicao-relativa', { kind: 'spatial', symbols, relation: above ? 'above' : 'below' });
        }
        const forms = ['●', '▲', '■', '▭'], names = { '●': 'círculo', '▲': 'triângulo', '■': 'quadrado', '▭': 'retângulo' }, ans = forms[rand(0, 3)];
        return item(`Toque no ${names[ans]}.`, 'Observe as formas.', sh(forms.filter(x => x !== ans)).slice(0, 2).concat(ans), ans, 'Observe o contorno, os lados e os cantos.', `Esta figura representa um ${names[ans]}.`, 'figuras-planas', { kind: 'shapes', rotations: sh([0, 45, 90]) });
    }
    const values = sh([rand(1, 2), rand(3, 4), rand(5, 6)]), labels = ['A', 'B', 'C'];
    if (i === 0 || i === 1 || i === 2) {
        const kind = i === 0 ? 'height' : i === 1 ? 'length' : 'capacity', ans = labels[values.indexOf(Math.max(...values))], skill = i === 0 ? 'comparar-alturas' : i === 1 ? 'comparar-comprimentos' : 'comparar-capacidades';
        return item(i === 0 ? 'Qual barra é mais alta?' : i === 1 ? 'Qual fita é mais comprida?' : 'Qual recipiente precisou de mais copinhos iguais para ficar cheio?', 'Compare a partir da mesma linha.', labels, ans, SKILLS.measures[i].tip, i === 0 ? 'Esta barra é a mais alta.' : i === 1 ? 'Esta fita é a mais comprida.' : 'Mais copinhos iguais indicam maior capacidade.', skill, { kind, values });
    }
    const animals = ['🐶', '🐱', '🐰'];
    if (i === 4 && band > 0) {
        const shared = rand(1, 3), other = shared + 1, votes = sh([shared, shared, other]), pairs = ['🐶 e 🐱', '🐶 e 🐰', '🐱 e 🐰'], ans = votes[0] === votes[1] ? pairs[0] : votes[0] === votes[2] ? pairs[1] : pairs[2];
        return item('Quais animais receberam a mesma quantidade de votos?', 'Cada bolinha representa um voto.', pairs, ans, SKILLS.measures[3].tip, 'Estas duas colunas têm a mesma quantidade de votos.', 'ler-dados', { kind: 'chart', values: votes, symbols: animals });
    }
    const votes = sh([0, rand(1, 2), rand(3, 5)]), more = i === 3, ans = animals[votes.indexOf(more ? Math.max(...votes) : Math.min(...votes))];
    return item(more ? 'Qual animal recebeu mais votos?' : 'Qual animal recebeu menos votos?', 'Cada bolinha representa um voto.', animals, ans, SKILLS.measures[3].tip, more ? 'Este animal tem mais votos.' : 'Este animal tem menos votos.', 'ler-dados', { kind: 'chart', values: votes, symbols: animals });
}
function taskSignature(task) { return JSON.stringify([task.world, task.skill, task.prompt, task.stimulus, task.answer]); }
function makeMission(world, level, random = Math.random) { const tasks = [], seen = new Set(); let seed = (world.length * 2654435761 + level * 1013904223 + 7) >>> 0; const fallback = () => { seed = (Math.imul(seed, 1664525) + 1013904223) >>> 0; return seed / 4294967296; }; for (let index = 0; index < 5; index++) {
    let accepted = false;
    for (let attempt = 0; attempt < 1024; attempt++) {
        const task = makeTask(world, index, level, attempt < 24 ? random : fallback), sig = taskSignature(task);
        if (seen.has(sig))
            continue;
        seen.add(sig);
        tasks.push(task);
        accepted = true;
        break;
    }
    if (!accepted)
        throw new Error('Não foi possível preparar cinco desafios diferentes.');
} return tasks; }
function nextLevel(current, history, requiredSkills = []) { const recent = history.slice(-10); if (recent.length < 10 || new Set(recent.map(o => o.mission)).size < 2)
    return current; const enough = requiredSkills.every(skill => recent.filter(o => o.skill === skill && o.independent).length >= 2); if (enough && recent.filter(o => o.independent).length >= 8)
    return Math.min(2, current + 1); if (recent.slice(-5).filter(o => o.independent).length <= 1)
    return Math.max(0, current - 1); return current; }