/* Intelectus Matemática V16 Premium — integração PWA/microinterações */
(() => {
  document.documentElement.classList.add('v16-premium');
  const shortcut = new URLSearchParams(location.search).get('atalho');
  if (shortcut && typeof s === 'object' && s.onboarded) {
    if (shortcut === 'continuar') route = s.diag ? 'home' : 'diagIntro';
    if (shortcut === 'conquistas') route = 'rewards';
    if (shortcut === 'familia') route = 'adult';
    queueMicrotask(() => render());
    history.replaceState({}, '', location.pathname + location.hash);
  }
  document.addEventListener('pointerdown', event => {
    if (!event.target.closest('button,[role="button"]')) return;
    if (navigator.vibrate && matchMedia('(pointer:coarse)').matches) navigator.vibrate(7);
  }, {passive:true});
  window.addEventListener('appinstalled', () => {
    document.documentElement.dataset.installed = 'true';
  });
})();