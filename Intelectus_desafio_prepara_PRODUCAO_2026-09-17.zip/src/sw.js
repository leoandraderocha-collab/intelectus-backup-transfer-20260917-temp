'use strict';
const TAG='rc23-annual-14000-adaptive-20260915';
const SCOPE_PATH=new URL(self.registration.scope).pathname;
const CACHE='intelectus-prepara-'+encodeURIComponent(SCOPE_PATH)+'-'+TAG;
const CORE=[
  './','./index.html','./manifest.webmanifest','./release.json','./app.css','./bootstrap.js','./family-standard.css','./family-standard.js','./family-controls.css','./family-controls.js',
  './01.js','./02.js','./03.js','./04.js','./05.js','./06.js',
  './assets/logo-preparamais-oficial.webp','./assets/icon-192.png','./assets/icon-512.png'
];
const SHELL_EXT=/\.(?:html?|js|css|json|webmanifest)$/i;

self.addEventListener('install',event=>{
  event.waitUntil((async()=>{
    const cache=await caches.open(CACHE);
    await Promise.allSettled(CORE.map(url=>cache.add(url)));
  })());
});

self.addEventListener('activate',event=>{
  event.waitUntil((async()=>{
    const keys=await caches.keys();
    await Promise.all(keys.filter(key=>key.startsWith('intelectus-prepara-')&&key!==CACHE).map(key=>caches.delete(key)));
    await self.clients.claim();
  })());
});

async function networkFirst(request){
  const cache=await caches.open(CACHE);
  try{
    const response=await fetch(request,{cache:'no-cache'});
    if(response&&response.ok) await cache.put(request,response.clone());
    return response;
  }catch(error){
    const cached=await cache.match(request);
    if(cached) return cached;
    if(request.mode==='navigate') return (await cache.match('./index.html')) || Response.error();
    throw error;
  }
}

async function cacheFirst(request){
  const cache=await caches.open(CACHE);
  const cached=await cache.match(request);
  if(cached) return cached;
  const response=await fetch(request);
  if(response&&response.ok) await cache.put(request,response.clone());
  return response;
}

self.addEventListener('fetch',event=>{
  if(event.request.method!=='GET') return;
  const url=new URL(event.request.url);
  if(url.origin!==self.location.origin) return;
  const isShell=event.request.mode==='navigate'||SHELL_EXT.test(url.pathname);
  event.respondWith(isShell?networkFirst(event.request):cacheFirst(event.request));
});
